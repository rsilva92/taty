<?php
/**
 * TATI STUDIO — AGENTE API v2.0.0
 * Recebe ações do frontend: geração de blocos e CRUD de projetos.
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

// ── Autenticação ──────────────────────────────────────────────────────────────
if (empty($_SESSION['auth'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado.']);
    exit;
}

// ── Configuração ──────────────────────────────────────────────────────────────
$cfg = dirname(__DIR__) . '/includes/config.php';
if (!file_exists($cfg)) {
    http_response_code(500);
    echo json_encode(['error' => 'Sistema não configurado. Execute o install.sh.']);
    exit;
}
require_once $cfg;

// ── Input ─────────────────────────────────────────────────────────────────────
$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'JSON inválido.']);
    exit;
}
$action = $body['action'] ?? 'generate';

// ── Conexão com o banco ───────────────────────────────────────────────────────
// Retorna array ['pdo' => PDO|null, 'error' => string|null]
function db(): array {
    if (!defined('DB_HOST') || !defined('DB_NAME')) {
        return ['pdo' => null, 'error' => 'Constantes de banco não definidas no config.php.'];
    }
    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4;connect_timeout=5',
            DB_HOST, DB_PORT, DB_NAME
        );
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        return ['pdo' => $pdo, 'error' => null];
    } catch (Exception $e) {
        $m = $e->getMessage();
        if (str_contains($m, 'Access denied'))
            $err = 'Credenciais do banco incorretas. Verifique DB_USER e DB_PASS no config.php.';
        elseif (str_contains($m, 'Unknown database'))
            $err = 'Banco "' . DB_NAME . '" não existe. Rode install.sh novamente.';
        elseif (str_contains($m, "Can't connect") || str_contains($m, 'refused'))
            $err = 'MySQL não está rodando. Execute: systemctl start mysql';
        else
            $err = 'Erro de banco: ' . $m;
        return ['pdo' => null, 'error' => $err];
    }
}

// ── Ações de banco ────────────────────────────────────────────────────────────

if ($action === 'save_project') {
    ['pdo' => $pdo, 'error' => $err] = db();
    if (!$pdo) { echo json_encode(['ok' => false, 'error' => $err]); exit; }

    $titulo     = mb_substr(trim($body['titulo'] ?? 'Sem título'), 0, 255);
    $roteiro    = $body['roteiro']    ?? '';
    $resultados = json_encode($body['resultados'] ?? [], JSON_UNESCAPED_UNICODE);
    $pid        = (int)($body['project_id'] ?? 0);

    if ($pid > 0) {
        $pdo->prepare('UPDATE projetos SET titulo=?, roteiro=?, resultados=? WHERE id=?')
            ->execute([$titulo, $roteiro, $resultados, $pid]);
        echo json_encode(['ok' => true, 'project_id' => $pid]);
    } else {
        $pdo->prepare('INSERT INTO projetos (titulo, roteiro, resultados) VALUES (?,?,?)')
            ->execute([$titulo, $roteiro, $resultados]);
        echo json_encode(['ok' => true, 'project_id' => (int)$pdo->lastInsertId()]);
    }
    exit;
}

if ($action === 'list_projects') {
    ['pdo' => $pdo, 'error' => $err] = db();
    if (!$pdo) { echo json_encode(['projects' => [], 'error' => $err]); exit; }

    $rows = $pdo->query(
        "SELECT id, titulo,
                DATE_FORMAT(criado_em, '%d/%m/%Y %H:%i') AS criado_em
         FROM projetos ORDER BY criado_em DESC LIMIT 50"
    )->fetchAll();
    echo json_encode(['projects' => $rows]);
    exit;
}

if ($action === 'load_project') {
    ['pdo' => $pdo, 'error' => $err] = db();
    if (!$pdo) { echo json_encode(['error' => $err]); exit; }

    $id = (int)($body['project_id'] ?? 0);
    if ($id <= 0) { echo json_encode(['error' => 'ID inválido.']); exit; }

    $st = $pdo->prepare('SELECT * FROM projetos WHERE id = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) { echo json_encode(['error' => 'Projeto não encontrado.']); exit; }

    $row['resultados'] = json_decode($row['resultados'], true) ?? [];
    echo json_encode(['project' => $row]);
    exit;
}

if ($action === 'delete_project') {
    ['pdo' => $pdo, 'error' => $err] = db();
    if (!$pdo) { echo json_encode(['ok' => false, 'error' => $err]); exit; }

    $id = (int)($body['project_id'] ?? 0);
    if ($id <= 0) { echo json_encode(['ok' => false, 'error' => 'ID inválido.']); exit; }

    $pdo->prepare('DELETE FROM projetos WHERE id = ?')->execute([$id]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Teste de API Key ─────────────────────────────────────────────────────────
if ($action === 'test_apikey') {
    $testKey = trim($body['api_key'] ?? '');
    if (strlen($testKey) < 20 || !str_starts_with($testKey, 'sk-ant-')) {
        echo json_encode(['ok' => false, 'error' => 'Chave inválida (deve começar com sk-ant-).']);
        exit;
    }
    // Envia prompt mínimo para verificar se a chave funciona
    $testPayload = json_encode([
        'model'      => 'claude-haiku-4-5-20251001',
        'max_tokens' => 10,
        'messages'   => [['role' => 'user', 'content' => 'Hi']]
    ]);
    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $testPayload,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . $testKey,
            'anthropic-version: 2023-06-01',
        ],
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        echo json_encode(['ok' => false, 'error' => 'Erro de conexão: ' . $curlErr]);
        exit;
    }
    $data = json_decode($resp, true);
    if ($httpCode === 200) {
        echo json_encode(['ok' => true]);
    } else {
        $msg = $data['error']['message'] ?? "HTTP {$httpCode}";
        echo json_encode(['ok' => false, 'error' => $msg]);
    }
    exit;
}

// ── Geração de bloco via Anthropic ────────────────────────────────────────────
$prompt = trim($body['prompt'] ?? '');
if (empty($prompt)) {
    http_response_code(400);
    echo json_encode(['error' => 'Prompt vazio.']);
    exit;
}

$payload = json_encode([
    'model'      => 'claude-opus-4-5',
    'max_tokens' => 4096,
    'messages'   => [['role' => 'user', 'content' => $prompt]]
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_TIMEOUT        => 120,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: '          . ANTHROPIC_API_KEY,
        'anthropic-version: 2023-06-01',
    ],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro de conexão: ' . $curlErr]);
    exit;
}

$data = json_decode($response, true);
if ($httpCode !== 200) {
    $msg = $data['error']['message'] ?? 'Erro desconhecido da API Anthropic.';
    http_response_code($httpCode >= 400 ? $httpCode : 500);
    echo json_encode(['error' => $msg]);
    exit;
}

$result = implode('', array_map(
    fn($b) => $b['text'] ?? '',
    array_filter($data['content'] ?? [], fn($b) => ($b['type'] ?? '') === 'text')
));

if (empty(trim($result))) {
    http_response_code(500);
    echo json_encode(['error' => 'A IA retornou resposta vazia.']);
    exit;
}

// Log silencioso
try {
    ['pdo' => $pdo] = db();
    if ($pdo) {
        $ip = substr($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '', 0, 45);
        $pdo->prepare('INSERT INTO sessoes_log (ip, acao) VALUES (?,?)')->execute([$ip, 'bloco_gerado']);
    }
} catch (Exception $e) { /* silencia */ }

echo json_encode(['result' => $result], JSON_UNESCAPED_UNICODE);
