<?php
session_start();

// ── Configuração ──────────────────────────────────────────────────────────────
$cfg = __DIR__ . '/includes/config.php';
if (!file_exists($cfg)) {
    die('<html><body style="background:#08080f;color:#f87171;font:1rem sans-serif;padding:3rem;text-align:center">
        <h2>Sistema não instalado</h2>
        <p style="margin-top:1rem;color:#72728a">Execute <code>sudo bash install.sh</code> no servidor para instalar.</p>
    </body></html>');
}
require_once $cfg;

// ── Autenticação ──────────────────────────────────────────────────────────────
$loginError  = '';
// Lê mensagens de sessão (usadas após redirect PRG do save_apikey)
$apiKeyMsg   = $_SESSION['apikey_ok']    ?? '';
$apiKeyError = $_SESSION['apikey_error'] ?? '';
unset($_SESSION['apikey_ok'], $_SESSION['apikey_error']);

// Abre painel correto se vier ?panel= na URL
$openPanel = htmlspecialchars($_GET['panel'] ?? '');

if (isset($_POST['action'])) {
    if ($_POST['action'] === 'login') {
        if (password_verify($_POST['password'] ?? '', APP_PASSWORD)) {
            session_regenerate_id(true);
            $_SESSION['auth'] = true;
        } else {
            $loginError = 'Senha incorreta. Tente novamente.';
        }
    }
    if ($_POST['action'] === 'logout') {
        session_destroy();
        header('Location: ' . $_SERVER['SCRIPT_NAME']);
        exit;
    }
    // ── Salvar nova API Key ───────────────────────────────────────────────────
    if ($_POST['action'] === 'save_apikey' && !empty($_SESSION['auth'])) {
        $newKey = trim($_POST['api_key'] ?? '');

        // Validação flexível — aceita qualquer chave sk-ant- com tamanho mínimo
        if (strlen($newKey) < 20 || substr($newKey, 0, 7) !== 'sk-ant-') {
            $_SESSION['apikey_error'] = 'Chave inválida. Deve começar com sk-ant- e ter ao menos 20 caracteres.';
        } else {
            $cfgFile    = __DIR__ . '/includes/config.php';
            $cfgContent = file_get_contents($cfgFile);

            if ($cfgContent === false) {
                $_SESSION['apikey_error'] = 'Não foi possível ler o config.php.';
            } else {
                // Substitui a linha da ANTHROPIC_API_KEY com regex segura
                $escaped = str_replace("'", "\'", $newKey);
                $cfgNew  = preg_replace(
                    "/define\s*\(\s*'ANTHROPIC_API_KEY'\s*,\s*'[^']*'\s*\)\s*;/",
                    "define('ANTHROPIC_API_KEY', '" . $escaped . "');",
                    $cfgContent
                );

                if ($cfgNew === null) {
                    $_SESSION['apikey_error'] = 'Erro na expressão regular. Contate o suporte.';
                } elseif (file_put_contents($cfgFile, $cfgNew) === false) {
                    $_SESSION['apikey_error'] = 'Não foi possível salvar. Execute: chmod 600 includes/config.php && chown www-data:www-data includes/config.php';
                } else {
                    $_SESSION['apikey_ok'] = 'Chave de API atualizada com sucesso! Recarregue a página se necessário.';
                }
            }
        }
        // PRG — evita resubmissão ao recarregar
        header('Location: ' . $_SERVER['SCRIPT_NAME'] . '?panel=settings');
        exit;
    }
}
$authed = !empty($_SESSION['auth']);

// Mascara a chave atual para exibição
$maskedKey = '';
if (defined('ANTHROPIC_API_KEY') && strlen(ANTHROPIC_API_KEY) > 10) {
    $maskedKey = substr(ANTHROPIC_API_KEY, 0, 12) . '...' . substr(ANTHROPIC_API_KEY, -4);
}

// ── URL da API (funciona na raiz e em subpasta) ───────────────────────────────
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$apiUrl    = $scriptDir . '/api/agent.php';

// ── Blocos de produção ────────────────────────────────────────────────────────
$blocos = [
    1  => ['🗺️', 'Mapa do Roteiro',      'Extrai estrutura, produtos, momentos-chave e intenção de compra.'],
    2  => ['🎯', 'Verdade-Base',          'Fatos reais do roteiro que sustentam todo o conteúdo.'],
    3  => ['📐', 'Ângulo Estratégico',    'Posicionamento, busca, retenção e decisão de compra.'],
    4  => ['✏️', 'Roteiro Otimizado',     'Versão aprimorada mantendo 100% da essência original.'],
    5  => ['🎬', 'Storyboard 3×3',        'Divisão em 9 a 12 cenas com descrição visual de cada uma.'],
    6  => ['🎥', 'Shotlist',              'Lista técnica: plano, ângulo, ação, iluminação e duração.'],
    7  => ['🖼️', 'Prompts Imagem IA',     'Prompts hiper-realistas em inglês para geração de imagens.'],
    8  => ['📹', 'Prompts Vídeo IA',      'Prompts com keyframes e movimentos de câmera.'],
    9  => ['💬', 'Overlays',             'Textos de sobreposição com timing e posição.'],
    10 => ['🔤', 'Títulos',              '20 títulos em 4 categorias para máximo CTR.'],
    11 => ['🖼️', 'Thumbnail',            'Conceito, layout, psicologia de clique e prompts.'],
    12 => ['📝', 'Descrição SEO',        'Descrição completa com timestamps, links e palavras-chave.'],
    13 => ['📢', 'Aba Comunidade',       'Post de carrossel com prompts, legenda e hashtags.'],
    14 => ['✅', 'Auditoria Final',      'Checklist completo de qualidade e conversão.'],
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tati Indicando — Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
/* ── Reset e variáveis ───────────────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:       #08080f;
  --surface:  #111119;
  --surface2: #181824;
  --border:   #23233a;
  --border2:  #2e2e4a;
  --accent:   #ff6b35;
  --accent2:  #ffb703;
  --text:     #eeeef8;
  --muted:    #72728a;
  --ok:       #2dd4bf;
  --err:      #f87171;
  --r:        14px;
  --sidebar:  264px;
}
html, body { height: 100%; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  line-height: 1.6;
}

/* ── LOGIN ───────────────────────────────────────────────────────────────────── */
.login-wrap {
  min-height: 100vh;
  display: flex; align-items: center; justify-content: center;
  padding: 2rem;
  background-image:
    radial-gradient(ellipse at 15% 25%, rgba(255,107,53,.1) 0%, transparent 55%),
    radial-gradient(ellipse at 85% 75%, rgba(255,183,3,.08) 0%, transparent 55%);
}
.login-card {
  width: 100%; max-width: 400px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  padding: 2.5rem;
}
.login-logo {
  font-family: 'Syne', sans-serif; font-weight: 800;
  font-size: 1.7rem; letter-spacing: -.04em; margin-bottom: 2rem;
}
.login-logo span { color: var(--accent); }
.login-card h2 { font-family: 'Syne', sans-serif; font-size: 1.1rem; margin-bottom: .3rem; }
.login-card .sub { color: var(--muted); font-size: .88rem; margin-bottom: 1.8rem; }
.login-err {
  background: rgba(248,113,113,.08); border: 1px solid rgba(248,113,113,.3);
  border-radius: 8px; padding: .7rem 1rem; margin-bottom: 1.2rem;
  color: var(--err); font-size: .86rem;
}

/* ── Elementos de formulário ─────────────────────────────────────────────────── */
label {
  display: block; font-size: .76rem; font-weight: 500;
  color: var(--muted); text-transform: uppercase;
  letter-spacing: .07em; margin-bottom: .42rem;
}
input[type=password], input[type=text], textarea {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 8px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: .92rem;
  padding: .78rem 1rem;
  outline: none;
  transition: border-color .2s;
  resize: vertical;
}
input:focus, textarea:focus { border-color: var(--accent); }
textarea { min-height: 280px; font-family: 'DM Mono', monospace; font-size: .82rem; line-height: 1.7; }

/* ── Botões ──────────────────────────────────────────────────────────────────── */
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: .5rem;
  background: var(--accent); color: #fff; border: none; border-radius: 8px;
  padding: .85rem 1.6rem;
  font-family: 'Syne', sans-serif; font-weight: 700; font-size: .92rem;
  cursor: pointer; transition: opacity .2s, transform .15s;
  letter-spacing: -.01em; white-space: nowrap;
}
.btn:hover  { opacity: .85; transform: translateY(-1px); }
.btn:active { transform: translateY(0); }
.btn:disabled { opacity: .38; cursor: not-allowed; transform: none; }
.btn-full  { width: 100%; }
.btn-sm    { padding: .48rem .95rem; font-size: .8rem; }
.btn-ghost {
  background: transparent;
  border: 1px solid var(--border2);
  color: var(--text);
  font-family: 'DM Sans', sans-serif; font-weight: 400;
}
.btn-ghost:hover { border-color: var(--accent); color: var(--accent); }

/* ── Layout principal ────────────────────────────────────────────────────────── */
.app { display: flex; height: 100vh; overflow: hidden; }

/* Sidebar */
.sidebar {
  width: var(--sidebar); flex-shrink: 0;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex; flex-direction: column;
  overflow-y: auto; overflow-x: hidden;
}
.sidebar-logo {
  padding: 1.4rem 1.4rem 1rem;
  font-family: 'Syne', sans-serif; font-weight: 800;
  font-size: 1.05rem; letter-spacing: -.03em;
  border-bottom: 1px solid var(--border); flex-shrink: 0;
}
.sidebar-logo span { color: var(--accent); }
.sidebar-logo .ver {
  font-family: 'DM Sans', sans-serif; font-size: .65rem;
  color: var(--muted); font-weight: 400; display: block; margin-top: .15rem;
}
.sidebar-section { padding: .9rem .7rem .3rem; }
.section-label {
  font-size: .67rem; text-transform: uppercase; letter-spacing: .09em;
  color: var(--muted); padding: 0 .6rem; margin-bottom: .35rem;
}
.nav-item {
  display: flex; align-items: center; gap: .6rem;
  padding: .58rem .8rem; border-radius: 8px;
  cursor: pointer; font-size: .86rem; color: var(--muted);
  transition: background .15s, color .15s; user-select: none;
}
.nav-item:hover  { background: rgba(255,255,255,.04); color: var(--text); }
.nav-item.active { background: rgba(255,107,53,.1);   color: var(--accent); }
.nav-item .icon  { font-size: .95rem; width: 20px; text-align: center; flex-shrink: 0; }
.nav-item .badge {
  margin-left: auto; font-size: .64rem;
  padding: .12rem .42rem; border-radius: 20px;
  background: var(--border); color: var(--muted);
}
.nav-item.done .badge { background: rgba(45,212,191,.12); color: var(--ok); }
.nav-item.err  .badge { background: rgba(248,113,113,.12); color: var(--err); }
.sidebar-footer {
  margin-top: auto; border-top: 1px solid var(--border); padding: 1rem .7rem;
}

/* Barra de progresso */
.progress-wrap { padding: .7rem 1.2rem; border-bottom: 1px solid var(--border); }
.progress-label { display: flex; justify-content: space-between; font-size: .73rem; color: var(--muted); margin-bottom: .35rem; }
.progress-bar { height: 4px; background: var(--border); border-radius: 2px; overflow: hidden; }
.progress-fill { height: 100%; background: linear-gradient(90deg, var(--accent), var(--accent2)); border-radius: 2px; transition: width .4s ease; }

/* Main */
.main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
.topbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: .9rem 2rem; border-bottom: 1px solid var(--border);
  background: var(--surface); flex-shrink: 0; gap: 1rem;
}
.topbar-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .98rem; }
.topbar-actions { display: flex; gap: .55rem; align-items: center; }
.content { flex: 1; overflow-y: auto; padding: 2rem; }

/* Painéis */
.panel { display: none; }
.panel.active { display: block; animation: fadeUp .2s ease; }
@keyframes fadeUp { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }

.panel-header { margin-bottom: 1.8rem; }
.panel-header h2 { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1.25rem; letter-spacing: -.02em; margin-bottom: .3rem; }
.panel-header p  { color: var(--muted); font-size: .88rem; }

/* Cards */
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--r); padding: 1.5rem; margin-bottom: 1.5rem; }
.card-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .92rem; margin-bottom: 1rem; }
.field { margin-bottom: 1.2rem; }
.field:last-child { margin-bottom: 0; }

/* Resultado */
.result-box {
  background: var(--surface2); border: 1px solid var(--border);
  border-radius: 10px; padding: 1.5rem; margin-bottom: 1rem; position: relative;
}
.result-box h3 {
  font-family: 'Syne', sans-serif; font-size: .82rem; color: var(--accent);
  text-transform: uppercase; letter-spacing: .07em; margin-bottom: .75rem;
}
.result-content {
  font-size: .81rem; line-height: 1.78; color: var(--text);
  white-space: pre-wrap; font-family: 'DM Mono', monospace;
}
.copy-btn {
  position: absolute; top: 1rem; right: 1rem;
  background: var(--border); border: none; border-radius: 6px;
  color: var(--muted); padding: .28rem .6rem; font-size: .73rem;
  cursor: pointer; transition: background .15s, color .15s; font-family: 'DM Sans', sans-serif;
}
.copy-btn:hover { background: var(--accent); color: #fff; }
.empty-state { color: var(--muted); font-size: .88rem; text-align: center; padding: 2.5rem; }

/* Welcome grid */
.welcome-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px,1fr)); gap: 1rem; margin-top: 1.5rem; }
.welcome-card {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: var(--r); padding: 1.2rem; cursor: pointer;
  transition: border-color .2s, background .2s;
}
.welcome-card:hover { border-color: var(--accent); background: rgba(255,107,53,.05); }
.wc-icon  { font-size: 1.5rem; margin-bottom: .55rem; }
.wc-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .88rem; margin-bottom: .2rem; }
.wc-desc  { font-size: .76rem; color: var(--muted); line-height: 1.5; }

/* Projetos */
.project-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: .78rem 1rem; border: 1px solid var(--border); border-radius: 8px;
  margin-bottom: .45rem; transition: border-color .2s;
}
.project-item:hover { border-color: var(--border2); }
.pi-title { font-weight: 500; font-size: .88rem; }
.pi-date  { font-size: .73rem; color: var(--muted); margin-top: .1rem; }
.pi-actions { display: flex; gap: .4rem; }
.pi-del { background: none; border: none; color: var(--muted); cursor: pointer; font-size: .78rem; padding: .25rem .45rem; border-radius: 4px; }
.pi-del:hover { color: var(--err); background: rgba(248,113,113,.1); }

/* Navegação entre blocos */
.bloco-nav { display: flex; gap: .65rem; flex-wrap: wrap; margin-bottom: 1.5rem; }

/* Loading */
.loading-overlay {
  display: none; position: fixed; inset: 0;
  background: rgba(8,8,15,.85); backdrop-filter: blur(5px);
  z-index: 999; align-items: center; justify-content: center; flex-direction: column; gap: 1rem;
}
.loading-overlay.show { display: flex; }
.spinner {
  width: 44px; height: 44px;
  border: 3px solid var(--border); border-top-color: var(--accent);
  border-radius: 50%; animation: spin 1s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 1rem; }
.loading-sub   { color: var(--muted); font-size: .84rem; }

/* Toast */
.toast {
  position: fixed; bottom: 2rem; right: 2rem;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 10px; padding: .78rem 1.2rem; font-size: .86rem;
  z-index: 9999; opacity: 0; transform: translateY(16px);
  transition: all .3s ease; pointer-events: none; max-width: 320px;
}
.toast.show { opacity: 1; transform: translateY(0); }
.toast.ok  { border-color: var(--ok);  color: var(--ok); }
.toast.err { border-color: var(--err); color: var(--err); }

@media (max-width: 768px) { .sidebar { display: none; } }
</style>
</head>
<body>

<?php if (!$authed): ?>
<!-- ══════════════ LOGIN ══════════════ -->
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">Tati <span>Studio</span></div>
    <h2>Entrar no sistema</h2>
    <p class="sub">Digite sua senha para acessar o Studio.</p>
    <?php if ($loginError): ?>
    <div class="login-err">⚠ <?= htmlspecialchars($loginError) ?></div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="login">
      <div class="field">
        <label>Senha</label>
        <input type="password" name="password" autofocus placeholder="••••••••" autocomplete="current-password">
      </div>
      <button class="btn btn-full" type="submit" style="margin-top:.6rem">Entrar</button>
    </form>
  </div>
</div>

<?php else: ?>
<!-- ══════════════ APP ══════════════ -->
<div class="app">

  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      Tati <span>Studio</span>
      <span class="ver">v<?= APP_VERSION ?></span>
    </div>

    <div class="progress-wrap">
      <div class="progress-label">
        <span>Progresso</span>
        <span id="prog-pct">0%</span>
      </div>
      <div class="progress-bar">
        <div class="progress-fill" id="prog-fill" style="width:0%"></div>
      </div>
    </div>

    <div class="sidebar-section">
      <div class="section-label">Início</div>
      <div class="nav-item active" data-panel="welcome" onclick="goPanel('welcome')">
        <span class="icon">🏠</span> Início
      </div>
      <div class="nav-item" data-panel="roteiro" onclick="goPanel('roteiro')">
        <span class="icon">📋</span> Roteiro
        <span class="badge" id="badge-roteiro">—</span>
      </div>
      <div class="nav-item" data-panel="projetos" onclick="goPanel('projetos');loadProjects()">
        <span class="icon">💾</span> Projetos salvos
      </div>
    </div>

    <div class="sidebar-section">
      <div class="section-label">Agentes de produção</div>
      <?php foreach ($blocos as $n => [$ic, $label]): ?>
      <div class="nav-item" data-panel="bloco<?= $n ?>" onclick="goPanel('bloco<?= $n ?>')">
        <span class="icon"><?= $ic ?></span> <?= $label ?>
        <span class="badge" id="badge-bloco<?= $n ?>">—</span>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="sidebar-section">
      <div class="section-label">Sistema</div>
      <div class="nav-item" data-panel="settings" onclick="goPanel('settings')">
        <span class="icon">⚙️</span> Configurações
      </div>
    </div>

    <div class="sidebar-footer">
      <form method="POST" style="margin:0">
        <input type="hidden" name="action" value="logout">
        <button class="btn btn-ghost btn-sm btn-full" type="submit">Sair</button>
      </form>
    </div>
  </aside>

  <!-- MAIN -->
  <main class="main">
    <div class="topbar">
      <span class="topbar-title" id="topbar-title">Início</span>
      <div class="topbar-actions">
        <button class="btn btn-sm btn-ghost" onclick="saveProject()">💾 Salvar</button>
        <button class="btn btn-sm btn-ghost" onclick="resetAll()">🔄 Novo</button>
        <button class="btn btn-sm" id="btn-run-all" onclick="runAll()" disabled>▶ Gerar tudo</button>
      </div>
    </div>

    <div class="content">

      <!-- WELCOME -->
      <div class="panel active" id="panel-welcome">
        <div class="panel-header">
          <h2>👋 Bem-vinda ao Studio</h2>
          <p>Sistema multiagente de produção YouTube Faceless — Tati Indicando</p>
        </div>
        <div class="card">
          <div class="card-title">🚀 Como usar</div>
          <div style="color:var(--muted);font-size:.9rem;line-height:2">
            <b style="color:var(--text)">1.</b> Vá em <b style="color:var(--accent)">Roteiro</b> e cole o roteiro completo do vídeo.<br>
            <b style="color:var(--text)">2.</b> Clique em <b style="color:var(--accent)">▶ Gerar tudo</b> para rodar todos os 14 agentes em sequência.<br>
            <b style="color:var(--text)">3.</b> Ou clique em <b style="color:var(--accent)">▶ Gerar este bloco</b> em qualquer etapa individualmente.<br>
            <b style="color:var(--text)">4.</b> Use <b style="color:var(--accent)">💾 Salvar</b> para guardar o projeto no banco de dados.<br>
            <b style="color:var(--text)">5.</b> Recupere projetos anteriores em <b style="color:var(--accent)">Projetos salvos</b>.
          </div>
        </div>
        <div class="welcome-grid">
          <div class="welcome-card" onclick="goPanel('roteiro')">
            <div class="wc-icon">📋</div>
            <div class="wc-title">Novo projeto</div>
            <div class="wc-desc">Cole o roteiro e inicie a produção</div>
          </div>
          <div class="welcome-card" onclick="runAll()">
            <div class="wc-icon">⚡</div>
            <div class="wc-title">Gerar tudo</div>
            <div class="wc-desc">14 agentes rodando em sequência</div>
          </div>
          <div class="welcome-card" onclick="goPanel('projetos');loadProjects()">
            <div class="wc-icon">💾</div>
            <div class="wc-title">Projetos salvos</div>
            <div class="wc-desc">Retome um projeto anterior</div>
          </div>
        </div>
      </div>

      <!-- ROTEIRO -->
      <div class="panel" id="panel-roteiro">
        <div class="panel-header">
          <h2>📋 Roteiro</h2>
          <p>Cole aqui o roteiro completo. Todo o sistema nasce a partir dele.</p>
        </div>
        <div class="card">
          <div class="field">
            <label>Título do projeto</label>
            <input type="text" id="proj-title" placeholder="Ex: Top 3 Aspiradores 2025">
          </div>
          <div class="field">
            <label>Roteiro completo</label>
            <textarea id="roteiro" placeholder="Cole aqui o roteiro completo do vídeo..."></textarea>
          </div>
          <button class="btn" onclick="saveRoteiro()">Salvar e continuar →</button>
        </div>
      </div>

      <!-- PROJETOS SALVOS -->
      <div class="panel" id="panel-projetos">
        <div class="panel-header">
          <h2>💾 Projetos salvos</h2>
          <p>Clique em um projeto para carregar todos os resultados.</p>
        </div>
        <div id="projects-list">
          <div class="empty-state">Carregando...</div>
        </div>
      </div>

      <!-- BLOCOS 1–14 -->
      <?php foreach ($blocos as $n => [$ic, $label, $desc]): ?>
      <div class="panel" id="panel-bloco<?= $n ?>">
        <div class="panel-header">
          <h2><?= $ic ?> Bloco <?= $n ?> — <?= $label ?></h2>
          <p><?= $desc ?></p>
        </div>
        <div class="bloco-nav">
          <button class="btn btn-sm" onclick="runBloco(<?= $n ?>)">▶ Gerar este bloco</button>
          <?php if ($n > 1): ?>
          <button class="btn btn-sm btn-ghost" onclick="goPanel('bloco<?= $n-1 ?>')">← Bloco <?= $n-1 ?></button>
          <?php endif; ?>
          <?php if ($n < 14): ?>
          <button class="btn btn-sm btn-ghost" onclick="goPanel('bloco<?= $n+1 ?>')">Bloco <?= $n+1 ?> →</button>
          <?php endif; ?>
        </div>
        <div id="result-bloco<?= $n ?>" style="display:none">
          <div class="result-box">
            <h3><?= $ic ?> <?= $label ?></h3>
            <button class="copy-btn" onclick="copyBloco(<?= $n ?>)">Copiar</button>
            <div class="result-content" id="content-bloco<?= $n ?>"></div>
          </div>
        </div>
        <div id="empty-bloco<?= $n ?>" class="card">
          <div class="empty-state">Clique em <strong>▶ Gerar este bloco</strong> para processar esta etapa.</div>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- CONFIGURAÇÕES -->
      <div class="panel" id="panel-settings">
        <div class="panel-header">
          <h2>⚙️ Configurações</h2>
          <p>Gerencie as configurações do sistema sem precisar editar arquivos no servidor.</p>
        </div>

        <!-- API Key -->
        <div class="card">
          <div class="card-title">🔑 Chave de API — Anthropic</div>
          <p style="color:var(--muted);font-size:.88rem;margin-bottom:1.2rem;line-height:1.6">
            Esta chave é usada para gerar os blocos de produção. Atualize aqui sempre que a chave mudar.<br>
            Chave atual: <code style="background:var(--surface2);padding:.1rem .5rem;border-radius:4px;font-size:.8rem;color:var(--accent)"><?= $maskedKey ?: 'não definida' ?></code>
          </p>

          <?php if ($apiKeyMsg): ?>
          <div style="background:rgba(45,212,191,.08);border:1px solid rgba(45,212,191,.3);border-radius:8px;padding:.8rem 1rem;margin-bottom:1.2rem;color:var(--ok);font-size:.86rem">
            ✅ <?= htmlspecialchars($apiKeyMsg) ?>
          </div>
          <?php endif; ?>

          <?php if ($apiKeyError): ?>
          <div style="background:rgba(248,113,113,.08);border:1px solid rgba(248,113,113,.3);border-radius:8px;padding:.8rem 1rem;margin-bottom:1.2rem;color:var(--err);font-size:.86rem">
            ⚠ <?= htmlspecialchars($apiKeyError) ?>
          </div>
          <?php endif; ?>

          <form method="POST" action="<?= htmlspecialchars($_SERVER['SCRIPT_NAME']) ?>" id="apikey-form">
            <input type="hidden" name="action" value="save_apikey">
            <div class="field">
              <label>Nova chave de API</label>
              <div style="display:flex;gap:.75rem;align-items:flex-start">
                <input type="password" name="api_key" id="apikey-input"
                       placeholder="sk-ant-api03-..."
                       autocomplete="off"
                       style="flex:1"
                       required>
                <button type="button" onclick="toggleApiKey()"
                        style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--muted);padding:.78rem .9rem;cursor:pointer;flex-shrink:0;font-size:.85rem;transition:border-color .2s"
                        id="toggle-eye">👁</button>
              </div>
              <p style="font-size:.76rem;color:var(--muted);margin-top:.4rem">
                Obtenha em <strong style="color:var(--text)">console.anthropic.com</strong> → API Keys
              </p>
            </div>
            <div style="display:flex;gap:.75rem;flex-wrap:wrap">
              <button type="submit" class="btn btn-sm">💾 Salvar chave</button>
              <button type="button" class="btn btn-sm btn-ghost" onclick="testApiKey()">🔍 Testar conexão</button>
            </div>
          </form>
        </div>

        <!-- Info do sistema -->
        <div class="card">
          <div class="card-title">ℹ️ Informações do sistema</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:.6rem;font-size:.86rem">
            <div style="background:var(--surface2);border-radius:8px;padding:.8rem 1rem">
              <div style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:.3rem">Versão</div>
              <div style="font-weight:600">v<?= APP_VERSION ?></div>
            </div>
            <div style="background:var(--surface2);border-radius:8px;padding:.8rem 1rem">
              <div style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:.3rem">Banco</div>
              <div style="font-weight:600"><?= defined('DB_NAME') ? htmlspecialchars(DB_NAME) : '—' ?></div>
            </div>
            <div style="background:var(--surface2);border-radius:8px;padding:.8rem 1rem">
              <div style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:.3rem">Host DB</div>
              <div style="font-weight:600"><?= defined('DB_HOST') ? htmlspecialchars(DB_HOST) : '—' ?></div>
            </div>
            <div style="background:var(--surface2);border-radius:08px;padding:.8rem 1rem">
              <div style="color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;margin-bottom:.3rem">Subpasta</div>
              <div style="font-weight:600"><?= (defined('APP_SUBPATH') && APP_SUBPATH) ? '/' . htmlspecialchars(APP_SUBPATH) : 'Raiz (/)' ?></div>
            </div>
          </div>
        </div>

        <!-- Links úteis -->
        <div class="card">
          <div class="card-title">🔗 Links úteis</div>
          <div style="display:flex;flex-direction:column;gap:.5rem">
            <a href="/phpmyadmin" target="_blank"
               style="display:flex;align-items:center;gap:.75rem;padding:.8rem 1rem;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--text);text-decoration:none;font-size:.88rem;transition:border-color .2s"
               onmouseover="this.style.borderColor='var(--accent)'" onmouseout="this.style.borderColor='var(--border)'">
              <span style="font-size:1.1rem">🗄️</span>
              <div>
                <div style="font-weight:500">phpMyAdmin</div>
                <div style="font-size:.75rem;color:var(--muted)">Gerenciar banco de dados</div>
              </div>
              <span style="margin-left:auto;color:var(--muted);font-size:.8rem">↗</span>
            </a>
            <a href="https://console.anthropic.com" target="_blank"
               style="display:flex;align-items:center;gap:.75rem;padding:.8rem 1rem;background:var(--surface2);border:1px solid var(--border);border-radius:8px;color:var(--text);text-decoration:none;font-size:.88rem;transition:border-color .2s"
               onmouseover="this.style.borderColor='var(--accent)'" onmouseout="this.style.borderColor='var(--border)'">
              <span style="font-size:1.1rem">🤖</span>
              <div>
                <div style="font-weight:500">Anthropic Console</div>
                <div style="font-size:.75rem;color:var(--muted)">Gerenciar API Keys e uso</div>
              </div>
              <span style="margin-left:auto;color:var(--muted);font-size:.8rem">↗</span>
            </a>
          </div>
        </div>

      </div><!-- panel-settings -->

    </div><!-- .content -->
  </main>
</div><!-- .app -->

<!-- LOADING -->
<div class="loading-overlay" id="loading">
  <div class="spinner"></div>
  <div class="loading-title" id="loading-title">Processando...</div>
  <div class="loading-sub"   id="loading-sub">Aguarde</div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
// ── Estado global ─────────────────────────────────────────────────────────────
const S = {
  roteiro:    '',
  title:      '',
  projectId:  0,
  results:    {},
  done:       new Set()
};

const TOTAL   = 14;
const API_URL = <?= json_encode($apiUrl) ?>;

// ── Navegação ─────────────────────────────────────────────────────────────────
function goPanel(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('panel-' + name)?.classList.add('active');
  const nav = document.querySelector(`[data-panel="${name}"]`);
  if (nav) {
    nav.classList.add('active');
    const clone = nav.cloneNode(true);
    clone.querySelectorAll('.badge,.icon').forEach(x => x.remove());
    document.getElementById('topbar-title').textContent = clone.textContent.trim();
  }
}

// ── Roteiro ───────────────────────────────────────────────────────────────────
function saveRoteiro() {
  const roteiro = document.getElementById('roteiro').value.trim();
  const title   = document.getElementById('proj-title').value.trim() || 'Sem título';
  if (roteiro.length < 50) { toast('Cole um roteiro com pelo menos 50 caracteres.', 'err'); return; }
  S.roteiro = roteiro;
  S.title   = title;
  setBadge('roteiro', '✓');
  document.querySelector('[data-panel="roteiro"]').classList.add('done');
  document.getElementById('btn-run-all').disabled = false;
  toast('Roteiro salvo! Pronto para gerar.', 'ok');
  goPanel('bloco1');
}

// ── Progresso ─────────────────────────────────────────────────────────────────
function updateProgress() {
  const pct = Math.round((S.done.size / TOTAL) * 100);
  document.getElementById('prog-fill').style.width = pct + '%';
  document.getElementById('prog-pct').textContent  = pct + '%';
}

// ── Chamada à API ─────────────────────────────────────────────────────────────
async function api(body) {
  const res  = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ── Prompts dos 14 agentes ────────────────────────────────────────────────────
function buildPrompt(n) {
  const r    = S.roteiro;
  const prev = n > 1 && S.results[n-1] ? `\n\n[BLOCO ${n-1} GERADO]\n${S.results[n-1]}` : '';

  const base = `Você é um agente especialista em produção de conteúdo YouTube faceless para o canal "Tati Indicando" (nicho: eletrodomésticos, afiliados, ranking/comparação).

REGRAS ABSOLUTAS:
- Tudo deve nascer do roteiro abaixo — zero invenção técnica
- Não criar benefício que o roteiro não sustenta
- Não citar lojas na narração
- Não usar abertura clichê nem "fala pessoal"
- Não revelar o 1º lugar antes da hora
- Cada cena deve espelhar um trecho do roteiro
- Tom: natural, direto, confiável, comercial e humano

ROTEIRO:
${r}${prev}

`;

  const tasks = {
    1:  base + `TAREFA — BLOCO 1: MAPA DO ROTEIRO
Extraia de forma estruturada:
- Tema central e produtos em destaque (com ordem de aparição)
- Estrutura: intro / desenvolvimento / encerramento
- Momentos-chave de persuasão
- Palavras e frases de intenção de compra presentes no roteiro
- Tom identificado
- Duração estimada da narração`,

    2:  base + `TAREFA — BLOCO 2: VERDADE-BASE
Liste APENAS fatos que o roteiro sustenta:
- Benefícios mencionados explicitamente
- Diferenciais citados
- Comparações presentes
- Dados ou números mencionados
- Problemas que os produtos resolvem
- O que NÃO está no roteiro (alertas de invenção a evitar)`,

    3:  base + `TAREFA — BLOCO 3: ÂNGULO ESTRATÉGICO
Defina:
- Intenção de busca do espectador (Search Intent)
- Gatilho de clique principal
- Estratégia de retenção (o que mantém o viewer até o fim)
- Momento de decisão de compra (onde o CTA é mais forte)
- Posicionamento do canal neste vídeo
- Diferencial competitivo vs. outros vídeos do nicho`,

    4:  base + `TAREFA — BLOCO 4: ROTEIRO OTIMIZADO
Reescreva o roteiro mantendo 100% da essência:
- Melhore ritmo e fluidez
- Reforce CTAs de forma natural
- Elimine redundâncias
- Adicione ganchos de retenção nas viradas de cena
- Garanta que o 1º lugar seja revelado só no final
- Máximo 6 minutos de narração`,

    5:  base + `TAREFA — BLOCO 5: STORYBOARD 3×3
Divida em 9 a 12 cenas. Para cada cena:
- Número e título
- Trecho do roteiro correspondente
- Descrição do que aparece na tela
- Objetivo emocional da cena
- Duração estimada`,

    6:  base + `TAREFA — BLOCO 6: SHOTLIST DETALHADA
Para cada cena do storyboard:
- Tipo de plano (close, detalhe, ambiente, packshot)
- Ângulo e posição de câmera
- Ação principal do produto
- Iluminação sugerida
- Duração em segundos
- Notas de direção`,

    7:  base + `TAREFA — BLOCO 7: PROMPTS DE IMAGEM IA
Para cada cena (9-12), entregue:
- Trecho do roteiro vinculado
- Objetivo visual
- Prompt completo em inglês (hiper-realista, sem texto na imagem, sem logotipos inventados, sem CGI artificial)
- Iluminação | Lente | Enquadramento | Composição
- Frame inicial e frame final
- Negative prompt`,

    8:  base + `TAREFA — BLOCO 8: PROMPTS DE VÍDEO IA
Para cada cena:
- Duração | Intenção visual | Movimento de câmera
- Ação do produto
- Keyframe inicial | Keyframe intermediário | Keyframe final
- Transição para próxima cena
- Prompt completo em inglês
- Negative prompt`,

    9:  base + `TAREFA — BLOCO 9: OVERLAYS DE BENEFÍCIOS
Para cada cena:
- Texto principal do overlay (máx 5 palavras)
- Subtexto se necessário (máx 8 palavras)
- Momento de entrada (ex: "aos 0:45")
- Duração em segundos
- Estilo visual (cor, posição na tela)
IMPORTANTE: baseie-se APENAS no que o roteiro sustenta`,

    10: base + `TAREFA — BLOCO 10: TÍTULOS
Crie exatamente 20 títulos divididos em 4 categorias:
- 5 títulos Search (palavras-chave diretas, comprador quente)
- 5 títulos Browse (curiosidade, emoção, formato)
- 5 títulos Comparação (ranking, produto vs produto)
- 5 títulos Decisão de compra (urgência, certeza, CTR)
Máx 60 caracteres cada. Sem repetir ideias.`,

    11: base + `TAREFA — BLOCO 11: THUMBNAIL
Entregue:
- Conceito criativo
- Layout descrito (o que aparece em cada zona)
- Psicologia de clique utilizada
- Texto curto para a thumbnail (máx 4 palavras)
- Prompt completo em inglês (hiper-realista, produto real, sem distorções)
- 3 variações de texto alternativas`,

    12: base + `TAREFA — BLOCO 12: DESCRIÇÃO SEO
Estrutura completa:
- CTA inicial (2-3 linhas)
- Timestamps de cada cena
- 3º lugar: produto + links [LINK ML] [LINK MAGALU] [LINK SHOPEE]
- 2º lugar: mesmo formato
- 1º lugar: mesmo formato
- Link do vídeo (placeholder)
- Resumo do vídeo (3-4 linhas)
- 20 palavras-chave long-tail separadas por vírgula
- 3 hashtags finais`,

    13: base + `TAREFA — BLOCO 13: ABA COMUNIDADE
Entregue:
- Ideia de carrossel 1:1 (quantidade de slides e tema de cada um)
- Prompts de imagem em inglês para cada slide
- Legenda completa do post
- CTA final da legenda
- 5 palavras-chave relevantes
- 3 hashtags`,

    14: base + `TAREFA — BLOCO 14: AUDITORIA FINAL
Verifique cada item com ✅ (aprovado) ou ⚠️ (atenção) + justificativa:
1. Tudo nasceu do roteiro?
2. Há invenção técnica não sustentada?
3. Cenas conectadas ao roteiro?
4. Títulos prometem o que o vídeo entrega?
5. Thumbnail não repete o título?
6. Descrição otimizada para SEO?
7. CTAs estão naturais?
8. Prompts fiéis ao roteiro?
9. Decisão de compra clara para o espectador?
10. 1º lugar revelado só no final?

Finalize com: nota de 0 a 100 e recomendação geral.`
  };

  return tasks[n] || base + `Execute o bloco ${n}.`;
}

// ── Gerar um bloco ────────────────────────────────────────────────────────────
async function runBloco(n) {
  if (!S.roteiro) { toast('Salve o roteiro primeiro!', 'err'); goPanel('roteiro'); return; }
  showLoading(`Bloco ${n} — Gerando...`, 'A IA está processando — aguarde');
  try {
    const data = await api({ prompt: buildPrompt(n) });
    S.results[n] = data.result;
    S.done.add(n);
    showResult(n, data.result);
    updateProgress();
    setBadge('bloco' + n, '✓', 'done');
    toast(`Bloco ${n} gerado!`, 'ok');
  } catch (e) {
    setBadge('bloco' + n, '!', 'err');
    toast('Erro: ' + e.message, 'err');
  } finally {
    hideLoading();
  }
}

// ── Gerar todos ───────────────────────────────────────────────────────────────
async function runAll() {
  if (!S.roteiro) { toast('Salve o roteiro primeiro!', 'err'); goPanel('roteiro'); return; }
  const btn = document.getElementById('btn-run-all');
  btn.disabled = true;
  const names = ['Mapa','Verdade-Base','Ângulo','Roteiro Otimizado','Storyboard',
                 'Shotlist','Prompts Imagem','Prompts Vídeo','Overlays','Títulos',
                 'Thumbnail','Descrição SEO','Aba Comunidade','Auditoria'];
  for (let n = 1; n <= TOTAL; n++) {
    goPanel('bloco' + n);
    showLoading(`Bloco ${n} de ${TOTAL}`, `Gerando: ${names[n-1]}`);
    try {
      const data = await api({ prompt: buildPrompt(n) });
      S.results[n] = data.result;
      S.done.add(n);
      showResult(n, data.result);
      updateProgress();
      setBadge('bloco' + n, '✓', 'done');
    } catch (e) {
      setBadge('bloco' + n, '!', 'err');
      toast(`Bloco ${n} falhou: ${e.message}`, 'err');
    }
  }
  hideLoading();
  btn.disabled = false;
  toast('🎉 Todos os blocos gerados!', 'ok');
}

// ── Salvar projeto no banco ───────────────────────────────────────────────────
async function saveProject() {
  if (!S.roteiro) { toast('Nada para salvar ainda.', 'err'); return; }
  try {
    const data = await api({
      action:     'save_project',
      project_id: S.projectId,
      titulo:     S.title || document.getElementById('proj-title')?.value || 'Sem título',
      roteiro:    S.roteiro,
      resultados: S.results
    });
    if (data.ok) {
      S.projectId = data.project_id;
      toast('Projeto salvo!', 'ok');
    } else {
      toast('Erro ao salvar: ' + (data.error || 'Desconhecido'), 'err');
    }
  } catch (e) {
    toast('Erro ao salvar: ' + e.message, 'err');
  }
}

// ── Listar projetos ───────────────────────────────────────────────────────────
async function loadProjects() {
  const el = document.getElementById('projects-list');
  el.innerHTML = '<div class="empty-state">Carregando...</div>';
  try {
    const data = await api({ action: 'list_projects' });
    if (!data.projects?.length) {
      el.innerHTML = '<div class="card"><div class="empty-state">Nenhum projeto salvo ainda.</div></div>';
      return;
    }
    el.innerHTML = data.projects.map(p => `
      <div class="project-item">
        <div>
          <div class="pi-title">${esc(p.titulo)}</div>
          <div class="pi-date">${p.criado_em}</div>
        </div>
        <div class="pi-actions">
          <button class="btn btn-sm btn-ghost" onclick="loadProject(${p.id})">Abrir</button>
          <button class="pi-del" onclick="deleteProject(${p.id},this)" title="Deletar">✕</button>
        </div>
      </div>`).join('');
  } catch (e) {
    el.innerHTML = `<div class="card"><div class="empty-state" style="color:var(--err)">Erro: ${esc(e.message)}</div></div>`;
  }
}

async function loadProject(id) {
  showLoading('Carregando projeto...', 'Aguarde');
  try {
    const data = await api({ action: 'load_project', project_id: id });
    if (data.error) throw new Error(data.error);
    const p = data.project;
    S.roteiro   = p.roteiro    || '';
    S.title     = p.titulo     || '';
    S.projectId = p.id;
    S.results   = p.resultados || {};
    S.done      = new Set(Object.keys(S.results).map(Number).filter(n => S.results[n]));

    const rEl = document.getElementById('roteiro');
    const tEl = document.getElementById('proj-title');
    if (rEl) rEl.value = S.roteiro;
    if (tEl) tEl.value = S.title;

    for (let n = 1; n <= TOTAL; n++) {
      if (S.results[n]) { showResult(n, S.results[n]); setBadge('bloco'+n,'✓','done'); }
    }
    if (S.roteiro) {
      setBadge('roteiro','✓');
      document.querySelector('[data-panel="roteiro"]').classList.add('done');
      document.getElementById('btn-run-all').disabled = false;
    }
    updateProgress();
    toast('Projeto carregado!', 'ok');
    goPanel('welcome');
  } catch (e) {
    toast('Erro: ' + e.message, 'err');
  } finally {
    hideLoading();
  }
}

async function deleteProject(id, btn) {
  if (!confirm('Deletar este projeto permanentemente?')) return;
  btn.disabled = true;
  try {
    await api({ action: 'delete_project', project_id: id });
    loadProjects();
    toast('Projeto deletado.', 'ok');
  } catch (e) {
    toast('Erro: ' + e.message, 'err');
    btn.disabled = false;
  }
}

// ── Exibir resultado ──────────────────────────────────────────────────────────
function showResult(n, text) {
  document.getElementById('content-bloco'+n).textContent = text;
  document.getElementById('result-bloco'+n).style.display = 'block';
  document.getElementById('empty-bloco'+n).style.display  = 'none';
}

// ── Copiar resultado ──────────────────────────────────────────────────────────
function copyBloco(n) {
  const text = document.getElementById('content-bloco'+n).textContent;
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(text).then(() => toast('Copiado!','ok')).catch(() => fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}
function fallbackCopy(text) {
  const ta = Object.assign(document.createElement('textarea'),
    { value: text, style: 'position:fixed;opacity:0' });
  document.body.appendChild(ta);
  ta.select();
  document.execCommand('copy');
  document.body.removeChild(ta);
  toast('Copiado!','ok');
}

// ── Badge / estado da sidebar ─────────────────────────────────────────────────
function setBadge(id, text, cls = '') {
  const badge = document.getElementById('badge-' + id);
  const nav   = document.querySelector(`[data-panel="${id}"]`);
  if (badge) badge.textContent = text;
  if (nav && cls) { nav.classList.remove('done','err'); nav.classList.add(cls); }
}

// ── Reset ─────────────────────────────────────────────────────────────────────
function resetAll() {
  if (!confirm('Limpar tudo e começar um novo projeto?')) return;
  S.roteiro = ''; S.title = ''; S.projectId = 0; S.results = {}; S.done = new Set();
  const rEl = document.getElementById('roteiro');
  const tEl = document.getElementById('proj-title');
  if (rEl) rEl.value = '';
  if (tEl) tEl.value = '';
  for (let n = 1; n <= TOTAL; n++) {
    document.getElementById('result-bloco'+n).style.display = 'none';
    document.getElementById('empty-bloco'+n).style.display  = 'block';
    document.getElementById('content-bloco'+n).textContent  = '';
    setBadge('bloco'+n, '—');
    document.querySelector(`[data-panel="bloco${n}"]`).classList.remove('done','err');
  }
  setBadge('roteiro','—');
  document.querySelector('[data-panel="roteiro"]').classList.remove('done');
  document.getElementById('btn-run-all').disabled = true;
  updateProgress();
  goPanel('welcome');
}

// ── Loading / Toast ───────────────────────────────────────────────────────────
function showLoading(title, sub) {
  document.getElementById('loading-title').textContent = title;
  document.getElementById('loading-sub').textContent   = sub;
  document.getElementById('loading').classList.add('show');
}
function hideLoading() {
  document.getElementById('loading').classList.remove('show');
}
let _toastTimer;
function toast(msg, type = 'ok') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${type} show`;
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => el.classList.remove('show'), 3500);
}
function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Abre painel via URL (?panel=settings) ────────────────────────────────────
(function() {
  const panel = <?= json_encode($openPanel) ?>;
  if (panel) goPanel(panel);
})();

// ── Configurações — API Key ───────────────────────────────────────────────────
function toggleApiKey() {
  const inp = document.getElementById('apikey-input');
  const eye = document.getElementById('toggle-eye');
  if (inp.type === 'password') {
    inp.type = 'text';
    eye.textContent = '🙈';
  } else {
    inp.type = 'password';
    eye.textContent = '👁';
  }
}

async function testApiKey() {
  const key = document.getElementById('apikey-input').value.trim();
  if (!key) { toast('Cole a chave antes de testar.', 'err'); return; }
  showLoading('Testando chave de API...', 'Enviando requisição à Anthropic');
  try {
    // Testa com um prompt mínimo usando a chave informada
    const res  = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'test_apikey', api_key: key })
    });
    const data = await res.json().catch(() => ({}));
    if (data.ok) {
      toast('✅ Chave válida e funcionando!', 'ok');
    } else {
      toast('❌ ' + (data.error || 'Chave inválida ou sem créditos.'), 'err');
    }
  } catch (e) {
    toast('Erro ao testar: ' + e.message, 'err');
  } finally {
    hideLoading();
  }
}
</script>
<?php endif; ?>
</body>
</html>
