<?php
// Este arquivo é um exemplo — gerado automaticamente pelo install.sh
// NÃO use este arquivo. O install.sh cria o config.php real.

define('ANTHROPIC_API_KEY', 'sk-ant-api03-...');
define('APP_PASSWORD',      'hash_gerado_pelo_install');
define('APP_SUBPATH',       '');
define('APP_VERSION',       '2.0.0');

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'tati_studio');
define('DB_USER', 'tati_user');
define('DB_PASS', 'senha_gerada_automaticamente');

define('INSTALLED', true);
