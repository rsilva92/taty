# 🎬 Tati Indicando Studio v2.0.0

Sistema multiagente de produção de conteúdo YouTube Faceless.
Cole um roteiro e gere automaticamente os 14 blocos de produção.

---

## Requisitos do servidor

- Ubuntu 20.04 / 22.04 / 24.04 ou Debian 11 / 12
- Acesso root via SSH
- Conexão com a internet

> O install.sh instala tudo automaticamente: Apache, PHP 8.2, MySQL e todas as extensões.

---

## Instalação

```bash
# 1. Envie os arquivos para o servidor via FTP ou SCP
scp -r tati-studio/ usuario@seuip:/var/www/

# 2. Conecte via SSH
ssh usuario@seuip

# 3. Execute o instalador
cd /var/www/tati-studio
sudo bash install.sh

# 4. Siga as perguntas interativas e aguarde ~3 minutos
```

---

## Estrutura de arquivos

```
/
├── install.sh              ← Execute este arquivo para instalar
├── index.php               ← App principal
├── api/
│   ├── agent.php           ← Agente que chama a API Anthropic
│   └── .htaccess           ← Protege a rota da API
├── includes/
│   └── config.example.php  ← Referência (o real é gerado pelo install.sh)
└── README.md
```

O `install.sh` cria automaticamente:
- `includes/config.php` — configuração com API key, senha e credenciais do banco
- `.htaccess` — roteamento e segurança
- Pastas: `cache/`, `logs/`, `assets/`
- Banco de dados e tabelas MySQL

---

## Após instalar

- Acesse `http://seudominio.com` e faça login com a senha que você criou
- As credenciais do banco ficam salvas em `/root/tati-studio-credenciais.txt`
- Para HTTPS: `certbot --apache -d seudominio.com`
