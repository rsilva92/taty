#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  TATI INDICANDO STUDIO — INSTALADOR AUTOMÁTICO v2.0.0
#  Compatível: Ubuntu 20.04 / 22.04 / 24.04 | Debian 11 / 12
#  Instala: Apache2 + PHP 8.2 + MySQL 8 + extensões + configura tudo
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail
IFS=$'\n\t'

# ── Cores ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

info()    { echo -e "${CYAN}${BOLD}[INFO]${RESET}  $*"; }
ok()      { echo -e "${GREEN}${BOLD}[ OK ]${RESET}  $*"; }
warn()    { echo -e "${YELLOW}${BOLD}[AVISO]${RESET} $*"; }
step()    { echo -e "\n${BLUE}${BOLD}━━━  $*  ━━━${RESET}"; }
die()     { echo -e "${RED}${BOLD}[ERRO]${RESET}  $*"; exit 1; }

# ── Gerar senha aleatória segura ──────────────────────────────────────────────
gen_pass() {
    local len="${1:-24}"
    tr -dc 'A-Za-z0-9' < /dev/urandom | head -c "$len"
    echo ""
}

# ── Banner ────────────────────────────────────────────────────────────────────
banner() {
    clear
    echo -e "${ACCENT:-}"
    cat << 'EOF'
  ████████╗ █████╗ ████████╗██╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗
     ██║   ██╔══██╗╚══██╔══╝██║    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗
     ██║   ███████║   ██║   ██║    ███████╗   ██║   ██║   ██║██║  ██║██║██║   ██║
     ██║   ██╔══██║   ██║   ██║    ╚════██║   ██║   ██║   ██║██║  ██║██║██║   ██║
     ██║   ██║  ██║   ██║   ██║    ███████║   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝
     ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚═╝   ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝
EOF
    echo ""
    echo -e "  ${BOLD}TATI INDICANDO — Studio de Produção YouTube Faceless${RESET}"
    echo -e "  Instalador v2.0.0  |  Apache + PHP 8.2 + MySQL 8"
    echo ""
}

# ── Verificações iniciais ─────────────────────────────────────────────────────
check_root() {
    [[ $EUID -eq 0 ]] || die "Execute como root: sudo bash install.sh"
}

check_os() {
    [[ -f /etc/os-release ]] || die "Sistema operacional não identificado."
    # shellcheck source=/dev/null
    source /etc/os-release
    case "$ID" in
        ubuntu|debian) ok "Sistema: $PRETTY_NAME" ;;
        *) die "Suportado apenas Ubuntu e Debian. Detectado: ${PRETTY_NAME:-desconhecido}" ;;
    esac
}

check_internet() {
    info "Verificando conexão com a internet..."
    curl -s --max-time 8 -o /dev/null https://google.com \
        || die "Sem acesso à internet. Verifique a conexão antes de continuar."
    ok "Conexão com a internet OK"
}

# ── Coleta de configurações ───────────────────────────────────────────────────
collect_config() {
    step "CONFIGURAÇÃO DA INSTALAÇÃO"
    echo ""

    # ── Local de instalação ───────────────────────────────────────────────────
    echo -e "${BOLD}Onde instalar o sistema?${RESET}"
    echo "  1) Raiz do domínio  — seusite.com/"
    echo "  2) Subpasta         — seusite.com/studio"
    echo ""
    read -rp "  Escolha [1/2, padrão=1]: " _type
    _type="${_type:-1}"

    SUBPATH=""
    WEBROOT="/var/www/html"

    if [[ "$_type" == "2" ]]; then
        while true; do
            read -rp "  Nome da subpasta (ex: studio): " SUBPATH
            SUBPATH=$(echo "$SUBPATH" | tr -dc 'A-Za-z0-9_-')
            [[ -n "$SUBPATH" ]] && break
            warn "Nome inválido. Use apenas letras, números e hífen."
        done
        WEBROOT="/var/www/html/${SUBPATH}"
    fi

    # ── Domínio ───────────────────────────────────────────────────────────────
    echo ""
    echo -e "${BOLD}Domínio ou IP do servidor${RESET}"
    read -rp "  Ex: seusite.com ou 123.123.123.123 (Enter = localhost): " SERVER_NAME
    SERVER_NAME="${SERVER_NAME:-localhost}"

    # ── Chave de API ──────────────────────────────────────────────────────────
    echo ""
    echo -e "${BOLD}Chave de API da Anthropic${RESET}"
    echo -e "  ${CYAN}Obtenha em: https://console.anthropic.com → API Keys${RESET}"
    while true; do
        read -rsp "  Cole sua chave (sk-ant-...): " API_KEY
        echo ""
        [[ ${#API_KEY} -ge 20 ]] && break
        warn "Chave muito curta. Verifique e tente novamente."
    done

    # ── Senha do Studio ───────────────────────────────────────────────────────
    echo ""
    echo -e "${BOLD}Senha de acesso ao Studio${RESET}"
    while true; do
        read -rsp "  Crie uma senha (mínimo 8 caracteres): " APP_PASS
        echo ""
        if [[ ${#APP_PASS} -lt 8 ]]; then
            warn "Senha muito curta. Mínimo 8 caracteres."; continue
        fi
        read -rsp "  Confirme a senha: " APP_PASS2
        echo ""
        [[ "$APP_PASS" == "$APP_PASS2" ]] && break
        warn "Senhas não coincidem. Tente novamente."
    done

    # ── MySQL ─────────────────────────────────────────────────────────────────
    echo ""
    echo -e "${BOLD}Banco de dados (MySQL)${RESET}"
    read -rsp "  Senha root do MySQL (Enter = gerar automaticamente): " MYSQL_ROOT_PASS
    echo ""
    if [[ -z "$MYSQL_ROOT_PASS" ]]; then
        MYSQL_ROOT_PASS=$(gen_pass 24)
        echo ""
        warn "Senha root gerada: ${BOLD}${MYSQL_ROOT_PASS}${RESET}"
        warn "Anote essa senha antes de continuar!"
        echo ""
        read -rp "  Pressione Enter para continuar..."
    fi

    DB_NAME="tati_studio"
    DB_USER="tati_user"
    DB_PASS=$(gen_pass 24)

    # ── Confirmação ───────────────────────────────────────────────────────────
    echo ""
    echo -e "${BOLD}━━━ RESUMO ━━━${RESET}"
    echo -e "  Pasta:      ${CYAN}${WEBROOT}${RESET}"
    echo -e "  Domínio:    ${CYAN}${SERVER_NAME}${RESET}"
    echo -e "  Banco:      ${CYAN}${DB_NAME}${RESET}"
    echo -e "  Usuário DB: ${CYAN}${DB_USER}${RESET}"
    echo ""
    read -rp "  Confirmar instalação? [s/N]: " CONFIRM
    [[ "${CONFIRM,,}" == "s" ]] || die "Instalação cancelada."
}

# ── Instalar pacotes ──────────────────────────────────────────────────────────
# Função auxiliar: roda apt-get com saída visível e trata erros
apt_install() {
    local desc="$1"; shift
    info "Instalando: ${desc}..."
    if ! DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"; then
        die "Falha ao instalar: ${desc}. Verifique a conexão e tente novamente."
    fi
    ok "${desc} instalado"
}

install_packages() {
    step "INSTALANDO PACOTES"

    # ── Atualiza lista ────────────────────────────────────────────────────────
    info "Atualizando lista de pacotes..."
    apt-get update || die "Falha no apt-get update. Verifique a conexão com a internet."
    ok "Lista de pacotes atualizada"

    # ── Dependências base ─────────────────────────────────────────────────────
    apt_install "Dependências base" \
        software-properties-common curl wget unzip rsync \
        gnupg2 lsb-release ca-certificates apt-transport-https

    # ── Apache2 ───────────────────────────────────────────────────────────────
    apt_install "Apache2" apache2

    # ── Repositório PHP (versão mais atual disponível) ────────────────────────
    # shellcheck source=/dev/null
    source /etc/os-release
    info "Adicionando repositório PHP atualizado..."

    if [[ "$ID" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php \
            || die "Falha ao adicionar repositório ondrej/php."
    else
        # Debian: método moderno sem apt-key (deprecated no Debian 12+)
        curl -fsSo /usr/share/keyrings/deb.sury.org-php.gpg \
            https://packages.sury.org/php/apt.gpg \
            || die "Falha ao baixar chave GPG do repositório PHP."
        echo "deb [signed-by=/usr/share/keyrings/deb.sury.org-php.gpg] \
https://packages.sury.org/php/ $(lsb_release -sc) main" \
            > /etc/apt/sources.list.d/php-sury.list
    fi

    info "Atualizando lista após novo repositório..."
    apt-get update || die "Falha no apt-get update após adicionar repositório PHP."
    ok "Repositório PHP adicionado"

    # Detecta versão mais alta do PHP 8.x ou 9.x disponível
    PHP_VER=$(apt-cache search --names-only '^php[0-9]+\.[0-9]+$' \
              | grep -oP 'php\K[89]\.[0-9]+' \
              | sort -V | tail -1)
    if [[ -z "$PHP_VER" ]]; then
        warn "Não foi possível detectar versão do PHP. Usando 8.2 como padrão."
        PHP_VER="8.2"
    fi
    ok "Versão PHP detectada: ${PHP_VER}"

    # json e openssl são built-in desde PHP 8.0 — não existem como pacotes separados
    apt_install "PHP ${PHP_VER} + extensões" \
        "php${PHP_VER}"               \
        "php${PHP_VER}-cli"           \
        "php${PHP_VER}-mysql"         \
        "php${PHP_VER}-curl"          \
        "php${PHP_VER}-mbstring"      \
        "php${PHP_VER}-xml"           \
        "php${PHP_VER}-zip"           \
        "php${PHP_VER}-gd"            \
        "php${PHP_VER}-intl"          \
        "libapache2-mod-php${PHP_VER}"

    # ── MySQL ─────────────────────────────────────────────────────────────────
    apt_install "MySQL Server" mysql-server mysql-client
}

# ── Configurar MySQL ──────────────────────────────────────────────────────────
configure_mysql() {
    step "CONFIGURANDO MYSQL"

    info "Iniciando serviço MySQL..."
    systemctl enable mysql > /dev/null 2>&1
    systemctl start  mysql

    # Ubuntu 22+/24 usa auth_socket por padrão — tenta via socket sem senha primeiro
    info "Configurando senha root..."
    if mysql -u root -e "SELECT 1" > /dev/null 2>&1; then
        # Acesso via socket sem senha (Ubuntu recente)
        mysql -u root <<SQL
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
FLUSH PRIVILEGES;
SQL
    else
        # Tenta com senha vazia
        mysql -u root -p'' --connect-expired-password 2>/dev/null <<SQL || true
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '${MYSQL_ROOT_PASS}';
FLUSH PRIVILEGES;
SQL
    fi
    ok "Senha root configurada"

    info "Criando banco e usuário..."
    mysql -u root -p"${MYSQL_ROOT_PASS}" <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

DROP USER IF EXISTS '${DB_USER}'@'localhost';
CREATE USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQL

    info "Criando tabelas..."
    mysql -u "${DB_USER}" -p"${DB_PASS}" "${DB_NAME}" <<SQL
CREATE TABLE IF NOT EXISTS projetos (
    id            INT          AUTO_INCREMENT PRIMARY KEY,
    titulo        VARCHAR(255) NOT NULL DEFAULT 'Sem titulo',
    roteiro       LONGTEXT,
    resultados    JSON,
    criado_em     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_criado (criado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessoes_log (
    id        INT         AUTO_INCREMENT PRIMARY KEY,
    ip        VARCHAR(45),
    acao      VARCHAR(100),
    criado_em TIMESTAMP   DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL
    ok "Banco '${DB_NAME}' e tabelas criados"
}

# ── Configurar Apache ─────────────────────────────────────────────────────────
configure_apache() {
    step "CONFIGURANDO APACHE"

    info "Habilitando módulos..."
    a2enmod rewrite headers deflate expires > /dev/null 2>&1
    a2enmod "php${PHP_VER}"                > /dev/null 2>&1

    info "Criando VirtualHost..."
    cat > /etc/apache2/sites-available/tati-studio.conf <<VHOST
<VirtualHost *:80>
    ServerName ${SERVER_NAME}
    DocumentRoot /var/www/html

    <Directory "/var/www/html">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    Header always set X-Content-Type-Options  "nosniff"
    Header always set X-Frame-Options         "SAMEORIGIN"
    Header always set X-XSS-Protection        "1; mode=block"
    Header always set Referrer-Policy         "strict-origin-when-cross-origin"
    Header always unset X-Powered-By

    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json
    </IfModule>

    <IfModule mod_expires.c>
        ExpiresActive On
        ExpiresByType text/css               "access plus 1 month"
        ExpiresByType application/javascript "access plus 1 month"
    </IfModule>

    ErrorLog  \${APACHE_LOG_DIR}/tati-studio-error.log
    CustomLog \${APACHE_LOG_DIR}/tati-studio-access.log combined
</VirtualHost>
VHOST

    a2ensite  tati-studio.conf > /dev/null 2>&1
    a2dissite 000-default.conf > /dev/null 2>&1 || true

    info "Ajustando php.ini..."
    PHP_INI="/etc/php/${PHP_VER}/apache2/php.ini"
    if [[ -f "$PHP_INI" ]]; then
        sed -i 's/^upload_max_filesize.*/upload_max_filesize = 32M/'      "$PHP_INI"
        sed -i 's/^post_max_size.*/post_max_size = 32M/'                  "$PHP_INI"
        sed -i 's/^max_execution_time.*/max_execution_time = 120/'        "$PHP_INI"
        sed -i 's/^memory_limit.*/memory_limit = 256M/'                   "$PHP_INI"
        sed -i 's/^;date\.timezone.*/date.timezone = America\/Sao_Paulo/' "$PHP_INI"
        sed -i 's/^display_errors.*/display_errors = Off/'                "$PHP_INI"
        sed -i 's/^expose_php.*/expose_php = Off/'                        "$PHP_INI"
    fi

    systemctl enable apache2 > /dev/null 2>&1
    systemctl restart apache2
    ok "Apache configurado e reiniciado"
}

# ── Deploy dos arquivos ───────────────────────────────────────────────────────
deploy_files() {
    step "COPIANDO ARQUIVOS"

    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    mkdir -p "$WEBROOT"

    info "Copiando arquivos para ${WEBROOT}..."
    if command -v rsync &> /dev/null; then
        rsync -a \
            --exclude='install.sh' \
            --exclude='*.zip'      \
            --exclude='*.md'       \
            "${SCRIPT_DIR}/" "${WEBROOT}/"
    else
        cp -rf "${SCRIPT_DIR}/." "${WEBROOT}/"
        rm -f "${WEBROOT}/install.sh" "${WEBROOT}"/*.zip "${WEBROOT}"/*.md
    fi

    # Garante estrutura de pastas
    mkdir -p \
        "${WEBROOT}/includes" \
        "${WEBROOT}/api"      \
        "${WEBROOT}/cache"    \
        "${WEBROOT}/logs"     \
        "${WEBROOT}/assets/css" \
        "${WEBROOT}/assets/js"

    # Gera hash da senha do Studio
    APP_PASS_HASH=$(php${PHP_VER} -r "echo password_hash('${APP_PASS}', PASSWORD_DEFAULT);" 2>/dev/null \
        || php -r "echo password_hash('${APP_PASS}', PASSWORD_DEFAULT);")
    [[ -z "$APP_PASS_HASH" ]] && die "Falha ao gerar hash da senha. PHP instalado?"

    info "Gerando config.php..."
    cat > "${WEBROOT}/includes/config.php" <<PHP
<?php
// Gerado automaticamente pelo install.sh
// Data: $(date '+%d/%m/%Y %H:%M:%S')
// NÃO edite manualmente.

define('ANTHROPIC_API_KEY', '${API_KEY}');
define('APP_PASSWORD',      '${APP_PASS_HASH}');
define('APP_SUBPATH',       '${SUBPATH}');
define('APP_VERSION',       '2.0.0');

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', '${DB_NAME}');
define('DB_USER', '${DB_USER}');
define('DB_PASS', '${DB_PASS}');

define('INSTALLED', true);
PHP

    info "Gerando .htaccess..."
    BASE="${SUBPATH:+/$SUBPATH}"
    cat > "${WEBROOT}/.htaccess" <<HTA
Options -Indexes

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase ${BASE:-/}

  # Serve arquivos e pastas físicas diretamente
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d

  # Nunca redireciona a pasta api/
  RewriteRule ^api/ - [L]

  # Tudo mais vai para o index.php
  RewriteRule ^(.*)$ index.php?route=\$1 [QSA,L]
</IfModule>

# Bloqueia acesso direto a arquivos sensíveis
<FilesMatch "(config\.php|install\.sh|\.env|\.git)$">
  Order Allow,Deny
  Deny from all
</FilesMatch>

AddDefaultCharset UTF-8
HTA

    info "Ajustando permissões..."
    chown -R www-data:www-data "$WEBROOT"
    find "$WEBROOT" -type d -exec chmod 755 {} \;
    find "$WEBROOT" -type f -exec chmod 644 {} \;
    chmod 600 "${WEBROOT}/includes/config.php"
    chmod 755 "${WEBROOT}/cache" "${WEBROOT}/logs"

    ok "Arquivos implantados e permissões configuradas"
}


# ── phpMyAdmin ────────────────────────────────────────────────────────────────
install_phpmyadmin() {
    step "INSTALANDO phpMyAdmin"

    PMA_VER="5.2.1"
    PMA_DIR="/var/www/html/phpmyadmin"
    PMA_URL="https://files.phpmyadmin.net/phpMyAdmin/${PMA_VER}/phpMyAdmin-${PMA_VER}-all-languages.tar.gz"
    PMA_TMP="/tmp/phpmyadmin.tar.gz"

    info "Baixando phpMyAdmin ${PMA_VER}..."
    curl -fsSL "$PMA_URL" -o "$PMA_TMP" \
        || die "Falha ao baixar phpMyAdmin. Verifique a conexão."
    ok "Download concluído"

    info "Extraindo arquivos..."
    tar -xzf "$PMA_TMP" -C /tmp/
    rm -rf "$PMA_DIR"
    mv "/tmp/phpMyAdmin-${PMA_VER}-all-languages" "$PMA_DIR"
    rm -f "$PMA_TMP"
    ok "Arquivos extraídos em ${PMA_DIR}"

    # Gera chave secreta aleatória (32 chars)
    PMA_SECRET=$(tr -dc 'A-Za-z0-9!@#$%^&*' < /dev/urandom | head -c 32)

    info "Criando configuração do phpMyAdmin..."
    mkdir -p "${PMA_DIR}/tmp"
    cat > "${PMA_DIR}/config.inc.php" <<PMACFG
<?php
// phpMyAdmin Configuration — gerado pelo install.sh
declare(strict_types=1);

\$cfg['blowfish_secret'] = '${PMA_SECRET}';

\$i = 0;
\$i++;

// Conexão local
\$cfg['Servers'][\$i]['auth_type']       = 'cookie';
\$cfg['Servers'][\$i]['host']            = '127.0.0.1';
\$cfg['Servers'][\$i]['compress']        = false;
\$cfg['Servers'][\$i]['AllowNoPassword'] = false;

// Pasta temporária
\$cfg['TempDir'] = '${PMA_DIR}/tmp/';

// Segurança
\$cfg['CheckConfigurationPermissions'] = false;
PMACFG

    # Permissões
    chown -R www-data:www-data "$PMA_DIR"
    find "$PMA_DIR" -type d -exec chmod 755 {} \;
    find "$PMA_DIR" -type f -exec chmod 644 {} \;
    chmod 700 "${PMA_DIR}/tmp"
    chmod 600 "${PMA_DIR}/config.inc.php"

    # Cria usuário phpMyAdmin no MySQL com acesso controlado
    mysql -u root -p"${MYSQL_ROOT_PASS}" <<SQL 2>/dev/null || true
CREATE USER IF NOT EXISTS 'phpmyadmin'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO 'phpmyadmin'@'localhost';
GRANT SELECT ON mysql.user TO 'phpmyadmin'@'localhost';
FLUSH PRIVILEGES;
SQL

    ok "phpMyAdmin instalado em: http://${SERVER_NAME}/phpmyadmin"
}

# ── Firewall ──────────────────────────────────────────────────────────────────
configure_firewall() {
    step "FIREWALL"
    if command -v ufw &> /dev/null; then
        ufw allow 22/tcp  > /dev/null 2>&1 || true
        ufw allow 80/tcp  > /dev/null 2>&1 || true
        ufw allow 443/tcp > /dev/null 2>&1 || true
        ufw --force enable > /dev/null 2>&1 || true
        ok "UFW: portas 22, 80 e 443 liberadas"
    else
        warn "UFW não encontrado — configure o firewall manualmente se necessário"
    fi
}

# ── Verificação final ─────────────────────────────────────────────────────────
final_check() {
    step "VERIFICAÇÃO FINAL"

    local all_ok=true

    systemctl is-active --quiet apache2 \
        && ok  "Apache2: rodando" \
        || { warn "Apache2: PARADO — verifique: systemctl status apache2"; all_ok=false; }

    systemctl is-active --quiet mysql \
        && ok  "MySQL: rodando" \
        || { warn "MySQL: PARADO — verifique: systemctl status mysql"; all_ok=false; }

    php${PHP_VER} -v > /dev/null 2>&1 \
        && ok  "PHP ${PHP_VER}: disponível" \
        || { warn "PHP ${PHP_VER}: não encontrado"; all_ok=false; }

    # Verifica extensões críticas (json e openssl são built-in)
    for ext in curl mbstring pdo pdo_mysql xml gd; do
        php${PHP_VER} -m 2>/dev/null | grep -qi "^${ext}$" \
            && ok  "Extensão PHP: ${ext}" \
            || warn "Extensão PHP ausente: ${ext}"
    done

    [[ -f "${WEBROOT}/includes/config.php" ]] \
        && ok  "config.php gerado" \
        || { warn "config.php não encontrado"; all_ok=false; }

    mysql -u "${DB_USER}" -p"${DB_PASS}" "${DB_NAME}" \
        -e "SHOW TABLES;" > /dev/null 2>&1 \
        && ok  "Conexão com banco de dados OK" \
        || warn "Banco: verifique as credenciais"

    [[ -f "/var/www/html/phpmyadmin/index.php" ]] \
        && ok  "phpMyAdmin: instalado" \
        || warn "phpMyAdmin: não encontrado em /var/www/html/phpmyadmin"

    $all_ok && ok "Todos os checks passaram!" || warn "Alguns itens precisam de atenção (veja acima)"
}

# ── Resumo final ──────────────────────────────────────────────────────────────
print_summary() {
    local base=""
    [[ -n "$SUBPATH" ]] && base="/${SUBPATH}"
    APP_URL="http://${SERVER_NAME}${base}"

    echo ""
    echo -e "${GREEN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║          🎬  TATI STUDIO INSTALADO COM SUCESSO!  🎬          ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    echo -e "  ${BOLD}🌐 URL do sistema:${RESET}     ${CYAN}${APP_URL}${RESET}"
    echo -e "  ${BOLD}🔐 Senha de acesso:${RESET}    (a que você definiu)"
    echo ""
    echo -e "  ${BOLD}━━━ Banco de dados ━━━${RESET}"
    echo -e "  Host:      127.0.0.1"
    echo -e "  Banco:     ${DB_NAME}"
    echo -e "  Usuário:   ${DB_USER}"
    echo -e "  Senha DB:  ${YELLOW}${DB_PASS}${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ MySQL root ━━━${RESET}"
    echo -e "  Senha:     ${RED}${MYSQL_ROOT_PASS}${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ URLs ━━━${RESET}"
    echo -e "  Studio:      ${CYAN}${APP_URL}${RESET}"
    echo -e "  phpMyAdmin:  ${CYAN}http://${SERVER_NAME}/phpmyadmin${RESET}"
    echo ""
    echo -e "  ${BOLD}━━━ Login phpMyAdmin ━━━${RESET}"
    echo -e "  Usuário:   ${YELLOW}root${RESET}  ou  ${YELLOW}${DB_USER}${RESET}"
    echo -e "  Senha:     ${YELLOW}${MYSQL_ROOT_PASS}${RESET}  (root MySQL)"
    echo ""
    echo -e "  ${BOLD}━━━ Próximos passos ━━━${RESET}"
    echo -e "  1. Acesse ${CYAN}${APP_URL}${RESET} e faça login no Studio"
    echo -e "  2. Gerencie o banco em ${CYAN}http://${SERVER_NAME}/phpmyadmin${RESET}"
    echo -e "  3. Para HTTPS: ${CYAN}certbot --apache -d ${SERVER_NAME}${RESET}"
    echo ""

    # Salva credenciais em arquivo seguro
    cat > /root/tati-studio-credenciais.txt <<CREDS
TATI STUDIO — CREDENCIAIS
Instalado em: $(date '+%d/%m/%Y %H:%M:%S')

URLS:
  Studio:     ${APP_URL}
  phpMyAdmin: http://${SERVER_NAME}/phpmyadmin

STUDIO:
  Senha acesso: (definida durante instalação)

BANCO DE DADOS:
  Host:     127.0.0.1
  Banco:    ${DB_NAME}
  Usuário:  ${DB_USER}
  Senha:    ${DB_PASS}

MYSQL ROOT:
  Senha:    ${MYSQL_ROOT_PASS}

phpMYADMIN:
  URL:      http://${SERVER_NAME}/phpmyadmin
  Usuário:  root
  Senha:    ${MYSQL_ROOT_PASS}

Pasta dos arquivos: ${WEBROOT}
CREDS
    chmod 600 /root/tati-studio-credenciais.txt
    ok "Credenciais salvas em: /root/tati-studio-credenciais.txt"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════════
main() {
    banner
    check_root
    check_os
    check_internet
    collect_config
    install_packages
    configure_mysql
    configure_apache
    deploy_files
    install_phpmyadmin
    configure_firewall
    final_check
    print_summary
}

main "$@"
