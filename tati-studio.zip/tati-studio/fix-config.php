<?php
/**
 * TATI STUDIO — CORRIGIR CONFIG.PHP
 * Use quando o config.php existe mas falta as constantes de banco.
 * Acesse: seusite.com/fix-config.php
 * DELETE este arquivo após usar!
 */
if (($_GET['fix'] ?? '') !== 'tati') {
    http_response_code(403);
    die('<p style="font:1rem sans-serif;padding:2rem">Acesso negado. Use ?fix=tati</p>');
}

$configFile = __DIR__ . '/includes/config.php';
$saved = false;
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost = trim($_POST['db_host'] ?? '127.0.0.1');
    $dbPort = trim($_POST['db_port'] ?? '3306');
    $dbName = trim($_POST['db_name'] ?? '');
    $dbUser = trim($_POST['db_user'] ?? '');
    $dbPass = trim($_POST['db_pass'] ?? '');

    if (empty($dbName)) $errors[] = 'Nome do banco obrigatório.';
    if (empty($dbUser)) $errors[] = 'Usuário do banco obrigatório.';

    if (empty($errors)) {
        // Testa conexão
        try {
            $pdo = new PDO(
                "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4;connect_timeout=5",
                $dbUser, $dbPass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            // Cria tabelas se não existirem
            $pdo->exec("CREATE TABLE IF NOT EXISTS projetos (
                id            INT AUTO_INCREMENT PRIMARY KEY,
                titulo        VARCHAR(255) NOT NULL DEFAULT 'Sem titulo',
                roteiro       LONGTEXT,
                resultados    JSON,
                criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_criado (criado_em)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $pdo->exec("CREATE TABLE IF NOT EXISTS sessoes_log (
                id        INT AUTO_INCREMENT PRIMARY KEY,
                ip        VARCHAR(45),
                acao      VARCHAR(100),
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (Exception $e) {
            $msg = $e->getMessage();
            if (str_contains($msg, 'Access denied'))
                $errors[] = 'Usuário ou senha incorretos.';
            elseif (str_contains($msg, 'Unknown database'))
                $errors[] = "Banco '{$dbName}' não existe. Crie-o primeiro.";
            else
                $errors[] = 'Erro de conexão: ' . $msg;
        }
    }

    if (empty($errors)) {
        // Lê config atual e adiciona as constantes de banco
        $current = file_get_contents($configFile);
        // Remove define de INSTALLED e adiciona as novas constantes antes dele
        $addition  = "\n// Banco de dados — adicionado pelo fix-config.php\n";
        $addition .= "define('DB_HOST', '" . addslashes($dbHost) . "');\n";
        $addition .= "define('DB_PORT', '" . addslashes($dbPort) . "');\n";
        $addition .= "define('DB_NAME', '" . addslashes($dbName) . "');\n";
        $addition .= "define('DB_USER', '" . addslashes($dbUser) . "');\n";
        $addition .= "define('DB_PASS', '" . addslashes($dbPass) . "');\n";

        // Insere antes do define('INSTALLED') ou no final
        if (str_contains($current, "define('INSTALLED'")) {
            $current = str_replace("define('INSTALLED'", $addition . "define('INSTALLED'", $current);
        } else {
            $current .= $addition;
        }

        if (file_put_contents($configFile, $current) !== false) {
            $success = true;
        } else {
            $errors[] = 'Não foi possível salvar o config.php. Verifique as permissões.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Corrigir Config — Tati Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#08080f;--surface:#111119;--border:#23233a;--accent:#ff6b35;--text:#eeeef8;--muted:#72728a;--ok:#2dd4bf;--err:#f87171}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem}
.wrap{width:100%;max-width:480px}
.logo{font-family:'Syne',sans-serif;font-weight:800;font-size:1.4rem;letter-spacing:-.04em;margin-bottom:2rem}
.logo span{color:var(--accent)}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:2rem}
h1{font-family:'Syne',sans-serif;font-size:1.1rem;margin-bottom:.3rem}
p.sub{color:var(--muted);font-size:.88rem;margin-bottom:1.5rem;line-height:1.6}
label{display:block;font-size:.75rem;font-weight:500;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:.4rem}
input{width:100%;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:.9rem;padding:.75rem 1rem;outline:none;transition:border-color .2s;margin-bottom:1rem}
input:focus{border-color:var(--accent)}
.row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.btn{width:100%;background:var(--accent);color:#fff;border:none;border-radius:8px;padding:.85rem;font-family:'Syne',sans-serif;font-weight:700;font-size:.95rem;cursor:pointer;transition:opacity .2s}
.btn:hover{opacity:.85}
.err-box{background:rgba(248,113,113,.08);border:1px solid rgba(248,113,113,.25);border-radius:8px;padding:.8rem 1rem;margin-bottom:1.2rem;color:var(--err);font-size:.85rem;line-height:1.7}
.ok-box{background:rgba(45,212,191,.08);border:1px solid var(--ok);border-radius:8px;padding:1.2rem;text-align:center;color:var(--ok)}
.ok-box h2{font-family:'Syne',sans-serif;font-size:1.1rem;margin-bottom:.4rem}
.ok-box p{font-size:.85rem;opacity:.8}
a.back{display:block;text-align:center;margin-top:1rem;color:var(--accent);font-size:.88rem;text-decoration:none}
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">Tati <span>Studio</span></div>
  <div class="card">
  <?php if ($success): ?>
    <div class="ok-box">
      <h2>✅ Config atualizado!</h2>
      <p>As constantes de banco foram adicionadas ao config.php e as tabelas foram criadas.</p>
    </div>
    <a href="index.php" class="back">→ Ir para o Studio</a>
    <p style="color:var(--muted);font-size:.78rem;text-align:center;margin-top:1rem">⚠ Delete este arquivo: <code>fix-config.php</code></p>
  <?php else: ?>
    <h1>🔧 Adicionar credenciais do banco</h1>
    <p class="sub">O <code>config.php</code> existe mas está sem as constantes do MySQL. Preencha abaixo para corrigir.</p>

    <?php if (!empty($errors)): ?>
    <div class="err-box"><?php foreach($errors as $e) echo "⚠ " . htmlspecialchars($e) . "<br>"; ?></div>
    <?php endif; ?>

    <form method="POST" action="?fix=tati">
      <div class="row">
        <div><label>Host</label><input type="text" name="db_host" value="127.0.0.1" required></div>
        <div><label>Porta</label><input type="text" name="db_port" value="3306" required></div>
      </div>
      <label>Nome do banco</label>
      <input type="text" name="db_name" value="tati_studio" required>
      <label>Usuário MySQL</label>
      <input type="text" name="db_user" placeholder="tati_user" required autocomplete="off">
      <label>Senha MySQL</label>
      <input type="password" name="db_pass" placeholder="Senha do usuário" autocomplete="new-password">
      <p style="color:var(--muted);font-size:.78rem;margin-bottom:1rem">O banco precisa existir. As tabelas serão criadas automaticamente.</p>
      <button class="btn" type="submit">Salvar e corrigir</button>
    </form>
  <?php endif; ?>
  </div>
</div>
</body>
</html>
