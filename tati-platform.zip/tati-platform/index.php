<?php
require_once __DIR__ . '/includes/config.php';
if (!empty($_SESSION['user_id'])) {
    header('Location: pages/dashboard.php'); exit;
}
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tati Indicando — Studio</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

:root {
  --bg: #07070e;
  --surface: #0f0f1a;
  --border: rgba(255,255,255,.07);
  --accent: #6366f1;
  --accent2: #a855f7;
  --text: #e2e8f0;
  --muted: #64748b;
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.bg-mesh {
  position: fixed; inset: 0; z-index: 0; pointer-events: none;
  background:
    radial-gradient(ellipse 60% 50% at 20% 10%, rgba(99,102,241,.18) 0%, transparent 60%),
    radial-gradient(ellipse 50% 40% at 80% 90%, rgba(168,85,247,.15) 0%, transparent 60%),
    radial-gradient(ellipse 40% 60% at 50% 50%, rgba(99,102,241,.05) 0%, transparent 80%);
}

.grid-lines {
  position: fixed; inset: 0; z-index: 0; pointer-events: none;
  background-image:
    linear-gradient(rgba(99,102,241,.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(99,102,241,.04) 1px, transparent 1px);
  background-size: 60px 60px;
}

.login-wrap {
  position: relative; z-index: 10;
  width: 100%; max-width: 420px;
  padding: 24px;
}

.brand {
  text-align: center;
  margin-bottom: 36px;
}

.brand-logo {
  width: 64px; height: 64px;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  border-radius: 18px;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 28px;
  margin-bottom: 16px;
  box-shadow: 0 0 40px rgba(99,102,241,.4);
}

.brand h1 {
  font-family: 'Syne', sans-serif;
  font-size: 24px; font-weight: 800;
  background: linear-gradient(135deg, #fff 0%, #a5b4fc 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}

.brand p {
  font-size: 13px; color: var(--muted); margin-top: 4px;
}

.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 36px;
  box-shadow: 0 24px 80px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.05);
}

.card h2 {
  font-family: 'Syne', sans-serif;
  font-size: 20px; font-weight: 700;
  margin-bottom: 8px;
}

.card > p { font-size: 13px; color: var(--muted); margin-bottom: 28px; }

.field { margin-bottom: 18px; }

.field label {
  display: block;
  font-size: 12px; font-weight: 600;
  text-transform: uppercase; letter-spacing: 1px;
  color: var(--muted);
  margin-bottom: 8px;
}

.field input {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 14px 16px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  outline: none;
  transition: border-color .2s, box-shadow .2s;
}

.field input:focus {
  border-color: rgba(99,102,241,.6);
  box-shadow: 0 0 0 3px rgba(99,102,241,.12);
}

.field input::placeholder { color: #475569; }

.btn-login {
  width: 100%;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  color: #fff;
  border: none;
  border-radius: 12px;
  padding: 15px;
  font-family: 'DM Sans', sans-serif;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 8px;
  transition: opacity .2s, transform .1s;
  box-shadow: 0 4px 24px rgba(99,102,241,.35);
}

.btn-login:hover { opacity: .92; }
.btn-login:active { transform: scale(.98); }
.btn-login:disabled { opacity: .5; cursor: not-allowed; }

.error-msg {
  background: rgba(239,68,68,.1);
  border: 1px solid rgba(239,68,68,.3);
  color: #fca5a5;
  border-radius: 10px;
  padding: 12px 16px;
  font-size: 13px;
  margin-top: 16px;
  display: none;
}

.footer-note {
  text-align: center;
  margin-top: 20px;
  font-size: 12px;
  color: var(--muted);
}
</style>
</head>
<body>
<div class="bg-mesh"></div>
<div class="grid-lines"></div>

<div class="login-wrap">
  <div class="brand">
    <div class="brand-logo">✦</div>
    <h1>Tati Indicando</h1>
    <p>Studio de Produção Multiagente</p>
  </div>

  <div class="card">
    <h2>Entrar na plataforma</h2>
    <p>Acesse com suas credenciais para continuar.</p>

    <div class="field">
      <label>E-mail</label>
      <input type="email" id="email" placeholder="seu@email.com" autocomplete="email">
    </div>

    <div class="field">
      <label>Senha</label>
      <input type="password" id="password" placeholder="••••••••" autocomplete="current-password">
    </div>

    <button class="btn-login" id="loginBtn" onclick="doLogin()">Entrar</button>
    <div class="error-msg" id="errMsg"></div>
  </div>

  <p class="footer-note">Tati Indicando Studio v1.0 · Acesso restrito</p>
</div>

<script>
async function doLogin() {
  const btn  = document.getElementById('loginBtn');
  const err  = document.getElementById('errMsg');
  const email    = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  err.style.display = 'none';

  if (!email || !password) {
    showError('Preencha e-mail e senha.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Entrando...';

  const fd = new FormData();
  fd.append('action', 'login');
  fd.append('email', email);
  fd.append('password', password);

  try {
    const res  = await fetch('api/auth.php', { method: 'POST', body: fd });
    const data = await res.json();

    if (data.success) {
      btn.textContent = '✓ Redirecionando...';
      window.location.href = data.redirect;
    } else {
      showError(data.message);
      btn.disabled = false;
      btn.textContent = 'Entrar';
    }
  } catch (e) {
    showError('Erro de conexão. Tente novamente.');
    btn.disabled = false;
    btn.textContent = 'Entrar';
  }
}

function showError(msg) {
  const err = document.getElementById('errMsg');
  err.textContent = msg;
  err.style.display = 'block';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Enter') doLogin();
});
</script>
</body>
</html>
