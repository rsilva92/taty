#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║        TATI INDICANDO — STUDIO  ·  INSTALADOR AUTOMATIZADO          ║
# ║                         Versão 2.0.0                                 ║
# ║                                                                      ║
# ║  Instala automaticamente:                                            ║
# ║    • Apache 2.4  +  mod_rewrite  +  mod_php                         ║
# ║    • PHP 8.2  +  todas as extensões necessárias                      ║
# ║    • MariaDB  +  banco + usuário criados automaticamente             ║
# ║    • Aplicação Tati Indicando Studio                                 ║
# ║                                                                      ║
# ║  USO:                                                                ║
# ║    sudo bash install.sh                                              ║
# ║                                                                      ║
# ║  REQUISITOS:                                                         ║
# ║    • Ubuntu 20.04+ / Debian 11+ / CentOS/Rocky 8+                   ║
# ║    • Acesso root ou sudo                                             ║
# ║    • Conexão com a internet                                          ║
# ╚══════════════════════════════════════════════════════════════════════╝

set -euo pipefail
IFS=$'\n\t'

# ── VERSÃO ────────────────────────────────────────────────────────────
readonly APP_VERSION="2.0.0"
readonly APP_NAME="Tati Indicando Studio"
readonly PHP_TARGET="8.2"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly LOG_FILE="/tmp/tati_install_$(date +%Y%m%d_%H%M%S).log"

# ── CORES ─────────────────────────────────────────────────────────────
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; B='\033[0;34m'
C='\033[0;36m'; M='\033[0;35m'; W='\033[1m'; D='\033[2m'; X='\033[0m'

# ── VARIÁVEIS GLOBAIS ──────────────────────────────────────────────────
OS_ID=""; OS_VERSION=""; OS_NAME=""; PKG_MGR=""
PHP_VER=""; WEB_SERVER=""; MYSQL_SUDO_MODE=false

INSTALL_DIR="/var/www/html/tati-platform"
DB_HOST="localhost"; DB_PORT="3306"
DB_NAME="tati_platform"; DB_USER="tati_app"; DB_PASS=""
DOMAIN=""; BASE_URL=""; USE_SSL=false
ADMIN_NAME=""; ADMIN_EMAIL=""; ADMIN_PASS=""
CLAUDE_API_KEY=""

# ══════════════════════════════════════════════════════════════════════
# UTILITÁRIOS
# ══════════════════════════════════════════════════════════════════════
log()  { echo "[$(date '+%H:%M:%S')] $*" >> "$LOG_FILE"; }
step() { echo -e "\n${B}${W}  ▶  $1${X}"; log "STEP: $1"; }
ok()   { echo -e "  ${G}✓${X}  $1"; log "OK: $1"; }
info() { echo -e "  ${C}ℹ${X}  $1"; log "INFO: $1"; }
warn() { echo -e "  ${Y}⚠${X}  $1"; log "WARN: $1"; }
err()  { echo -e "\n  ${R}${W}✗  ERRO: $1${X}"; log "ERROR: $1"; }
div()  { echo -e "  ${D}──────────────────────────────────────────────────${X}"; }

fatal() {
    err "$1"
    echo -e "\n  ${D}Log: ${LOG_FILE}${X}\n"
    exit 1
}

# ── SPINNER ────────────────────────────────────────────────────────────
_spid=""
spin_start() {
    local msg="$1"
    local -a fr=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
    ( i=0; while true; do
        printf "\r  ${C}${fr[$((i%10))]}${X}  ${msg}   "
        sleep 0.08; ((i++)); done ) &
    _spid=$!; disown
}
spin_stop() {
    [[ -n "$_spid" ]] && kill "$_spid" 2>/dev/null && wait "$_spid" 2>/dev/null || true
    printf "\r\033[K"; _spid=""
}

# ── ROOT ───────────────────────────────────────────────────────────────
is_root()  { [[ $EUID -eq 0 ]]; }
has_sudo() { sudo -n true 2>/dev/null; }
asroot() {
    if is_root; then "$@"
    elif has_sudo; then sudo "$@"
    else fatal "Execute: sudo bash install.sh"
    fi
}

# ══════════════════════════════════════════════════════════════════════
# DETECTAR SISTEMA
# ══════════════════════════════════════════════════════════════════════
detect_system() {
    step "Detectando sistema operacional"

    [[ -f /etc/os-release ]] || fatal "Sistema não suportado."
    # shellcheck source=/dev/null
    . /etc/os-release
    OS_ID="${ID:-unknown}"; OS_VERSION="${VERSION_ID:-0}"
    OS_NAME="${PRETTY_NAME:-Linux}"
    log "OS: $OS_NAME | ID: $OS_ID"

    case "$OS_ID" in
        ubuntu|debian|linuxmint|pop) PKG_MGR="apt" ;;
        centos|rhel|rocky|almalinux|fedora)
            command -v dnf &>/dev/null && PKG_MGR="dnf" || PKG_MGR="yum" ;;
        *) warn "Distro '${OS_ID}' não testada — assumindo apt"; PKG_MGR="apt" ;;
    esac

    ok "Sistema: ${OS_NAME}"
    ok "Package manager: ${PKG_MGR}"

    is_root || has_sudo || fatal "Execute: sudo bash install.sh"
    ok "Privilégios root: ✓"
}

# ══════════════════════════════════════════════════════════════════════
# APACHE
# ══════════════════════════════════════════════════════════════════════
install_apache() {
    step "Instalando Apache 2.4"

    if command -v apache2 &>/dev/null || command -v httpd &>/dev/null; then
        ok "Apache já instalado"
        WEB_SERVER="apache"
        _apache_start; return
    fi

    if [[ "$PKG_MGR" == "apt" ]]; then
        spin_start "Atualizando índice"
        asroot apt-get update -qq >> "$LOG_FILE" 2>&1
        spin_stop; ok "Índice atualizado"

        spin_start "Instalando apache2"
        asroot apt-get install -y -qq apache2 >> "$LOG_FILE" 2>&1
        spin_stop; ok "Apache2 instalado"
    else
        spin_start "Instalando httpd"
        asroot $PKG_MGR install -y httpd >> "$LOG_FILE" 2>&1
        spin_stop; ok "httpd instalado"
    fi

    _apache_start
    WEB_SERVER="apache"
}

_apache_start() {
    spin_start "Iniciando Apache"
    if [[ "$PKG_MGR" == "apt" ]]; then
        asroot systemctl enable apache2 >> "$LOG_FILE" 2>&1 || true
        asroot systemctl start  apache2 >> "$LOG_FILE" 2>&1 || true
        asroot a2enmod rewrite  >> "$LOG_FILE" 2>&1 || true
        asroot a2enmod headers  >> "$LOG_FILE" 2>&1 || true
    else
        asroot systemctl enable httpd >> "$LOG_FILE" 2>&1 || true
        asroot systemctl start  httpd >> "$LOG_FILE" 2>&1 || true
    fi
    spin_stop; ok "Apache ativo no boot"
}

# ══════════════════════════════════════════════════════════════════════
# PHP 8.2
# ══════════════════════════════════════════════════════════════════════
install_php() {
    step "Instalando PHP ${PHP_TARGET} e extensões"

    if command -v php &>/dev/null; then
        local maj min
        maj=$(php -r "echo PHP_MAJOR_VERSION;" 2>/dev/null || echo 0)
        min=$(php -r "echo PHP_MINOR_VERSION;"  2>/dev/null || echo 0)
        if [[ $maj -ge 8 ]] && [[ $min -ge 1 ]]; then
            PHP_VER=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;" 2>/dev/null)
            ok "PHP ${PHP_VER} já instalado"
            _check_php_extensions; return
        fi
        warn "PHP ${maj}.${min} muito antigo — atualizando para ${PHP_TARGET}..."
    fi

    [[ "$PKG_MGR" == "apt" ]] && _install_php_apt || _install_php_rpm

    PHP_VER=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;" 2>/dev/null || echo "$PHP_TARGET")
    ok "PHP ${PHP_VER} pronto"
    _check_php_extensions
}

_install_php_apt() {
    spin_start "Instalando software-properties-common"
    asroot apt-get install -y -qq software-properties-common curl gnupg2 >> "$LOG_FILE" 2>&1
    spin_stop; ok "software-properties-common"

    if [[ "$OS_ID" == "ubuntu" ]] || [[ "$OS_ID" == "linuxmint" ]] || [[ "$OS_ID" == "pop" ]]; then
        spin_start "Adicionando ppa:ondrej/php"
        asroot add-apt-repository -y ppa:ondrej/php >> "$LOG_FILE" 2>&1 || true
        asroot apt-get update -qq >> "$LOG_FILE" 2>&1
        spin_stop; ok "PPA ondrej/php adicionado"
    else
        spin_start "Adicionando repositório PHP (Debian/Sury)"
        asroot curl -sSL https://packages.sury.org/php/apt.gpg \
            -o /usr/share/keyrings/sury-php.gpg >> "$LOG_FILE" 2>&1 || true
        local codename; codename=$(. /etc/os-release && echo "$VERSION_CODENAME")
        echo "deb [signed-by=/usr/share/keyrings/sury-php.gpg] https://packages.sury.org/php/ ${codename} main" \
            | asroot tee /etc/apt/sources.list.d/php.list > /dev/null
        asroot apt-get update -qq >> "$LOG_FILE" 2>&1
        spin_stop; ok "Repositório PHP Sury configurado"
    fi

    local pkgs=(
        "php${PHP_TARGET}" "php${PHP_TARGET}-cli" "php${PHP_TARGET}-fpm"
        "libapache2-mod-php${PHP_TARGET}" "php${PHP_TARGET}-common"
        "php${PHP_TARGET}-mysql" "php${PHP_TARGET}-curl" "php${PHP_TARGET}-mbstring"
        "php${PHP_TARGET}-xml" "php${PHP_TARGET}-zip" "php${PHP_TARGET}-opcache"
        "php${PHP_TARGET}-bcmath" "php${PHP_TARGET}-intl"
    )

    spin_start "Instalando PHP ${PHP_TARGET} + extensões (aguarde...)"
    asroot apt-get install -y -qq "${pkgs[@]}" >> "$LOG_FILE" 2>&1
    spin_stop; ok "PHP ${PHP_TARGET} + extensões instalados"

    asroot a2enmod "php${PHP_TARGET}" >> "$LOG_FILE" 2>&1 || true
    asroot systemctl reload apache2   >> "$LOG_FILE" 2>&1 || true
}

_install_php_rpm() {
    spin_start "Configurando EPEL + Remi"
    asroot $PKG_MGR install -y epel-release >> "$LOG_FILE" 2>&1 || true
    local rv; rv=$(rpm -E '%{rhel}' 2>/dev/null || echo "8")
    asroot $PKG_MGR install -y \
        "https://rpms.remirepo.net/enterprise/remi-release-${rv}.rpm" \
        >> "$LOG_FILE" 2>&1 || true
    spin_stop; ok "EPEL + Remi"

    spin_start "Habilitando PHP 8.2 (Remi)"
    asroot $PKG_MGR module reset  -y php >> "$LOG_FILE" 2>&1 || true
    asroot $PKG_MGR module enable -y php:remi-8.2 >> "$LOG_FILE" 2>&1 || true
    spin_stop

    local pkgs=(
        php php-cli php-fpm mod_php
        php-mysqlnd php-pdo php-curl php-mbstring
        php-xml php-zip php-opcache php-bcmath php-intl php-json php-common
    )
    spin_start "Instalando PHP 8.2 + extensões"
    asroot $PKG_MGR install -y "${pkgs[@]}" >> "$LOG_FILE" 2>&1
    spin_stop; ok "PHP 8.2 instalado"

    asroot systemctl reload httpd >> "$LOG_FILE" 2>&1 || true
}

_check_php_extensions() {
    local -a req=("pdo" "pdo_mysql" "curl" "mbstring") missing=()
    for e in "${req[@]}"; do
        php -r "exit(extension_loaded('${e}')?0:1);" 2>/dev/null || missing+=("$e")
    done
    [[ ${#missing[@]} -eq 0 ]] \
        && ok "Extensões PHP críticas: pdo, pdo_mysql, curl, mbstring ✓" \
        || warn "Extensões ausentes: ${missing[*]} — instale: apt install php${PHP_VER}-mysql php${PHP_VER}-curl"
}

# ══════════════════════════════════════════════════════════════════════
# MARIADB
# ══════════════════════════════════════════════════════════════════════
install_mariadb() {
    step "Instalando MariaDB"

    if command -v mysql &>/dev/null || command -v mariadb &>/dev/null; then
        ok "MySQL/MariaDB já instalado"
        _mariadb_start; return
    fi

    spin_start "Instalando mariadb-server"
    if [[ "$PKG_MGR" == "apt" ]]; then
        asroot apt-get install -y -qq mariadb-server mariadb-client >> "$LOG_FILE" 2>&1
    else
        asroot $PKG_MGR install -y mariadb-server mariadb >> "$LOG_FILE" 2>&1
    fi
    spin_stop; ok "MariaDB instalado"

    _mariadb_start
}

_mariadb_start() {
    spin_start "Iniciando MariaDB"
    asroot systemctl enable mariadb >> "$LOG_FILE" 2>&1 \
        || asroot systemctl enable mysql >> "$LOG_FILE" 2>&1 || true
    asroot systemctl start mariadb  >> "$LOG_FILE" 2>&1 \
        || asroot systemctl start mysql  >> "$LOG_FILE" 2>&1 || true
    spin_stop; ok "MariaDB ativo no boot"

    # Esperar socket ficar disponível (máx 15s)
    local i=0 sock=""
    while [[ $i -lt 15 ]]; do
        for c in /var/run/mysqld/mysqld.sock /run/mysqld/mysqld.sock \
                  /tmp/mysql.sock /var/lib/mysql/mysql.sock; do
            [[ -S "$c" ]] && sock="$c" && break 2
        done
        sleep 1; ((i++))
    done
    [[ -n "$sock" ]] && log "Socket MariaDB: $sock" \
        || warn "Socket MariaDB não detectado — prosseguindo via TCP"
}

# ══════════════════════════════════════════════════════════════════════
# MYSQL HELPER — sem word splitting
# ══════════════════════════════════════════════════════════════════════
_mysql_args() {
    # _mysql_args <user> <pass>  → preenche array global MYSQL_ARGS
    local user="$1" pass="$2"
    MYSQL_ARGS=("-u" "$user")
    [[ -n "$pass" ]] && MYSQL_ARGS+=("-p${pass}")

    local sock=""
    for c in /var/run/mysqld/mysqld.sock /run/mysqld/mysqld.sock \
              /tmp/mysql.sock /var/lib/mysql/mysql.sock; do
        [[ -S "$c" ]] && sock="$c" && break
    done

    if [[ -n "$sock" ]]; then
        MYSQL_ARGS+=("--socket=${sock}")
    else
        MYSQL_ARGS+=("-h" "127.0.0.1" "-P" "$DB_PORT")
    fi
    MYSQL_ARGS+=("--connect-timeout=10" "--batch" "--silent")
}

mysql_run() {
    # mysql_run <user> <pass> <extra args...>
    local user="$1" pass="$2"; shift 2
    local -a MYSQL_ARGS=()
    _mysql_args "$user" "$pass"
    MYSQL_ARGS+=("$@")
    log "mysql_run: mysql ${MYSQL_ARGS[*]}"
    mysql "${MYSQL_ARGS[@]}" 2>>"$LOG_FILE"
}

mysql_root() {
    # Tenta sudo mysql (auth_socket) depois root sem senha
    if asroot mysql --batch --silent "$@" >> "$LOG_FILE" 2>&1; then
        MYSQL_SUDO_MODE=true; return 0
    fi
    mysql_run "root" "" "$@" >> "$LOG_FILE" 2>&1 && return 0
    return 1
}

# ══════════════════════════════════════════════════════════════════════
# BANCO DE DADOS
# ══════════════════════════════════════════════════════════════════════
setup_database() {
    step "Configurando banco de dados"

    # Gerar senha forte
    DB_PASS="$(tr -dc 'A-Za-z0-9' < /dev/urandom 2>/dev/null | head -c 28)" || true
    [[ -z "$DB_PASS" ]] && DB_PASS="$(date +%s%N${RANDOM} | sha256sum | head -c 28)"
    log "Senha DB gerada (${#DB_PASS} chars)"

    # ── Conectar como root
    spin_start "Verificando acesso root ao MariaDB"
    local root_ok=false i=0
    while [[ $i -lt 3 ]]; do
        ((i++))
        mysql_root --execute="SELECT 1;" 2>/dev/null && root_ok=true && break
        sleep 1
    done
    spin_stop

    if [[ "$root_ok" == false ]]; then
        echo ""
        warn "Não conectei automaticamente. Informe a senha root do MariaDB:"
        local tp tk=false
        for i in 1 2 3; do
            printf "  Senha root (tentativa ${i}/3, ENTER=sem senha): "
            read -rs tp; echo ""
            if mysql_run "root" "$tp" --execute="SELECT 1;" 2>/dev/null; then
                tk=true
                # Redefinir mysql_root para usar essa senha
                eval 'mysql_root() { mysql_run "root" "'"$tp"'" "$@"; }'
                break
            fi
            warn "Incorreta."
        done
        [[ "$tk" == true ]] || fatal "Não foi possível conectar ao MariaDB."
    fi
    ok "Acesso root ao MariaDB confirmado"

    # ── Criar banco
    spin_start "Criando banco '${DB_NAME}'"
    mysql_root --execute="
        CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`
        CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    " || { spin_stop; fatal "Falha ao criar banco."; }
    spin_stop; ok "Banco '${DB_NAME}' criado"

    # ── Criar usuário (suporte MySQL 8+ e MariaDB 10.x)
    spin_start "Criando usuário MySQL '${DB_USER}'"
    mysql_root --execute="
        DROP USER IF EXISTS '${DB_USER}'@'localhost';
        CREATE USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
        GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
        FLUSH PRIVILEGES;
    " 2>/dev/null \
    || mysql_root --execute="
        GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost'
        IDENTIFIED BY '${DB_PASS}';
        FLUSH PRIVILEGES;
    " \
    || { spin_stop; fatal "Falha ao criar usuário '${DB_USER}'."; }
    spin_stop; ok "Usuário '${DB_USER}' criado"

    # ── Importar schema
    spin_start "Importando schema"
    mysql_run "$DB_USER" "$DB_PASS" "$DB_NAME" \
        < "${INSTALL_DIR}/database.sql" \
        || { spin_stop; fatal "Falha ao importar schema."; }
    spin_stop; ok "Schema importado (5 tabelas)"

    # ── Admin
    _create_app_admin
}

_create_app_admin() {
    spin_start "Criando admin '${ADMIN_EMAIL}'"
    command -v php &>/dev/null || { spin_stop; warn "PHP não disponível para hash — crie admin manualmente."; return; }

    local ph; ph=$(php -r "echo password_hash('${ADMIN_PASS}',PASSWORD_BCRYPT);" 2>/dev/null) || { spin_stop; warn "Erro ao gerar hash."; return; }
    local sph="${ph//\'/\'\'}"; local snm="${ADMIN_NAME//\'/\'\'}"; local sem="${ADMIN_EMAIL//\'/\'\'}"

    mysql_run "$DB_USER" "$DB_PASS" "$DB_NAME" --execute="
        DELETE FROM users WHERE email='${sem}';
        INSERT INTO users (name,email,password,role,active)
        VALUES ('${snm}','${sem}','${sph}','admin',1);
    " || { spin_stop; warn "Não criou admin via SQL — crie manualmente."; return; }
    spin_stop; ok "Admin '${ADMIN_NAME}' criado"
}

# ══════════════════════════════════════════════════════════════════════
# COLETA DE CONFIGURAÇÃO
# ══════════════════════════════════════════════════════════════════════
collect_config() {
    echo ""
    echo -e "${M}${W}  ╔══════════════════════════════════════════════════════════╗"
    echo    "  ║    ✦  TATI INDICANDO — STUDIO                           ║"
    echo    "  ║       Instalador Automatizado v${APP_VERSION}                    ║"
    echo -e "  ╚══════════════════════════════════════════════════════════╝${X}"
    echo ""
    echo -e "  ${D}Log: ${LOG_FILE}${X}"
    echo ""
    echo -e "  ${W}ENTER = valor padrão em cada campo.${X}"
    echo ""

    div
    echo -e "  ${W}🌐  DOMÍNIO${X}"; echo ""
    printf "  Domínio ou IP (ex: meusite.com.br) [localhost]: "
    read -r DOMAIN; DOMAIN="${DOMAIN:-localhost}"

    if [[ "$DOMAIN" != "localhost" ]]; then
        printf "  Usar HTTPS? (s/n) [n]: "
        read -r sl; [[ "$sl" =~ ^[Ss]$ ]] && USE_SSL=true
    fi
    [[ "$USE_SSL" == true ]] \
        && BASE_URL="https://${DOMAIN}/tati-platform" \
        || BASE_URL="http://${DOMAIN}/tati-platform"
    info "URL: ${BASE_URL}"

    div
    echo -e "  ${W}📁  DIRETÓRIO${X}"; echo ""
    printf "  Instalar em [/var/www/html/tati-platform]: "
    read -r input; INSTALL_DIR="${input:-/var/www/html/tati-platform}"

    div
    echo -e "  ${W}🗄️   BANCO${X}"; echo ""
    info "Usuário '${DB_USER}' e senha gerados automaticamente"
    printf "  Nome do banco [tati_platform]: "
    read -r input; DB_NAME="${input:-tati_platform}"

    div
    echo -e "  ${W}🤖  API CLAUDE${X}"; echo ""
    echo -e "  ${D}Obtenha em: https://console.anthropic.com/api-keys${X}"; echo ""
    while true; do
        printf "  API Key (sk-ant-..., ENTER para pular): "
        read -rs CLAUDE_API_KEY; echo ""
        [[ "$CLAUDE_API_KEY" =~ ^sk-ant- ]] && { ok "Formato válido ✓"; break; }
        [[ -z "$CLAUDE_API_KEY" ]] && { warn "Sem API Key — configure depois em config.php"; break; }
        warn "Deve começar com 'sk-ant-'"
    done

    div
    echo -e "  ${W}👤  ADMINISTRADOR${X}"; echo ""
    printf "  Nome [Administrador]: "; read -r input; ADMIN_NAME="${input:-Administrador}"
    printf "  E-mail [admin@tatiindicando.com]: "; read -r ADMIN_EMAIL
    [[ -z "$ADMIN_EMAIL" ]] && ADMIN_EMAIL="admin@tatiindicando.com"
    while true; do
        printf "  Senha admin (mín. 8 chars): "; read -rs ADMIN_PASS; echo ""
        [[ ${#ADMIN_PASS} -ge 8 ]] || { warn "Mínimo 8 caracteres."; continue; }
        printf "  Confirme a senha: "; read -rs p2; echo ""
        [[ "$ADMIN_PASS" == "$p2" ]] && break || warn "Senhas não conferem."
    done

    div; echo ""
    echo -e "  ${W}📋  RESUMO DA INSTALAÇÃO${X}"; echo ""
    echo -e "  ${D}Sistema:${X}     ${OS_NAME}"
    echo -e "  ${D}Instalar:${X}    Apache + PHP ${PHP_TARGET} + MariaDB (automático)"
    echo -e "  ${D}URL:${X}         ${BASE_URL}"
    echo -e "  ${D}Diretório:${X}   ${INSTALL_DIR}"
    echo -e "  ${D}Banco:${X}       ${DB_NAME}  |  user: ${DB_USER}  |  senha: automática"
    echo -e "  ${D}Admin:${X}       ${ADMIN_NAME} <${ADMIN_EMAIL}>"
    [[ -n "$CLAUDE_API_KEY" ]] \
        && echo -e "  ${D}API Key:${X}     ${CLAUDE_API_KEY:0:24}..." \
        || echo -e "  ${D}API Key:${X}     ${Y}(não configurada)${X}"
    echo ""
    echo -e "  ${Y}${W}Iniciar instalação completa? (s/n) [s]:${X} \c"
    read -r go; [[ "${go:-s}" =~ ^[Nn]$ ]] && { info "Cancelado."; exit 0; }
}

# ══════════════════════════════════════════════════════════════════════
# ARQUIVOS DA APLICAÇÃO
# ══════════════════════════════════════════════════════════════════════
install_app_files() {
    step "Copiando arquivos para ${INSTALL_DIR}"

    if [[ -d "$INSTALL_DIR" ]]; then
        local bk="${INSTALL_DIR}_bkp_$(date +%Y%m%d_%H%M%S)"
        asroot mv "$INSTALL_DIR" "$bk"
        warn "Backup anterior: ${bk}"
    fi

    asroot mkdir -p "${INSTALL_DIR}"

    spin_start "Copiando arquivos da aplicação"
    for item in api includes pages index.php database.sql .htaccess; do
        [[ -e "${SCRIPT_DIR}/${item}" ]] \
            && asroot cp -r "${SCRIPT_DIR}/${item}" "${INSTALL_DIR}/" 2>>"$LOG_FILE" \
            || warn "Não encontrado: ${item}"
    done
    spin_stop; ok "Arquivos copiados"

    spin_start "Criando diretórios de dados"
    for d in uploads uploads/reports logs; do
        asroot mkdir -p "${INSTALL_DIR}/${d}"
    done
    spin_stop; ok "uploads/, logs/ criados"

    printf 'includes/config.php\nuploads/\nlogs/\n*.log\n' \
        | asroot tee "${INSTALL_DIR}/.gitignore" > /dev/null
}

# ══════════════════════════════════════════════════════════════════════
# PERMISSÕES
# ══════════════════════════════════════════════════════════════════════
set_permissions() {
    step "Configurando permissões"
    local wu="www-data"
    id apache   &>/dev/null && wu="apache"
    id nginx    &>/dev/null && wu="nginx"
    id www-data &>/dev/null && wu="www-data"

    spin_start "Aplicando dono=${wu} e chmod"
    asroot chown -R "${wu}:${wu}" "${INSTALL_DIR}" 2>/dev/null \
        || asroot chown -R "$(whoami)" "${INSTALL_DIR}"
    asroot find "${INSTALL_DIR}" -type d -exec chmod 755 {} \;
    asroot find "${INSTALL_DIR}" -type f -exec chmod 644 {} \;
    asroot chmod -R 775 "${INSTALL_DIR}/uploads"
    asroot chmod -R 775 "${INSTALL_DIR}/logs"
    asroot chmod 640 "${INSTALL_DIR}/includes/config.php" 2>/dev/null || true
    spin_stop; ok "Permissões aplicadas (dono: ${wu})"
}

# ══════════════════════════════════════════════════════════════════════
# CONFIG.PHP
# ══════════════════════════════════════════════════════════════════════
write_config() {
    step "Gerando includes/config.php"
    local ssl_flag=0; [[ "$USE_SSL" == true ]] && ssl_flag=1

    asroot tee "${INSTALL_DIR}/includes/config.php" > /dev/null <<PHPEOF
<?php
// config.php — Gerado em $(date '+%d/%m/%Y %H:%M:%S')

define('DB_HOST',  '${DB_HOST}');
define('DB_PORT',  '${DB_PORT}');
define('DB_USER',  '${DB_USER}');
define('DB_PASS',  '${DB_PASS}');
define('DB_NAME',  '${DB_NAME}');

define('CLAUDE_API_KEY',    '${CLAUDE_API_KEY}');
define('CLAUDE_MODEL',      'claude-sonnet-4-20250514');
define('CLAUDE_MAX_TOKENS', 8000);

define('BASE_URL',    '${BASE_URL}');
define('REPORTS_DIR', __DIR__ . '/../uploads/reports/');
define('APP_NAME',    'Tati Indicando — Studio');
define('APP_VERSION', '${APP_VERSION}');

session_start();
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure',   ${ssl_flag});
ini_set('session.use_strict_mode', 1);
ini_set('session.gc_maxlifetime',  86400);

date_default_timezone_set('America/Sao_Paulo');
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors',     1);
ini_set('error_log',      __DIR__ . '/../logs/error.log');

function getDB(): PDO {
    static \$pdo = null;
    if (\$pdo === null) {
        try {
            \$pdo = new PDO(
                sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                    DB_HOST, DB_PORT, DB_NAME),
                DB_USER, DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                 PDO::ATTR_EMULATE_PREPARES => false]
            );
        } catch (PDOException \$e) {
            error_log('DB: ' . \$e->getMessage());
            die(json_encode(['error' => 'Falha na conexão com o banco de dados.']));
        }
    }
    return \$pdo;
}

function requireAuth(): void {
    if (empty(\$_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/index.php'); exit;
    }
}

function requireAdmin(): void {
    requireAuth();
    if (\$_SESSION['user_role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/pages/dashboard.php'); exit;
    }
}

function clean(string \$str): string {
    return htmlspecialchars(trim(\$str), ENT_QUOTES, 'UTF-8');
}

function auditLog(string \$action, string \$description = '', ?int \$userId = null): void {
    try {
        \$db  = getDB();
        \$uid = \$userId ?? (\$_SESSION['user_id'] ?? null);
        \$ip  = \$_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        \$db->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address) VALUES (?,?,?,?)")
           ->execute([\$uid, \$action, \$description, \$ip]);
    } catch (Exception \$e) {}
}
PHPEOF

    asroot chmod 640 "${INSTALL_DIR}/includes/config.php"
    ok "config.php gerado e protegido (chmod 640)"
}

# ══════════════════════════════════════════════════════════════════════
# PHP.INI OTIMIZADO
# ══════════════════════════════════════════════════════════════════════
configure_php_ini() {
    step "Otimizando PHP.ini"

    local conf_dir=""
    for c in \
        "/etc/php/${PHP_VER}/apache2/conf.d" \
        "/etc/php/${PHP_VER}/mods-available" \
        "/etc/php.d" "/etc/php/conf.d"; do
        [[ -d "$c" ]] && conf_dir="$c" && break
    done

    local ini_content="$(cat << 'INI'
; Tati Platform — PHP otimizado
max_execution_time    = 300
max_input_time        = 300
memory_limit          = 256M
post_max_size         = 64M
upload_max_filesize   = 64M
output_buffering      = Off
default_socket_timeout = 120
INI
)"

    if [[ -n "$conf_dir" ]]; then
        echo "$ini_content" | asroot tee "${conf_dir}/99-tati.ini" > /dev/null
        ok "PHP otimizado: ${conf_dir}/99-tati.ini"
    else
        echo "$ini_content" | asroot tee "${INSTALL_DIR}/.user.ini" > /dev/null
        ok "PHP otimizado via .user.ini"
    fi

    asroot systemctl reload apache2 >> "$LOG_FILE" 2>&1 \
        || asroot systemctl reload httpd >> "$LOG_FILE" 2>&1 || true
}

# ══════════════════════════════════════════════════════════════════════
# VIRTUALHOST APACHE
# ══════════════════════════════════════════════════════════════════════
configure_apache() {
    step "Configurando VirtualHost Apache"

    local conf_path
    [[ "$PKG_MGR" == "apt" ]] \
        && conf_path="/etc/apache2/sites-available/tati-platform.conf" \
        || conf_path="/etc/httpd/conf.d/tati-platform.conf"

    asroot tee "$conf_path" > /dev/null << VHEOF
<VirtualHost *:80>
    ServerName ${DOMAIN}
    DocumentRoot /var/www/html

    Alias /tati-platform ${INSTALL_DIR}

    <Directory "${INSTALL_DIR}">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        DirectoryIndex index.php
    </Directory>

    <DirectoryMatch "${INSTALL_DIR}/(includes|logs)">
        Require all denied
    </DirectoryMatch>

    <FilesMatch "\\.php\$">
        SetHandler application/x-httpd-php
    </FilesMatch>

    ErrorLog  \${APACHE_LOG_DIR}/tati-platform_error.log
    CustomLog \${APACHE_LOG_DIR}/tati-platform_access.log combined
</VirtualHost>
VHEOF

    if [[ "$PKG_MGR" == "apt" ]]; then
        asroot a2ensite tati-platform.conf  >> "$LOG_FILE" 2>&1 || true
        asroot a2dissite 000-default.conf   >> "$LOG_FILE" 2>&1 || true
        asroot a2enmod rewrite              >> "$LOG_FILE" 2>&1 || true
        asroot a2enmod "php${PHP_VER}"      >> "$LOG_FILE" 2>&1 || true
        asroot apachectl configtest         >> "$LOG_FILE" 2>&1 \
            && asroot systemctl reload apache2 >> "$LOG_FILE" 2>&1 || true
    else
        asroot apachectl configtest >> "$LOG_FILE" 2>&1 \
            && asroot systemctl reload httpd >> "$LOG_FILE" 2>&1 || true
    fi

    ok "VirtualHost configurado: ${conf_path}"

    if [[ "$USE_SSL" == true ]] && [[ "$DOMAIN" != "localhost" ]]; then
        _configure_ssl
    fi
}

_configure_ssl() {
    command -v certbot &>/dev/null || {
        spin_start "Instalando certbot"
        if [[ "$PKG_MGR" == "apt" ]]; then
            asroot apt-get install -y -qq certbot python3-certbot-apache >> "$LOG_FILE" 2>&1
        else
            asroot $PKG_MGR install -y certbot python3-certbot-apache >> "$LOG_FILE" 2>&1
        fi
        spin_stop; ok "Certbot instalado"
    }

    spin_start "Obtendo SSL para ${DOMAIN}"
    asroot certbot --apache -d "$DOMAIN" \
        --non-interactive --agree-tos --email "$ADMIN_EMAIL" \
        >> "$LOG_FILE" 2>&1 \
        && { spin_stop; ok "SSL ativo para ${DOMAIN}"; } \
        || { spin_stop; warn "Certbot falhou — configure SSL manualmente."; }
}

# ══════════════════════════════════════════════════════════════════════
# DEPENDÊNCIAS EXTRAS + FIREWALL
# ══════════════════════════════════════════════════════════════════════
install_extras() {
    step "Instalando dependências extras"
    local pkgs=()
    command -v curl  &>/dev/null || pkgs+=("curl")
    command -v unzip &>/dev/null || pkgs+=("unzip")
    command -v git   &>/dev/null || pkgs+=("git")

    if [[ ${#pkgs[@]} -gt 0 ]]; then
        spin_start "Instalando: ${pkgs[*]}"
        [[ "$PKG_MGR" == "apt" ]] \
            && asroot apt-get install -y -qq "${pkgs[@]}" >> "$LOG_FILE" 2>&1 \
            || asroot $PKG_MGR install -y "${pkgs[@]}" >> "$LOG_FILE" 2>&1
        spin_stop; ok "Extras: ${pkgs[*]}"
    else
        ok "Extras já presentes"
    fi

    # Firewall
    if command -v ufw &>/dev/null; then
        spin_start "UFW: liberando portas 80/443"
        asroot ufw allow 80/tcp  >> "$LOG_FILE" 2>&1 || true
        asroot ufw allow 443/tcp >> "$LOG_FILE" 2>&1 || true
        spin_stop; ok "UFW: 80 e 443 liberadas"
    elif command -v firewall-cmd &>/dev/null; then
        spin_start "Firewalld: liberando http/https"
        asroot firewall-cmd --permanent --add-service=http  >> "$LOG_FILE" 2>&1 || true
        asroot firewall-cmd --permanent --add-service=https >> "$LOG_FILE" 2>&1 || true
        asroot firewall-cmd --reload >> "$LOG_FILE" 2>&1 || true
        spin_stop; ok "Firewalld: http/https liberados"
    fi
}

# ══════════════════════════════════════════════════════════════════════
# VERIFICAÇÃO FINAL
# ══════════════════════════════════════════════════════════════════════
run_health_check() {
    step "Verificação final"
    local errors=0

    local -a critical=(
        "index.php" "includes/config.php" "includes/claude.service.php"
        "api/auth.php" "api/generate.php" "api/projects.php"
        "api/report.php" "pages/dashboard.php" "database.sql"
    )
    for f in "${critical[@]}"; do
        [[ -f "${INSTALL_DIR}/${f}" ]] && ok "${f}" || { err "Faltando: ${f}"; ((errors++)); }
    done

    for d in uploads uploads/reports logs; do
        [[ -w "${INSTALL_DIR}/${d}" ]] \
            && ok "${d}/ gravável ✓" \
            || { warn "${d}/ sem permissão de escrita"; ((errors++)); }
    done

    # PHP funcional
    command -v php &>/dev/null && {
        [[ "$(php -r "echo 'ok';" 2>/dev/null)" == "ok" ]] \
            && ok "PHP funcional ✓" || { warn "PHP com problema"; ((errors++)); }
    }

    # DB via PHP
    spin_start "Testando PHP → MariaDB"
    local dbt
    dbt=$(php -r "
        try {
            \$p = new PDO('mysql:host=localhost;dbname=${DB_NAME};charset=utf8mb4',
                         '${DB_USER}','${DB_PASS}');
            echo 'ok:'.\$p->query('SELECT COUNT(*) FROM users')->fetchColumn();
        } catch(Exception \$e){ echo 'err:'.\$e->getMessage(); }
    " 2>/dev/null || echo "err:PHP falhou")
    spin_stop
    [[ "$dbt" == ok:* ]] \
        && ok "Banco OK — ${dbt#ok:} usuário(s)" \
        || { warn "DB: ${dbt}"; ((errors++)); }

    # Apache
    systemctl is-active --quiet apache2 2>/dev/null \
        || systemctl is-active --quiet httpd 2>/dev/null \
        && ok "Apache em execução ✓" \
        || { warn "Apache não está rodando"; ((errors++)); }

    # Claude API
    if [[ -n "$CLAUDE_API_KEY" ]] && [[ "$CLAUDE_API_KEY" =~ ^sk-ant- ]]; then
        spin_start "Testando API Claude"
        local hc; hc=$(curl -s -o /dev/null -w "%{http_code}" \
            -H "x-api-key: ${CLAUDE_API_KEY}" \
            -H "anthropic-version: 2023-06-01" \
            "https://api.anthropic.com/v1/models" 2>/dev/null || echo "000")
        spin_stop
        [[ "$hc" == "200" ]] && ok "Claude API OK ✓" \
            || warn "Claude API retornou HTTP ${hc}"
    fi

    [[ $errors -gt 0 ]] \
        && warn "${errors} problema(s) — log: ${LOG_FILE}" \
        || ok "Tudo verificado sem erros ✓"

    return $errors
}

# ══════════════════════════════════════════════════════════════════════
# TELA FINAL
# ══════════════════════════════════════════════════════════════════════
print_success() {
    echo ""
    echo -e "${G}${W}"
    echo "  ╔══════════════════════════════════════════════════════════╗"
    echo "  ║                                                          ║"
    echo "  ║    ✓  INSTALAÇÃO CONCLUÍDA COM SUCESSO!                  ║"
    echo "  ║                                                          ║"
    echo -e "  ╚══════════════════════════════════════════════════════════╝${X}"
    echo ""
    echo -e "  ${W}🌐  Acesse agora:${X}"
    echo -e "      ${C}${BASE_URL}${X}"
    echo ""
    echo -e "  ${W}🔑  Login do administrador:${X}"
    echo -e "      ${D}E-mail:${X}   ${ADMIN_EMAIL}"
    echo -e "      ${D}Senha:${X}    ${Y}(a que você definiu)${X}"
    echo ""
    echo -e "  ${W}🗄️   Banco de dados criado automaticamente:${X}"
    echo -e "      ${D}Banco:${X}    ${DB_NAME}"
    echo -e "      ${D}Usuário:${X}  ${DB_USER}"
    echo -e "      ${D}Senha:${X}    ${G}${DB_PASS}${X}"
    echo -e "      ${D}→ Salva em: ${INSTALL_DIR}/includes/config.php${X}"
    echo ""
    echo -e "  ${W}📦  Stack instalada automaticamente:${X}"
    echo -e "      ${G}✓${X}  Apache 2.4  +  mod_rewrite"
    echo -e "      ${G}✓${X}  PHP ${PHP_VER}  +  pdo_mysql, curl, mbstring, xml, zip, opcache"
    echo -e "      ${G}✓${X}  MariaDB  +  banco + usuário"
    echo -e "      ${G}✓${X}  VirtualHost configurado"
    echo ""
    echo -e "  ${W}📋  Log:${X}  ${LOG_FILE}"
    echo ""
    div
    echo ""
    echo -e "  ${Y}${W}⚠  PRÓXIMOS PASSOS:${X}"
    echo ""
    echo -e "  1. Acesse ${C}${BASE_URL}${X} e faça login"
    echo -e "  2. Configure a Claude API Key em → Configurações"
    echo -e "  3. Remova database.sql do servidor (segurança):"
    echo -e "     ${C}sudo rm ${INSTALL_DIR}/database.sql${X}"
    echo ""
}

print_failure() {
    echo ""
    echo -e "${R}${W}  ╔══════════════════════════════════════════════════╗"
    echo    "  ║    ✗  INSTALAÇÃO FALHOU                          ║"
    echo -e "  ╚══════════════════════════════════════════════════╝${X}"
    echo ""
    echo -e "  Log: ${C}${LOG_FILE}${X}"; echo ""
    echo -e "  ${D}Últimas linhas:${X}"; echo ""
    tail -20 "$LOG_FILE" | sed 's/^/    /'
    echo ""
}

# ══════════════════════════════════════════════════════════════════════
# TRAP
# ══════════════════════════════════════════════════════════════════════
_on_error() {
    spin_stop
    err "Erro na linha $1 (código $2)"
    print_failure
    exit 1
}
trap '_on_error $LINENO $?' ERR

# ══════════════════════════════════════════════════════════════════════
# DESINSTALAÇÃO
# ══════════════════════════════════════════════════════════════════════
uninstall() {
    clear
    echo -e "${R}${W}  DESINSTALAÇÃO — Tati Indicando Studio${X}\n"
    printf "  Diretório [/var/www/html/tati-platform]: "
    read -r rm_dir; rm_dir="${rm_dir:-/var/www/html/tati-platform}"
    [[ -d "$rm_dir" ]] || fatal "Não encontrado: ${rm_dir}"
    echo -e "  ${R}Remove ${rm_dir} permanentemente. Digite 'sim':${X} \c"
    read -r confirm; [[ "$confirm" == "sim" ]] || { info "Cancelado."; exit 0; }

    asroot rm -rf "$rm_dir"; ok "Removido: ${rm_dir}"
    printf "  Remover banco '${DB_NAME}'? (s/n): "; read -r d
    [[ "$d" =~ ^[Ss]$ ]] && {
        mysql_root --execute="
            DROP DATABASE IF EXISTS \`${DB_NAME}\`;
            DROP USER IF EXISTS '${DB_USER}'@'localhost';
            FLUSH PRIVILEGES;
        " 2>/dev/null && ok "Banco e usuário removidos" || warn "Remova manualmente."
    }
    ok "Desinstalação concluída."
}

# ══════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════
main() {
    {   echo "=== ${APP_NAME} v${APP_VERSION} ==="
        echo "Data:    $(date)"
        echo "Usuário: $(whoami)"
        echo "Dir:     ${SCRIPT_DIR}"
        echo ""
    } > "$LOG_FILE"

    clear
    detect_system
    collect_config

    echo ""
    step "INICIANDO INSTALAÇÃO AUTOMÁTICA DA STACK LAMP"
    echo ""

    install_extras       # curl, unzip, git, firewall
    install_apache       # Apache 2.4 + mod_rewrite
    install_php          # PHP 8.2 + extensões
    install_mariadb      # MariaDB
    install_app_files    # Copiar arquivos
    set_permissions      # chmod + chown
    write_config         # config.php
    setup_database       # banco + usuário + schema + admin
    configure_php_ini    # php.ini otimizado
    configure_apache     # VirtualHost

    run_health_check && print_success || { warn "Concluído com avisos."; print_success; }
}

# ── ARGUMENTOS ──────────────────────────────────────────────────────────
case "${1:-}" in
    --uninstall|-u) uninstall ;;
    --help|-h)
        echo ""
        echo "  ${APP_NAME} — Instalador v${APP_VERSION}"
        echo ""
        echo "  Uso:"
        echo "    sudo bash install.sh              Instala tudo automaticamente"
        echo "    sudo bash install.sh --uninstall  Remove a plataforma"
        echo "    sudo bash install.sh --help       Esta ajuda"
        echo ""
        echo "  Instala automaticamente:"
        echo "    • Apache 2.4 + mod_rewrite + mod_php"
        echo "    • PHP 8.2 + pdo_mysql, curl, mbstring, xml, zip, opcache"
        echo "    • MariaDB + banco '${DB_NAME}' + usuário '${DB_USER}' (senha auto)"
        echo "    • Aplicação Tati Indicando Studio"
        echo "    • VirtualHost, permissões, php.ini otimizado"
        echo ""
        ;;
    *) main ;;
esac
