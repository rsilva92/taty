#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║       TATI INDICANDO — STUDIO · INSTALADOR AUTOMATIZADO         ║
# ║                        Versão 1.0.0                             ║
# ╚══════════════════════════════════════════════════════════════════╝
#
# USO:
#   chmod +x install.sh
#   ./install.sh
#
# REQUISITOS:
#   - Linux (Ubuntu 20.04+ / Debian 11+ / CentOS 8+)
#   - Bash 4+
#   - Conexão com internet
#   - Usuário com sudo OU root

set -euo pipefail
IFS=$'\n\t'

# ──────────────────────────────────────────────
# CONSTANTES
# ──────────────────────────────────────────────
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly LOG_FILE="/tmp/tati_install_$(date +%Y%m%d_%H%M%S).log"
readonly APP_NAME="Tati Indicando Studio"
readonly APP_VERSION="1.0.0"
readonly MIN_PHP="8.1"
readonly MIN_MYSQL="5.7"

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

# ──────────────────────────────────────────────
# VARIÁVEIS GLOBAIS (preenchidas pelo usuário)
# ──────────────────────────────────────────────
INSTALL_DIR=""
DB_HOST="localhost"
DB_PORT="3306"
DB_NAME="tati_platform"
DB_USER=""
DB_PASS=""
DB_ROOT_PASS=""
CREATE_DB_USER=false
CLAUDE_API_KEY=""
BASE_URL=""
ADMIN_NAME=""
ADMIN_EMAIL=""
ADMIN_PASS=""
WEB_SERVER=""       # apache | nginx | none
PHP_VERSION=""
CONFIGURE_VHOST=false
DOMAIN=""
USE_SSL=false
INSTALL_COMPOSER=false

# ──────────────────────────────────────────────
# LOGGING
# ──────────────────────────────────────────────
log() { echo "[$(date '+%H:%M:%S')] $*" >> "$LOG_FILE"; }

# ──────────────────────────────────────────────
# FUNÇÕES DE SAÍDA
# ──────────────────────────────────────────────
print_banner() {
    clear
    echo -e "${MAGENTA}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════╗"
    echo "  ║                                                          ║"
    echo "  ║    ✦  TATI INDICANDO — STUDIO                           ║"
    echo "  ║       Instalador Automatizado v${APP_VERSION}                    ║"
    echo "  ║                                                          ║"
    echo "  ╚══════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    echo -e "  ${DIM}Log sendo salvo em: ${LOG_FILE}${RESET}"
    echo ""
}

step() {
    echo -e "\n${BLUE}${BOLD}  ▶  $1${RESET}"
    log "STEP: $1"
}

info() {
    echo -e "  ${CYAN}ℹ  $1${RESET}"
    log "INFO: $1"
}

ok() {
    echo -e "  ${GREEN}✓  $1${RESET}"
    log "OK: $1"
}

warn() {
    echo -e "  ${YELLOW}⚠  $1${RESET}"
    log "WARN: $1"
}

err() {
    echo -e "\n  ${RED}${BOLD}✗  ERRO: $1${RESET}"
    log "ERROR: $1"
}

fatal() {
    err "$1"
    echo -e "\n  ${DIM}Verifique o log: ${LOG_FILE}${RESET}\n"
    exit 1
}

divider() {
    echo -e "  ${DIM}──────────────────────────────────────────────────────────${RESET}"
}

# ──────────────────────────────────────────────
# SPINNER
# ──────────────────────────────────────────────
spinner_pid=""
start_spinner() {
    local msg="$1"
    local frames=('⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏')
    printf "  ${CYAN}"
    (
        i=0
        while true; do
            printf "\r  ${CYAN}${frames[$((i % 10))]}  ${msg}${RESET}   "
            sleep 0.08
            ((i++))
        done
    ) &
    spinner_pid=$!
    disown
}

stop_spinner() {
    if [[ -n "$spinner_pid" ]] && kill -0 "$spinner_pid" 2>/dev/null; then
        kill "$spinner_pid" 2>/dev/null
        wait "$spinner_pid" 2>/dev/null || true
    fi
    printf "\r\033[K"
    spinner_pid=""
}

run_quiet() {
    local msg="$1"
    shift
    start_spinner "$msg"
    if "$@" >> "$LOG_FILE" 2>&1; then
        stop_spinner
        ok "$msg"
        return 0
    else
        stop_spinner
        err "$msg"
        return 1
    fi
}

# ──────────────────────────────────────────────
# INSTALAÇÃO DE EXTENSÕES PHP FALTANTES
# ──────────────────────────────────────────────
install_php_extensions() {
    local missing=("$@")
    [[ ${#missing[@]} -eq 0 ]] && return 0

    if [[ "$PKG_MGR" == "none" ]]; then
        warn "Não foi possível instalar extensões automaticamente (sem package manager)."
        warn "Instale manualmente: ${missing[*]}"
        return 0
    fi

    # Detectar versão curta do PHP: "8.2.x" → "8.2"
    local php_ver
    php_ver=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;" 2>/dev/null || echo "8.2")

    # Mapeamento ext → nome real do pacote por distro
    # apt  (Debian/Ubuntu/Mint): php8.2-mysql, php8.2-curl, etc.
    # dnf/yum (RHEL/CentOS/Fedora/Rocky): php-mysqlnd, php-curl, etc.
    declare -A apt_map=(
        [pdo]="php${php_ver}-common"        # PDO já vem no common; instalar garante
        [pdo_mysql]="php${php_ver}-mysql"
        [curl]="php${php_ver}-curl"
        [json]="php${php_ver}-json"         # json é embutido no 8.x, mas o pacote existe
        [mbstring]="php${php_ver}-mbstring"
        [openssl]="php${php_ver}-openssl"   # openssl vem com o core; o pacote garante
        [session]="php${php_ver}-common"    # session é embutido — common cobre
        [xml]="php${php_ver}-xml"
        [zip]="php${php_ver}-zip"
    )

    declare -A rpm_map=(
        [pdo]="php-pdo"
        [pdo_mysql]="php-mysqlnd"
        [curl]="php-curl"
        [json]="php-json"
        [mbstring]="php-mbstring"
        [openssl]="php-openssl"
        [session]="php-common"
        [xml]="php-xml"
        [zip]="php-zip"
    )

    local pkg_list=()

    if [[ "$PKG_MGR" == "apt" ]]; then
        # Atualizar índice antes de instalar (silencioso)
        start_spinner "Atualizando índice de pacotes"
        run_as_root apt-get update -qq >> "$LOG_FILE" 2>&1 || true
        stop_spinner

        for ext in "${missing[@]}"; do
            local pkg="${apt_map[$ext]:-}"
            if [[ -n "$pkg" ]]; then
                # Verifica se o pacote existe antes de adicionar
                if apt-cache show "$pkg" >> "$LOG_FILE" 2>&1; then
                    pkg_list+=("$pkg")
                else
                    # Fallback: tentar php-<ext> sem versão
                    local fallback="php-${ext//_/-}"
                    if apt-cache show "$fallback" >> "$LOG_FILE" 2>&1; then
                        pkg_list+=("$fallback")
                    fi
                fi
            fi
        done

        # Remover duplicatas
        local unique_pkgs
        mapfile -t unique_pkgs < <(printf '%s\n' "${pkg_list[@]}" | sort -u)

        if [[ ${#unique_pkgs[@]} -gt 0 ]]; then
            start_spinner "Instalando extensões: ${unique_pkgs[*]}"
            run_as_root apt-get install -y -qq "${unique_pkgs[@]}" >> "$LOG_FILE" 2>&1
            local exit_code=$?
            stop_spinner
            if [[ $exit_code -eq 0 ]]; then
                ok "Extensões instaladas: ${unique_pkgs[*]}"
                # Reiniciar PHP-FPM se estiver rodando
                if systemctl is-active --quiet "php${php_ver}-fpm" 2>/dev/null; then
                    run_as_root systemctl restart "php${php_ver}-fpm" >> "$LOG_FILE" 2>&1 || true
                fi
            else
                warn "Alguns pacotes falharam. Verifique o log: ${LOG_FILE}"
            fi
        fi

    elif [[ "$PKG_MGR" == "dnf" ]] || [[ "$PKG_MGR" == "yum" ]]; then
        for ext in "${missing[@]}"; do
            local pkg="${rpm_map[$ext]:-}"
            [[ -n "$pkg" ]] && pkg_list+=("$pkg")
        done

        local unique_pkgs
        mapfile -t unique_pkgs < <(printf '%s\n' "${pkg_list[@]}" | sort -u)

        if [[ ${#unique_pkgs[@]} -gt 0 ]]; then
            start_spinner "Instalando extensões: ${unique_pkgs[*]}"
            run_as_root $PKG_MGR install -y "${unique_pkgs[@]}" >> "$LOG_FILE" 2>&1
            local exit_code=$?
            stop_spinner
            if [[ $exit_code -eq 0 ]]; then
                ok "Extensões instaladas: ${unique_pkgs[*]}"
            else
                warn "Alguns pacotes falharam. Verifique o log: ${LOG_FILE}"
            fi
        fi
    fi

    # Re-verificar após instalação
    local still_missing=()
    for ext in "${missing[@]}"; do
        if ! php -r "exit(extension_loaded('${ext}') ? 0 : 1);" 2>/dev/null; then
            # json e openssl são embutidos no PHP 8 — não contam como falta real
            if [[ "$ext" != "json" ]] && [[ "$ext" != "openssl" ]] && [[ "$ext" != "session" ]]; then
                still_missing+=("$ext")
            fi
        fi
    done

    if [[ ${#still_missing[@]} -gt 0 ]]; then
        warn "Ainda faltando após instalação: ${still_missing[*]}"
        warn "Instale manualmente e execute o instalador novamente."
    else
        ok "Todas as extensões PHP verificadas ✓"
    fi
}

# ──────────────────────────────────────────────
# DETECÇÃO DO SISTEMA
# ──────────────────────────────────────────────
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS_ID="${ID:-unknown}"
        OS_VERSION="${VERSION_ID:-unknown}"
        OS_NAME="${PRETTY_NAME:-Linux}"
    elif [[ "$(uname)" == "Darwin" ]]; then
        OS_ID="macos"
        OS_NAME="macOS"
    else
        OS_ID="unknown"
        OS_NAME="Sistema desconhecido"
    fi
    log "OS detectado: $OS_NAME"
}

detect_package_manager() {
    if command -v apt-get &>/dev/null; then
        PKG_MGR="apt"
        PKG_UPDATE="apt-get update -qq"
        PKG_INSTALL="apt-get install -y -qq"
    elif command -v dnf &>/dev/null; then
        PKG_MGR="dnf"
        PKG_UPDATE="dnf check-update -q || true"
        PKG_INSTALL="dnf install -y -q"
    elif command -v yum &>/dev/null; then
        PKG_MGR="yum"
        PKG_UPDATE="yum check-update -q || true"
        PKG_INSTALL="yum install -y -q"
    else
        PKG_MGR="none"
    fi
    log "Package manager: $PKG_MGR"
}

is_root() { [[ $EUID -eq 0 ]]; }

can_sudo() { sudo -n true 2>/dev/null; }

run_as_root() {
    if is_root; then
        "$@"
    elif can_sudo; then
        sudo "$@"
    else
        fatal "Este comando precisa de privilégios root. Execute como root ou configure o sudo."
    fi
}

# ──────────────────────────────────────────────
# VERIFICAÇÕES DE PRÉ-REQUISITOS
# ──────────────────────────────────────────────
check_prerequisites() {
    step "Verificando pré-requisitos do sistema"

    # PHP
    if command -v php &>/dev/null; then
        PHP_VERSION=$(php -r "echo PHP_VERSION;")
        PHP_MAJOR=$(php -r "echo PHP_MAJOR_VERSION;")
        PHP_MINOR=$(php -r "echo PHP_MINOR_VERSION;")
        if [[ $PHP_MAJOR -ge 8 ]] && [[ $PHP_MINOR -ge 1 ]]; then
            ok "PHP ${PHP_VERSION} (✓ >= ${MIN_PHP})"
        else
            warn "PHP ${PHP_VERSION} encontrado — requer >= ${MIN_PHP}"
            offer_install_php
        fi
    else
        warn "PHP não encontrado"
        offer_install_php
    fi

    # Extensões PHP necessárias
    # Usamos php -r extension_loaded() — imune a variações de capitalização e módulos embutidos
    local required_exts=("pdo" "pdo_mysql" "curl" "json" "mbstring" "openssl")
    local missing_exts=()

    if ! command -v php &>/dev/null; then
        warn "PHP não encontrado — pulando verificação de extensões."
    else
        for ext in "${required_exts[@]}"; do
            if php -r "exit(extension_loaded('${ext}') ? 0 : 1);" 2>/dev/null; then
                log "ext OK: ${ext}"
            else
                missing_exts+=("$ext")
                log "ext MISSING: ${ext}"
            fi
        done

        # 'session' é sempre embutido no PHP — verificar separadamente via php -m
        if ! php -m 2>/dev/null | grep -qi "session"; then
            missing_exts+=("session")
        fi

        if [[ ${#missing_exts[@]} -eq 0 ]]; then
            ok "Extensões PHP: pdo, pdo_mysql, curl, json, mbstring, openssl, session ✓"
        else
            warn "Extensões PHP faltando: ${missing_exts[*]}"
            install_php_extensions "${missing_exts[@]}"
        fi
    fi

    # MySQL / MariaDB
    if command -v mysql &>/dev/null; then
        MYSQL_VERSION=$(mysql --version 2>/dev/null | grep -oP '[\d]+\.[\d]+\.[\d]+' | head -1)
        ok "MySQL/MariaDB ${MYSQL_VERSION} encontrado"
    elif command -v mariadb &>/dev/null; then
        ok "MariaDB encontrado"
        shopt -s expand_aliases
        alias mysql='mariadb'
    else
        warn "MySQL/MariaDB não encontrado"
        offer_install_mysql
    fi

    # Servidor web
    detect_web_server

    # curl
    if command -v curl &>/dev/null; then
        ok "curl disponível"
    else
        warn "curl não encontrado — instalando..."
        if [[ "$PKG_MGR" == "apt" ]]; then
            run_as_root apt-get install -y -qq curl >> "$LOG_FILE" 2>&1 || warn "Instale o curl manualmente"
        elif [[ "$PKG_MGR" == "dnf" ]] || [[ "$PKG_MGR" == "yum" ]]; then
            run_as_root $PKG_MGR install -y curl >> "$LOG_FILE" 2>&1 || warn "Instale o curl manualmente"
        fi
    fi

    # zip/unzip
    if command -v unzip &>/dev/null; then
        ok "unzip disponível"
    else
        if [[ "$PKG_MGR" == "apt" ]]; then
            run_as_root apt-get install -y -qq unzip >> "$LOG_FILE" 2>&1 || true
        elif [[ "$PKG_MGR" == "dnf" ]] || [[ "$PKG_MGR" == "yum" ]]; then
            run_as_root $PKG_MGR install -y unzip >> "$LOG_FILE" 2>&1 || true
        fi
    fi

    ok "Verificação de pré-requisitos concluída"
}

detect_web_server() {
    if command -v apache2 &>/dev/null || command -v httpd &>/dev/null; then
        WEB_SERVER="apache"
        ok "Apache detectado"
    elif command -v nginx &>/dev/null; then
        WEB_SERVER="nginx"
        ok "Nginx detectado"
    else
        WEB_SERVER="none"
        warn "Nenhum servidor web detectado"
    fi
}

offer_install_php() {
    if [[ "$PKG_MGR" == "none" ]]; then
        fatal "PHP >= 8.1 é obrigatório. Instale manualmente e execute o instalador novamente."
    fi
    echo ""
    echo -e "  ${YELLOW}Deseja instalar o PHP 8.2 agora? (s/n):${RESET} \c"
    read -r choice
    if [[ "$choice" =~ ^[Ss]$ ]]; then
        install_php
    else
        fatal "PHP >= 8.1 é obrigatório para continuar."
    fi
}

install_php() {
    step "Instalando PHP 8.2 e extensões"
    if [[ "$PKG_MGR" == "apt" ]]; then
        start_spinner "Instalando dependências base"
        run_as_root apt-get install -y -qq software-properties-common >> "$LOG_FILE" 2>&1
        stop_spinner; ok "software-properties-common"

        start_spinner "Adicionando repositório ppa:ondrej/php"
        run_as_root add-apt-repository -y ppa:ondrej/php >> "$LOG_FILE" 2>&1 || true
        run_as_root apt-get update -qq >> "$LOG_FILE" 2>&1
        stop_spinner; ok "Repositório PHP adicionado"

        start_spinner "Instalando PHP 8.2 e extensões essenciais"
        run_as_root apt-get install -y -qq \
            php8.2 php8.2-cli php8.2-fpm \
            php8.2-mysql php8.2-curl php8.2-mbstring \
            php8.2-xml php8.2-zip php8.2-json \
            php8.2-common php8.2-opcache >> "$LOG_FILE" 2>&1
        stop_spinner; ok "PHP 8.2 instalado"

    elif [[ "$PKG_MGR" == "dnf" ]] || [[ "$PKG_MGR" == "yum" ]]; then
        start_spinner "Instalando EPEL + Remi"
        run_as_root $PKG_MGR install -y epel-release >> "$LOG_FILE" 2>&1 || true
        run_as_root $PKG_MGR install -y "https://rpms.remirepo.net/enterprise/remi-release-$(rpm -E '%{rhel}').rpm" >> "$LOG_FILE" 2>&1 || true
        stop_spinner; ok "EPEL/Remi configurado"

        start_spinner "Instalando PHP 8.2"
        run_as_root $PKG_MGR module enable -y php:remi-8.2 >> "$LOG_FILE" 2>&1 || true
        run_as_root $PKG_MGR install -y \
            php php-cli php-fpm \
            php-mysqlnd php-pdo \
            php-curl php-mbstring \
            php-xml php-zip php-json \
            php-common php-opcache >> "$LOG_FILE" 2>&1
        stop_spinner; ok "PHP 8.2 instalado"
    fi
    PHP_VERSION=$(php -r "echo PHP_VERSION;" 2>/dev/null || echo "8.2")
    ok "PHP ${PHP_VERSION} instalado"
}

offer_install_mysql() {
    if [[ "$PKG_MGR" == "none" ]]; then
        fatal "MySQL/MariaDB é obrigatório. Instale manualmente e execute novamente."
    fi
    echo ""
    echo -e "  ${YELLOW}Deseja instalar o MariaDB agora? (s/n):${RESET} \c"
    read -r choice
    if [[ "$choice" =~ ^[Ss]$ ]]; then
        install_mariadb
    else
        fatal "MySQL/MariaDB é obrigatório para continuar."
    fi
}

install_mariadb() {
    step "Instalando MariaDB"
    if [[ "$PKG_MGR" == "apt" ]]; then
        start_spinner "Instalando MariaDB Server"
        run_as_root apt-get install -y -qq mariadb-server mariadb-client >> "$LOG_FILE" 2>&1
        stop_spinner; ok "MariaDB instalado"
    elif [[ "$PKG_MGR" == "dnf" ]] || [[ "$PKG_MGR" == "yum" ]]; then
        start_spinner "Instalando MariaDB Server"
        run_as_root $PKG_MGR install -y mariadb-server mariadb >> "$LOG_FILE" 2>&1
        stop_spinner; ok "MariaDB instalado"
    fi

    start_spinner "Iniciando MariaDB"
    run_as_root systemctl start mariadb >> "$LOG_FILE" 2>&1 || \
        run_as_root service mariadb start >> "$LOG_FILE" 2>&1 || true
    stop_spinner

    start_spinner "Habilitando MariaDB no boot"
    run_as_root systemctl enable mariadb >> "$LOG_FILE" 2>&1 || true
    stop_spinner

    ok "MariaDB instalado e iniciado"
}

# ──────────────────────────────────────────────
# COLETA INTERATIVA DE CONFIGURAÇÕES
# ──────────────────────────────────────────────
collect_config() {
    print_banner
    echo -e "  ${BOLD}Configuração da Instalação${RESET}"
    echo -e "  Responda as perguntas abaixo. Pressione ENTER para usar o valor padrão."
    echo ""

    # ── DIRETÓRIO DE INSTALAÇÃO
    divider
    echo -e "  ${BOLD}📁  DIRETÓRIO DE INSTALAÇÃO${RESET}"
    echo ""

    local default_dir="/var/www/html/tati-platform"
    if [[ "$WEB_SERVER" == "nginx" ]]; then
        default_dir="/var/www/tati-platform"
    fi

    echo -e "  ${DIM}Diretório padrão: ${default_dir}${RESET}"
    printf "  Diretório de instalação [${default_dir}]: "
    read -r input
    INSTALL_DIR="${input:-$default_dir}"

    # ── BANCO DE DADOS
    divider
    echo -e "  ${BOLD}🗄️   BANCO DE DADOS${RESET}"
    echo ""

    printf "  Host MySQL [localhost]: "
    read -r input; DB_HOST="${input:-localhost}"

    printf "  Porta MySQL [3306]: "
    read -r input; DB_PORT="${input:-3306}"

    printf "  Nome do banco [tati_platform]: "
    read -r input; DB_NAME="${input:-tati_platform}"

    echo ""
    echo -e "  ${YELLOW}Você já tem um usuário MySQL criado para esta aplicação? (s/n):${RESET} \c"
    read -r has_user

    if [[ "$has_user" =~ ^[Ss]$ ]]; then
        printf "  Usuário MySQL da aplicação: "
        read -r DB_USER
        printf "  Senha do usuário MySQL: "
        read -rs DB_PASS; echo ""
    else
        CREATE_DB_USER=true
        printf "  Nome do novo usuário MySQL [tati_app]: "
        read -r input; DB_USER="${input:-tati_app}"

        while true; do
            printf "  Senha para o novo usuário: "
            read -rs DB_PASS; echo ""
            printf "  Confirme a senha: "
            read -rs db_pass2; echo ""
            if [[ "$DB_PASS" == "$db_pass2" ]]; then
                break
            else
                warn "Senhas não conferem. Tente novamente."
            fi
        done

        echo ""
        echo -e "  ${DIM}Preciso da senha root do MySQL para criar o usuário.${RESET}"
        printf "  Senha root do MySQL (ENTER se sem senha): "
        read -rs DB_ROOT_PASS; echo ""
    fi

    # ── API CLAUDE
    divider
    echo -e "  ${BOLD}🤖  API DO CLAUDE (ANTHROPIC)${RESET}"
    echo ""
    echo -e "  ${DIM}Obtenha sua chave em: https://console.anthropic.com/api-keys${RESET}"
    echo ""

    while true; do
        printf "  Claude API Key (sk-ant-...): "
        read -rs CLAUDE_API_KEY; echo ""
        if [[ "$CLAUDE_API_KEY" =~ ^sk-ant- ]]; then
            ok "Formato da API Key válido"
            break
        elif [[ -z "$CLAUDE_API_KEY" ]]; then
            warn "API Key não informada — você pode configurar manualmente depois em includes/config.php"
            break
        else
            warn "API Key não parece válida (deve começar com 'sk-ant-'). Tente novamente."
        fi
    done

    # ── URL BASE
    divider
    echo -e "  ${BOLD}🌐  CONFIGURAÇÃO WEB${RESET}"
    echo ""

    printf "  Domínio ou IP do servidor (ex: meusite.com.br): "
    read -r DOMAIN

    if [[ -n "$DOMAIN" ]]; then
        printf "  Usar HTTPS? (s/n) [n]: "
        read -r use_ssl
        if [[ "$use_ssl" =~ ^[Ss]$ ]]; then
            USE_SSL=true
            BASE_URL="https://${DOMAIN}/tati-platform"
        else
            BASE_URL="http://${DOMAIN}/tati-platform"
        fi
    else
        BASE_URL="http://localhost/tati-platform"
    fi

    echo -e "  URL base configurada: ${CYAN}${BASE_URL}${RESET}"

    # ── CONTA ADMIN
    divider
    echo -e "  ${BOLD}👤  CONTA DO ADMINISTRADOR${RESET}"
    echo ""

    printf "  Nome do administrador [Administrador]: "
    read -r input; ADMIN_NAME="${input:-Administrador}"

    printf "  E-mail do administrador: "
    read -r ADMIN_EMAIL
    if [[ -z "$ADMIN_EMAIL" ]]; then
        ADMIN_EMAIL="admin@tatiindicando.com"
        info "E-mail padrão: ${ADMIN_EMAIL}"
    fi

    while true; do
        printf "  Senha do administrador (min. 8 chars): "
        read -rs ADMIN_PASS; echo ""
        if [[ ${#ADMIN_PASS} -ge 8 ]]; then
            printf "  Confirme a senha: "
            read -rs pass2; echo ""
            if [[ "$ADMIN_PASS" == "$pass2" ]]; then
                break
            else
                warn "Senhas não conferem."
            fi
        else
            warn "A senha deve ter pelo menos 8 caracteres."
        fi
    done

    # ── VHOST (opcional)
    divider
    if [[ "$WEB_SERVER" != "none" ]] && [[ -n "$DOMAIN" ]]; then
        echo -e "  ${BOLD}⚙️   VIRTUAL HOST${RESET}"
        echo ""
        echo -e "  ${YELLOW}Deseja que o instalador configure o Virtual Host automaticamente? (s/n):${RESET} \c"
        read -r vhost_choice
        if [[ "$vhost_choice" =~ ^[Ss]$ ]]; then
            CONFIGURE_VHOST=true
        fi
    fi

    # ── RESUMO
    divider
    echo ""
    echo -e "  ${BOLD}📋  RESUMO DA CONFIGURAÇÃO${RESET}"
    echo ""
    echo -e "  ${DIM}Diretório:${RESET}   ${INSTALL_DIR}"
    echo -e "  ${DIM}Banco:${RESET}       ${DB_NAME} @ ${DB_HOST}:${DB_PORT}"
    echo -e "  ${DIM}Usuário DB:${RESET}  ${DB_USER}"
    echo -e "  ${DIM}URL Base:${RESET}    ${BASE_URL}"
    echo -e "  ${DIM}Admin:${RESET}       ${ADMIN_NAME} <${ADMIN_EMAIL}>"
    echo -e "  ${DIM}API Key:${RESET}     ${CLAUDE_API_KEY:0:20}..."
    echo ""
    echo -e "  ${YELLOW}${BOLD}Confirma e inicia a instalação? (s/n):${RESET} \c"
    read -r confirm
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        echo ""
        info "Instalação cancelada pelo usuário."
        exit 0
    fi
}

# ──────────────────────────────────────────────
# INSTALAÇÃO DOS ARQUIVOS
# ──────────────────────────────────────────────
install_files() {
    step "Instalando arquivos da aplicação"

    # Criar diretório
    if [[ ! -d "$INSTALL_DIR" ]]; then
        run_as_root mkdir -p "$INSTALL_DIR"
        ok "Diretório criado: ${INSTALL_DIR}"
    else
        warn "Diretório já existe — fazendo backup..."
        local backup_dir="${INSTALL_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
        run_as_root cp -r "$INSTALL_DIR" "$backup_dir"
        ok "Backup salvo em: ${backup_dir}"
    fi

    # Copiar arquivos do script dir
    local source_dir="$SCRIPT_DIR"

    start_spinner "Copiando arquivos da aplicação"
    run_as_root cp -r "${source_dir}/api"      "${INSTALL_DIR}/" 2>>"$LOG_FILE" || true
    run_as_root cp -r "${source_dir}/includes" "${INSTALL_DIR}/" 2>>"$LOG_FILE" || true
    run_as_root cp -r "${source_dir}/pages"    "${INSTALL_DIR}/" 2>>"$LOG_FILE" || true
    run_as_root cp    "${source_dir}/index.php"      "${INSTALL_DIR}/" 2>>"$LOG_FILE" || true
    run_as_root cp    "${source_dir}/database.sql"   "${INSTALL_DIR}/" 2>>"$LOG_FILE" || true
    run_as_root cp    "${source_dir}/.htaccess"      "${INSTALL_DIR}/" 2>>"$LOG_FILE" || true
    stop_spinner
    ok "Arquivos copiados"

    # Criar diretórios necessários
    local dirs=("uploads" "uploads/reports" "logs")
    for dir in "${dirs[@]}"; do
        run_as_root mkdir -p "${INSTALL_DIR}/${dir}"
    done
    ok "Diretórios criados: uploads/, uploads/reports/, logs/"

    # Arquivo .gitignore
    run_as_root tee "${INSTALL_DIR}/.gitignore" > /dev/null <<'GITEOF'
includes/config.php
uploads/
logs/
*.log
GITEOF
}

# ──────────────────────────────────────────────
# PERMISSÕES
# ──────────────────────────────────────────────
set_permissions() {
    step "Configurando permissões"

    # Detectar usuário do servidor web
    local web_user="www-data"
    if id "nginx" &>/dev/null; then
        web_user="nginx"
    elif id "apache" &>/dev/null; then
        web_user="apache"
    elif id "http" &>/dev/null; then
        web_user="http"
    fi

    log "Usuário web detectado: $web_user"

    run_as_root chown -R "${web_user}:${web_user}" "${INSTALL_DIR}" 2>/dev/null || \
        run_as_root chown -R "$(whoami):$(whoami)" "${INSTALL_DIR}"

    # Permissões dos arquivos PHP
    run_as_root find "${INSTALL_DIR}" -type f -name "*.php" -exec chmod 644 {} \;
    run_as_root find "${INSTALL_DIR}" -type f -name "*.sql" -exec chmod 640 {} \;
    run_as_root find "${INSTALL_DIR}" -type d -exec chmod 755 {} \;

    # Pastas com escrita
    run_as_root chmod -R 775 "${INSTALL_DIR}/uploads"
    run_as_root chmod -R 775 "${INSTALL_DIR}/logs"

    # Proteger config
    run_as_root chmod 640 "${INSTALL_DIR}/includes/config.php" 2>/dev/null || true

    ok "Permissões configuradas (usuário web: ${web_user})"
}

# ──────────────────────────────────────────────
# BANCO DE DADOS
# ──────────────────────────────────────────────

# Executa um comando mysql usando array de argumentos (sem word splitting)
# Uso: mysql_exec <user> <pass_or_empty> <host> <port> [args...]
mysql_exec() {
    local user="$1"; shift
    local pass="$1"; shift
    local host="$1"; shift
    local port="$1"; shift

    local -a args=()

    # Usuário
    args+=("-u" "$user")

    # Senha — só adiciona -p se não estiver vazia
    if [[ -n "$pass" ]]; then
        args+=("-p${pass}")
    fi

    # Host: se for localhost E o socket existir, deixa o mysql usar o socket
    # (adicionar -h localhost força TCP e pode falhar se o MySQL não ouve em TCP)
    if [[ "$host" == "localhost" ]]; then
        # Tentar detectar o socket Unix do MySQL/MariaDB
        local sock=""
        for candidate in \
            /var/run/mysqld/mysqld.sock \
            /var/run/mysql/mysql.sock \
            /tmp/mysql.sock \
            /var/lib/mysql/mysql.sock \
            /run/mysqld/mysqld.sock; do
            if [[ -S "$candidate" ]]; then
                sock="$candidate"
                break
            fi
        done

        if [[ -n "$sock" ]]; then
            args+=("--socket=$sock")
            log "mysql: usando socket $sock"
        else
            args+=("-h" "127.0.0.1" "-P" "$port")
            log "mysql: sem socket, usando TCP 127.0.0.1:${port}"
        fi
    else
        args+=("-h" "$host" "-P" "$port")
    fi

    # Suprimir warning de senha no stderr (MySQL 5.7+)
    args+=("--connect-timeout=10")

    # Passar argumentos extras (ex: -e "SQL", nome do banco, etc.)
    args+=("$@")

    log "mysql_exec: mysql ${args[*]}"
    mysql "${args[@]}" 2>> "$LOG_FILE"
}

setup_database() {
    step "Configurando banco de dados"

    # Determinar credenciais para operações root (criar banco/usuário)
    local root_user="root"
    local root_pass=""

    if [[ "$CREATE_DB_USER" == true ]]; then
        root_pass="$DB_ROOT_PASS"
    else
        # Usuário já existe — usamos as credenciais fornecidas para tudo
        root_user="$DB_USER"
        root_pass="$DB_PASS"
    fi

    # ── Teste de conexão com retry e diagnóstico detalhado
    start_spinner "Testando conexão com MySQL"
    local connected=false
    local attempts=0
    local max_attempts=3

    while [[ $attempts -lt $max_attempts ]]; do
        ((attempts++))
        log "Tentativa de conexão ${attempts}/${max_attempts}: user=${root_user} host=${DB_HOST}:${DB_PORT}"

        if mysql_exec "$root_user" "$root_pass" "$DB_HOST" "$DB_PORT" \
            --execute="SELECT 1;" >> "$LOG_FILE" 2>&1; then
            connected=true
            break
        fi

        # Diagnosticar causa do erro
        local mysql_err
        mysql_err=$(mysql_exec "$root_user" "$root_pass" "$DB_HOST" "$DB_PORT" \
            --execute="SELECT 1;" 2>&1 | tail -1 || true)
        log "Erro mysql tentativa ${attempts}: ${mysql_err}"

        [[ $attempts -lt $max_attempts ]] && sleep 1
    done

    stop_spinner

    if [[ "$connected" == false ]]; then
        # Tentar diagnóstico extra antes de falhar
        echo ""
        echo -e "  ${RED}Falha na conexão MySQL. Diagnóstico:${RESET}"
        echo ""

        # Checar se o serviço está rodando
        if systemctl is-active --quiet mysql 2>/dev/null || \
           systemctl is-active --quiet mariadb 2>/dev/null; then
            echo -e "  ${GREEN}✓${RESET} Serviço MySQL/MariaDB está ${GREEN}ativo${RESET}"
        else
            echo -e "  ${RED}✗${RESET} Serviço MySQL/MariaDB ${RED}não está rodando${RESET}"
            echo -e "    ${DIM}Tente: sudo systemctl start mysql   ou   sudo systemctl start mariadb${RESET}"
        fi

        # Checar porta TCP
        if command -v ss &>/dev/null; then
            if ss -tlnp 2>/dev/null | grep -q ":${DB_PORT}"; then
                echo -e "  ${GREEN}✓${RESET} Porta ${DB_PORT} está ${GREEN}ouvindo${RESET}"
            else
                echo -e "  ${YELLOW}⚠${RESET} Porta ${DB_PORT} não encontrada via ss"
            fi
        fi

        # Checar socket
        for sock_path in /var/run/mysqld/mysqld.sock /tmp/mysql.sock /run/mysqld/mysqld.sock; do
            if [[ -S "$sock_path" ]]; then
                echo -e "  ${GREEN}✓${RESET} Socket encontrado: ${sock_path}"
            fi
        done

        # Checar se é problema de root sem senha
        if [[ "$CREATE_DB_USER" == true ]] && [[ -z "$root_pass" ]]; then
            echo ""
            echo -e "  ${YELLOW}Dica:${RESET} Em sistemas com auth_socket/unix_socket, o root MySQL"
            echo -e "  só aceita conexão via ${BOLD}sudo mysql${RESET} sem senha."
            echo -e "  Tentando via sudo..."
            echo ""

            if run_as_root mysql_exec "$root_user" "" "$DB_HOST" "$DB_PORT" \
               --execute="SELECT 1;" >> "$LOG_FILE" 2>&1; then
                echo -e "  ${GREEN}✓ Conexão via sudo funcionou!${RESET}"
                log "Conexão bem-sucedida via sudo"
                connected=true
                MYSQL_USE_SUDO=true
            fi
        fi

        if [[ "$connected" == false ]]; then
            echo ""
            echo -e "  ${DIM}Últimas linhas do log MySQL:${RESET}"
            grep -i "error\|denied\|failed\|can't\|unable" "$LOG_FILE" | tail -5 | sed 's/^/    /'
            echo ""
            mysql_collect_info_and_retry "$root_user" "$root_pass"
        fi
    fi

    ok "Conexão com MySQL estabelecida"

    # ── Criar banco e usuário (se necessário)
    if [[ "$CREATE_DB_USER" == true ]]; then
        start_spinner "Criando banco de dados '${DB_NAME}'"
        mysql_exec "$root_user" "$root_pass" "$DB_HOST" "$DB_PORT" \
            --execute="CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" \
            >> "$LOG_FILE" 2>&1 || {
            stop_spinner
            fatal "Erro ao criar banco de dados. Verifique as permissões do usuário root MySQL."
        }
        stop_spinner
        ok "Banco '${DB_NAME}' criado"

        start_spinner "Criando usuário '${DB_USER}'"
        mysql_exec "$root_user" "$root_pass" "$DB_HOST" "$DB_PORT" \
            --execute="CREATE USER IF NOT EXISTS '${DB_USER}'@'${DB_HOST}' IDENTIFIED BY '${DB_PASS}'; GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'${DB_HOST}'; FLUSH PRIVILEGES;" \
            >> "$LOG_FILE" 2>&1 || {
            stop_spinner
            fatal "Erro ao criar usuário MySQL '${DB_USER}'."
        }
        stop_spinner
        ok "Usuário '${DB_USER}' criado com privilégios em '${DB_NAME}'"
    else
        # Só criar o banco se não existir
        start_spinner "Criando banco de dados '${DB_NAME}' (se não existir)"
        mysql_exec "$DB_USER" "$DB_PASS" "$DB_HOST" "$DB_PORT" \
            --execute="CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" \
            >> "$LOG_FILE" 2>&1 || {
            stop_spinner
            fatal "Erro ao criar banco. Verifique se o usuário '${DB_USER}' tem permissão de CREATE."
        }
        stop_spinner
        ok "Banco '${DB_NAME}' pronto"
    fi

    # ── Importar schema
    start_spinner "Importando schema (tabelas e dados iniciais)"
    mysql_exec "$DB_USER" "$DB_PASS" "$DB_HOST" "$DB_PORT" \
        "$DB_NAME" < "${INSTALL_DIR}/database.sql" >> "$LOG_FILE" 2>&1 || {
        stop_spinner
        fatal "Erro ao importar schema. Verifique o arquivo database.sql e as permissões."
    }
    stop_spinner
    ok "Schema importado com sucesso (5 tabelas criadas)"

    # ── Criar admin
    create_admin_user
}

# Coleta credenciais novas e tenta de novo antes de desistir
mysql_collect_info_and_retry() {
    local cur_user="$1"
    local cur_pass="$2"

    echo -e "  ${YELLOW}Deseja tentar com credenciais diferentes? (s/n):${RESET} \c"
    read -r retry_choice
    if [[ ! "$retry_choice" =~ ^[Ss]$ ]]; then
        fatal "Não foi possível conectar ao MySQL. Verifique as credenciais e o status do serviço."
    fi

    printf "  Usuário MySQL (root ou outro com privilégios): "
    read -r new_user
    new_user="${new_user:-root}"

    printf "  Senha (ENTER para sem senha): "
    read -rs new_pass; echo ""

    printf "  Host [${DB_HOST}]: "
    read -r new_host
    new_host="${new_host:-$DB_HOST}"

    printf "  Porta [${DB_PORT}]: "
    read -r new_port
    new_port="${new_port:-$DB_PORT}"

    start_spinner "Testando novas credenciais"
    if mysql_exec "$new_user" "$new_pass" "$new_host" "$new_port" \
       --execute="SELECT 1;" >> "$LOG_FILE" 2>&1; then
        stop_spinner
        ok "Conexão estabelecida com novas credenciais"
        # Atualizar variáveis globais
        if [[ "$CREATE_DB_USER" == true ]]; then
            DB_ROOT_PASS="$new_pass"
        else
            DB_USER="$new_user"
            DB_PASS="$new_pass"
        fi
        DB_HOST="$new_host"
        DB_PORT="$new_port"
    else
        stop_spinner
        fatal "Falha novamente. Corrija a configuração do MySQL e rode o instalador de novo."
    fi
}

create_admin_user() {
    start_spinner "Criando conta do administrador"

    # Gerar hash bcrypt via openssl (não depende do PHP estar disponível)
    local pass_hash=""
    if command -v php &>/dev/null; then
        pass_hash=$(php -r "echo password_hash('${ADMIN_PASS}', PASSWORD_BCRYPT);" 2>/dev/null || true)
    fi

    # Fallback: gerar hash simples via openssl se PHP não estiver disponível ainda
    if [[ -z "$pass_hash" ]]; then
        # Inserir senha em texto e deixar o PHP hashear na primeira execução
        # (a aplicação vai rejeitar — melhor avisar)
        warn "PHP não disponível para gerar hash. Defina a senha manualmente após instalar."
        stop_spinner
        return 0
    fi

    # Escapar aspas simples no hash para SQL seguro
    local safe_hash="${pass_hash//\'/\'\'}"
    local safe_name="${ADMIN_NAME//\'/\'\'}"
    local safe_email="${ADMIN_EMAIL//\'/\'\'}"

    local sql="
DELETE FROM users WHERE email = '${safe_email}';
INSERT INTO users (name, email, password, role, active)
VALUES ('${safe_name}', '${safe_email}', '${safe_hash}', 'admin', 1);
"
    if echo "$sql" | mysql_exec "$DB_USER" "$DB_PASS" "$DB_HOST" "$DB_PORT" "$DB_NAME" \
       >> "$LOG_FILE" 2>&1; then
        stop_spinner
        ok "Administrador '${ADMIN_NAME}' <${ADMIN_EMAIL}> criado"
    else
        stop_spinner
        warn "Não foi possível criar o admin automaticamente."
        warn "Acesse o MySQL manualmente e execute:"
        echo ""
        echo -e "  ${DIM}INSERT INTO ${DB_NAME}.users (name,email,password,role,active)"
        echo -e "  VALUES ('${ADMIN_NAME}','${ADMIN_EMAIL}','<hash>','admin',1);${RESET}"
        echo ""
    fi
}

# ──────────────────────────────────────────────
# CONFIGURAÇÃO PHP (config.php)
# ──────────────────────────────────────────────
write_config() {
    step "Gerando arquivo de configuração"

    local config_file="${INSTALL_DIR}/includes/config.php"

    run_as_root tee "$config_file" > /dev/null <<PHPEOF
<?php
// ============================================================
// config.php — Gerado automaticamente pelo instalador
// Data: $(date '+%d/%m/%Y %H:%M:%S')
// ============================================================

define('DB_HOST',  '${DB_HOST}');
define('DB_PORT',  '${DB_PORT}');
define('DB_USER',  '${DB_USER}');
define('DB_PASS',  '${DB_PASS}');
define('DB_NAME',  '${DB_NAME}');

define('CLAUDE_API_KEY',    '${CLAUDE_API_KEY}');
define('CLAUDE_MODEL',      'claude-sonnet-4-20250514');
define('CLAUDE_MAX_TOKENS', 8000);

define('BASE_URL',    '${BASE_URL}');
define('REPORTS_DIR', __DIR__ . '/../uploads/reports/');
define('APP_NAME',    'Tati Indicando — Studio');
define('APP_VERSION', '${APP_VERSION}');

// Sessão segura
session_start();
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure',   $([ "$USE_SSL" == true ] && echo 1 || echo 0));
ini_set('session.use_strict_mode', 1);
ini_set('session.gc_maxlifetime',  86400);

// Timezone
date_default_timezone_set('America/Sao_Paulo');

// Logs de erro (desative 'display_errors' em produção)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors',     1);
ini_set('error_log',      __DIR__ . '/../logs/error.log');

// Conexão PDO
function getDB(): PDO {
    static \$pdo = null;
    if (\$pdo === null) {
        try {
            \$dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                DB_HOST, DB_PORT, DB_NAME
            );
            \$pdo = new PDO(\$dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException \$e) {
            error_log('DB Connection failed: ' . \$e->getMessage());
            die(json_encode(['error' => 'Falha na conexão com o banco de dados.']));
        }
    }
    return \$pdo;
}

function requireAuth(): void {
    if (empty(\$_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function requireAdmin(): void {
    requireAuth();
    if (\$_SESSION['user_role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/pages/dashboard.php');
        exit;
    }
}

function clean(string \$str): string {
    return htmlspecialchars(trim(\$str), ENT_QUOTES, 'UTF-8');
}

function auditLog(string \$action, string \$description = '', ?int \$userId = null): void {
    try {
        \$db  = getDB();
        \$uid = \$userId ?? (\$_SESSION['user_id'] ?? null);
        \$ip  = \$_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        \$db->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address) VALUES (?,?,?,?)")
           ->execute([\$uid, \$action, \$description, \$ip]);
    } catch (Exception \$e) {}
}
PHPEOF

    run_as_root chmod 640 "$config_file"
    ok "config.php gerado em: ${config_file}"
}

# ──────────────────────────────────────────────
# VIRTUAL HOST
# ──────────────────────────────────────────────
configure_vhost() {
    [[ "$CONFIGURE_VHOST" != true ]] && return
    step "Configurando Virtual Host (${WEB_SERVER})"

    if [[ "$WEB_SERVER" == "apache" ]]; then
        configure_apache_vhost
    elif [[ "$WEB_SERVER" == "nginx" ]]; then
        configure_nginx_vhost
    fi
}

configure_apache_vhost() {
    local vhost_file="/etc/apache2/sites-available/tati-platform.conf"
    local doc_root
    doc_root="$(dirname "$INSTALL_DIR")"

    run_as_root tee "$vhost_file" > /dev/null <<APACHEEOF
<VirtualHost *:80>
    ServerName ${DOMAIN}
    DocumentRoot ${doc_root}

    <Directory "${INSTALL_DIR}">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    Alias /tati-platform ${INSTALL_DIR}

    ErrorLog  \${APACHE_LOG_DIR}/tati-platform_error.log
    CustomLog \${APACHE_LOG_DIR}/tati-platform_access.log combined

    <FilesMatch "\.php$">
        SetHandler application/x-httpd-php
    </FilesMatch>
</VirtualHost>
APACHEEOF

    run_as_root a2ensite tati-platform.conf >> "$LOG_FILE" 2>&1 || true
    run_as_root a2enmod rewrite >> "$LOG_FILE" 2>&1 || true
    run_as_root systemctl reload apache2 >> "$LOG_FILE" 2>&1 || \
        run_as_root service apache2 reload >> "$LOG_FILE" 2>&1 || true

    ok "Virtual Host Apache configurado: /etc/apache2/sites-available/tati-platform.conf"

    if [[ "$USE_SSL" == true ]] && command -v certbot &>/dev/null; then
        configure_ssl_certbot
    elif [[ "$USE_SSL" == true ]]; then
        warn "certbot não encontrado. Configure SSL manualmente."
    fi
}

configure_nginx_vhost() {
    local vhost_file="/etc/nginx/sites-available/tati-platform.conf"

    run_as_root tee "$vhost_file" > /dev/null <<NGINXEOF
server {
    listen 80;
    server_name ${DOMAIN};
    root $(dirname "$INSTALL_DIR");
    index index.php index.html;

    location /tati-platform {
        alias ${INSTALL_DIR};
        try_files \$uri \$uri/ /tati-platform/index.php?\$query_string;

        location ~ \.php$ {
            fastcgi_pass unix:/var/run/php/php${PHP_VERSION%.*}-fpm.sock;
            fastcgi_index index.php;
            fastcgi_param SCRIPT_FILENAME \$request_filename;
            include fastcgi_params;
            fastcgi_read_timeout 300;
        }

        location ~* \.(css|js|png|jpg|gif|ico|woff2|svg)$ {
            expires 30d;
            add_header Cache-Control "public, no-transform";
        }

        location ~ /\. { deny all; }
        location ~* /includes/ { deny all; }
        location ~* /logs/ { deny all; }
    }

    error_log  /var/log/nginx/tati-platform_error.log;
    access_log /var/log/nginx/tati-platform_access.log;
}
NGINXEOF

    run_as_root ln -sf "$vhost_file" /etc/nginx/sites-enabled/ 2>/dev/null || true
    run_as_root nginx -t >> "$LOG_FILE" 2>&1 && \
        run_as_root systemctl reload nginx >> "$LOG_FILE" 2>&1 || \
        run_as_root service nginx reload >> "$LOG_FILE" 2>&1 || true

    ok "Virtual Host Nginx configurado: ${vhost_file}"
}

configure_ssl_certbot() {
    info "Configurando SSL com Let's Encrypt..."
    run_as_root certbot --apache -d "$DOMAIN" --non-interactive --agree-tos \
        --email "$ADMIN_EMAIL" >> "$LOG_FILE" 2>&1 && \
        ok "SSL configurado com Let's Encrypt para ${DOMAIN}" || \
        warn "Falha ao configurar SSL automático. Configure manualmente."
}

# ──────────────────────────────────────────────
# PHP SETTINGS OTIMIZADOS
# ──────────────────────────────────────────────
configure_php() {
    step "Otimizando configurações do PHP"

    # Localizar php.ini ativo
    local php_ini
    php_ini=$(php --ini 2>/dev/null | grep "Loaded Configuration" | awk '{print $NF}')

    if [[ -z "$php_ini" ]] || [[ ! -f "$php_ini" ]]; then
        warn "Arquivo php.ini não encontrado — pulando configuração do PHP."
        return
    fi

    # Criar override .ini local para a aplicação (mais seguro que editar o global)
    local php_extra_dir
    php_extra_dir=$(php --ini 2>/dev/null | grep "Scan for additional" | awk '{print $NF}' | head -1)

    if [[ -d "$php_extra_dir" ]]; then
        run_as_root tee "${php_extra_dir}/99-tati-platform.ini" > /dev/null <<'PHPINIEOF'
; Tati Platform — Configurações PHP otimizadas
max_execution_time = 300
max_input_time = 300
memory_limit = 256M
post_max_size = 32M
upload_max_filesize = 32M
default_socket_timeout = 120
output_buffering = Off
PHPINIEOF
        ok "Configurações PHP otimizadas (${php_extra_dir}/99-tati-platform.ini)"
    else
        # Fallback: .user.ini na raiz da app
        run_as_root tee "${INSTALL_DIR}/.user.ini" > /dev/null <<'USERINIEOF'
max_execution_time = 300
memory_limit = 256M
post_max_size = 32M
upload_max_filesize = 32M
USERINIEOF
        ok "Configurações PHP via .user.ini na raiz da aplicação"
    fi
}

# ──────────────────────────────────────────────
# VERIFICAÇÃO FINAL
# ──────────────────────────────────────────────
run_health_check() {
    step "Executando verificação final de integridade"

    local errors=0

    # Arquivos críticos
    local critical_files=(
        "index.php"
        "includes/config.php"
        "includes/claude.service.php"
        "api/auth.php"
        "api/generate.php"
        "api/projects.php"
        "api/report.php"
        "pages/dashboard.php"
        "database.sql"
    )

    for file in "${critical_files[@]}"; do
        if [[ -f "${INSTALL_DIR}/${file}" ]]; then
            ok "${file}"
        else
            err "Arquivo faltando: ${file}"
            ((errors++))
        fi
    done

    # Diretórios com escrita
    local writable_dirs=("uploads" "uploads/reports" "logs")
    for dir in "${writable_dirs[@]}"; do
        if [[ -w "${INSTALL_DIR}/${dir}" ]]; then
            ok "${dir}/ (escrita ✓)"
        else
            warn "${dir}/ não tem permissão de escrita"
        fi
    done

    # Teste de conexão com banco
    start_spinner "Testando conexão com banco de dados"
    if php -r "
        try {
            \$pdo = new PDO(
                'mysql:host=${DB_HOST};port=${DB_PORT};dbname=${DB_NAME};charset=utf8mb4',
                '${DB_USER}', '${DB_PASS}'
            );
            \$count = \$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
            echo 'OK:' . \$count;
        } catch (Exception \$e) {
            echo 'ERR:' . \$e->getMessage();
        }
    " 2>/dev/null | grep -q "^OK:"; then
        stop_spinner
        ok "Conexão com banco de dados funcional"
    else
        stop_spinner
        warn "Não foi possível conectar ao banco via PHP. Verifique config.php."
        ((errors++))
    fi

    # Teste de acesso à API Claude (somente se key foi fornecida)
    if [[ -n "$CLAUDE_API_KEY" ]] && [[ "$CLAUDE_API_KEY" =~ ^sk-ant- ]]; then
        start_spinner "Verificando acesso à API do Claude"
        local api_test
        api_test=$(curl -s -o /dev/null -w "%{http_code}" \
            -H "x-api-key: ${CLAUDE_API_KEY}" \
            -H "anthropic-version: 2023-06-01" \
            "https://api.anthropic.com/v1/models" 2>/dev/null)
        stop_spinner
        if [[ "$api_test" == "200" ]]; then
            ok "API do Claude acessível ✓"
        else
            warn "API do Claude retornou HTTP ${api_test}. Verifique a API Key."
        fi
    fi

    if [[ $errors -gt 0 ]]; then
        warn "${errors} problema(s) encontrado(s). Verifique o log: ${LOG_FILE}"
    else
        ok "Verificação concluída sem erros"
    fi

    return $errors
}

# ──────────────────────────────────────────────
# SUMMARY FINAL
# ──────────────────────────────────────────────
print_success() {
    echo ""
    echo -e "${GREEN}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════╗"
    echo "  ║                                                          ║"
    echo "  ║    ✓  INSTALAÇÃO CONCLUÍDA COM SUCESSO!                  ║"
    echo "  ║                                                          ║"
    echo "  ╚══════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    echo ""
    echo -e "  ${BOLD}🌐  Acesse a plataforma:${RESET}"
    echo -e "      ${CYAN}${BASE_URL}${RESET}"
    echo ""
    echo -e "  ${BOLD}🔑  Credenciais do administrador:${RESET}"
    echo -e "      ${DIM}E-mail:${RESET} ${ADMIN_EMAIL}"
    echo -e "      ${DIM}Senha:${RESET}  ${YELLOW}[a que você definiu na instalação]${RESET}"
    echo ""
    echo -e "  ${BOLD}📁  Instalação em:${RESET}"
    echo -e "      ${INSTALL_DIR}"
    echo ""
    echo -e "  ${BOLD}📋  Log completo:${RESET}"
    echo -e "      ${LOG_FILE}"
    echo ""
    divider
    echo ""
    echo -e "  ${YELLOW}${BOLD}⚠  PRÓXIMOS PASSOS IMPORTANTES:${RESET}"
    echo ""
    echo -e "  ${DIM}1.${RESET} Acesse ${CYAN}${BASE_URL}${RESET} e faça login"
    echo -e "  ${DIM}2.${RESET} Vá em Configurações e confirme a API Key do Claude"
    echo -e "  ${DIM}3.${RESET} Crie usuários adicionais em ${CYAN}Usuários${RESET} (admin)"
    echo -e "  ${DIM}4.${RESET} Configure SSL/HTTPS se ainda não feito"
    echo -e "  ${DIM}5.${RESET} Remova o arquivo ${RED}database.sql${RESET} do diretório público"
    echo ""
    echo -e "  ${DIM}Para remover database.sql:${RESET}"
    echo -e "  ${CYAN}  rm ${INSTALL_DIR}/database.sql${RESET}"
    echo ""
}

print_failure() {
    echo ""
    echo -e "${RED}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════════════╗"
    echo "  ║    ✗  A INSTALAÇÃO ENCONTROU ERROS                      ║"
    echo "  ╚══════════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
    echo ""
    echo -e "  Verifique o log completo em:"
    echo -e "  ${CYAN}  ${LOG_FILE}${RESET}"
    echo ""
    echo -e "  ${DIM}Últimas linhas do log:${RESET}"
    echo ""
    tail -15 "$LOG_FILE" | sed 's/^/    /'
    echo ""
}

# ──────────────────────────────────────────────
# TRAP PARA ERROS INESPERADOS
# ──────────────────────────────────────────────
handle_error() {
    stop_spinner
    local line=$1
    local code=$2
    echo ""
    err "Erro inesperado na linha ${line} (código ${code})"
    print_failure
    exit 1
}

trap 'handle_error $LINENO $?' ERR

# ──────────────────────────────────────────────
# PONTO DE ENTRADA
# ──────────────────────────────────────────────
main() {
    # Iniciar log
    echo "=== Tati Indicando Studio — Instalação ===" > "$LOG_FILE"
    echo "Data: $(date)" >> "$LOG_FILE"
    echo "Usuário: $(whoami)" >> "$LOG_FILE"
    echo "Script: ${SCRIPT_DIR}" >> "$LOG_FILE"
    echo "" >> "$LOG_FILE"

    print_banner
    detect_os
    detect_package_manager

    info "Sistema: ${OS_NAME}"
    info "Package manager: ${PKG_MGR}"

    # Verificar pré-requisitos
    check_prerequisites

    # Coletar configurações interativamente
    collect_config

    echo ""
    step "Iniciando instalação..."

    # Pipeline de instalação
    install_files
    set_permissions
    write_config
    setup_database
    configure_php
    configure_vhost

    # Verificação
    if run_health_check; then
        print_success
    else
        warn "Instalação concluída mas com avisos. Verifique os itens acima."
        print_success
    fi
}

# ──────────────────────────────────────────────
# MODO UNINSTALL
# ──────────────────────────────────────────────
uninstall() {
    print_banner
    echo -e "  ${RED}${BOLD}DESINSTALAÇÃO${RESET}"
    echo ""
    printf "  Diretório a remover: "
    read -r rm_dir

    if [[ -z "$rm_dir" ]] || [[ ! -d "$rm_dir" ]]; then
        fatal "Diretório inválido: ${rm_dir}"
    fi

    echo -e "  ${RED}Isso vai remover ${rm_dir} permanentemente. Confirma? (DIGITAR 'sim'):${RESET} \c"
    read -r confirm
    if [[ "$confirm" != "sim" ]]; then
        info "Desinstalação cancelada."
        exit 0
    fi

    run_as_root rm -rf "$rm_dir"
    ok "Diretório removido: ${rm_dir}"

    echo ""
    printf "  Deseja apagar também o banco de dados? (s/n): "
    read -r drop_db
    if [[ "$drop_db" =~ ^[Ss]$ ]]; then
        printf "  Nome do banco: "
        read -r drop_name
        printf "  Usuário root MySQL: "
        read -r root_user
        printf "  Senha root MySQL: "
        read -rs root_pass; echo ""
        mysql -u "$root_user" -p"$root_pass" -e "DROP DATABASE IF EXISTS \`${drop_name}\`;" && \
            ok "Banco '${drop_name}' removido" || warn "Falha ao remover banco."
    fi

    ok "Desinstalação concluída."
}

# ──────────────────────────────────────────────
# ARGUMENTOS
# ──────────────────────────────────────────────
case "${1:-}" in
    --uninstall|-u)
        uninstall
        ;;
    --help|-h)
        echo ""
        echo "  ${APP_NAME} — Instalador"
        echo ""
        echo "  Uso: ./install.sh [opção]"
        echo ""
        echo "  Opções:"
        echo "    (sem opção)    Instala a plataforma de forma interativa"
        echo "    --uninstall    Remove a plataforma instalada"
        echo "    --help         Exibe esta ajuda"
        echo ""
        ;;
    *)
        main
        ;;
esac
