<?php
// ============================================================
// api/auth.php — Login, Logout, Registro
// ============================================================

require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    case 'login':
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$email || !$password) {
            echo json_encode(['success' => false, 'message' => 'Preencha todos os campos.']);
            exit;
        }

        $db   = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            auditLog('login_failed', "Tentativa: {$email}");
            echo json_encode(['success' => false, 'message' => 'Credenciais inválidas.']);
            exit;
        }

        $_SESSION['user_id']    = $user['id'];
        $_SESSION['user_name']  = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role']  = $user['role'];

        $db->prepare("UPDATE users SET last_login=NOW() WHERE id=?")->execute([$user['id']]);
        auditLog('login_success', "Usuário: {$user['name']}", $user['id']);

        echo json_encode(['success' => true, 'redirect' => '../pages/dashboard.php']);
        break;

    case 'logout':
        auditLog('logout', 'Usuário saiu do sistema');
        session_destroy();
        echo json_encode(['success' => true, 'redirect' => '../index.php']);
        break;

    case 'register':
        requireAdmin();
        $name     = clean($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role     = in_array($_POST['role'] ?? '', ['admin','editor','viewer']) ? $_POST['role'] : 'editor';

        if (!$name || !$email || !$password) {
            echo json_encode(['success' => false, 'message' => 'Preencha todos os campos.']);
            exit;
        }

        $db   = getDB();
        $hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $db->prepare("INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)")
               ->execute([$name, $email, $hash, $role]);
            auditLog('user_created', "Novo usuário: {$email}");
            echo json_encode(['success' => true, 'message' => 'Usuário criado com sucesso!']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'E-mail já cadastrado.']);
        }
        break;

    case 'change_password':
        requireAuth();
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';

        $db   = getDB();
        $stmt = $db->prepare("SELECT password FROM users WHERE id=?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        if (!password_verify($current, $user['password'])) {
            echo json_encode(['success' => false, 'message' => 'Senha atual incorreta.']);
            exit;
        }

        $hash = password_hash($new, PASSWORD_DEFAULT);
        $db->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hash, $_SESSION['user_id']]);
        auditLog('password_changed', 'Senha alterada');
        echo json_encode(['success' => true, 'message' => 'Senha alterada com sucesso!']);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Ação inválida.']);
}
