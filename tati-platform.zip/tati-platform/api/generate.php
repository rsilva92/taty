<?php
// ============================================================
// api/generate.php — Geração de blocos via SSE (streaming)
// ============================================================

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/claude.service.php';

requireAuth();

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no');

set_time_limit(0);
ob_implicit_flush(true);

function sendSSE(string $event, array $data): void {
    echo "event: {$event}\n";
    echo "data: " . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n\n";
    if (ob_get_level() > 0) ob_flush();
    flush();
}

// Validação
$projectId = (int)($_GET['project_id'] ?? 0);
if (!$projectId) {
    sendSSE('error', ['message' => 'ID do projeto inválido.']);
    exit;
}

$db = getDB();

// Buscar projeto
$stmt = $db->prepare("SELECT * FROM projects WHERE id = ? AND user_id = ?");
$stmt->execute([$projectId, $_SESSION['user_id']]);
$project = $stmt->fetch();

if (!$project) {
    sendSSE('error', ['message' => 'Projeto não encontrado.']);
    exit;
}

// Verificar se já foi processado
if ($project['status'] === 'completed') {
    sendSSE('error', ['message' => 'Projeto já foi processado.']);
    exit;
}

// Marcar como processando
$db->prepare("UPDATE projects SET status='processing' WHERE id=?")->execute([$projectId]);

sendSSE('start', ['message' => 'Iniciando sistema multiagente...', 'total_blocks' => 14]);

$claude = new ClaudeService();
$projectData = [
    'channel_name' => $project['channel_name'],
    'niche'        => $project['niche'],
    'video_type'   => $project['video_type'],
];

$totalTokens = 0;
$errors = [];

try {
    foreach ($claude->generateAllBlocks($project['script'], $projectData) as $result) {
        $blockNum  = $result['block_number'];
        $blockName = $result['block_name'];

        if (!$result['success']) {
            $errors[] = "Bloco {$blockNum}: {$result['error']}";
            sendSSE('block_error', [
                'block_number' => $blockNum,
                'block_name'   => $blockName,
                'error'        => $result['error'],
            ]);
            continue;
        }

        // Salvar bloco no banco
        $ins = $db->prepare("
            INSERT INTO project_blocks (project_id, block_number, block_name, content)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE content = VALUES(content), generated_at = NOW()
        ");
        $ins->execute([$projectId, $blockNum, $blockName, $result['content']]);

        $totalTokens += $result['tokens'];

        sendSSE('block_done', [
            'block_number' => $blockNum,
            'block_name'   => $blockName,
            'tokens'       => $result['tokens'],
            'preview'      => mb_substr(strip_tags($result['content']), 0, 120) . '...',
        ]);
    }

    // Atualizar status final
    $finalStatus = empty($errors) ? 'completed' : 'error';
    $db->prepare("UPDATE projects SET status=?, tokens_used=? WHERE id=?")
       ->execute([$finalStatus, $totalTokens, $projectId]);

    auditLog('project_generated', "Projeto #{$projectId} — {$totalTokens} tokens");

    sendSSE('complete', [
        'message'      => 'Produção completa!',
        'total_tokens' => $totalTokens,
        'status'       => $finalStatus,
        'errors'       => $errors,
    ]);

} catch (Throwable $e) {
    $db->prepare("UPDATE projects SET status='error' WHERE id=?")->execute([$projectId]);
    sendSSE('error', ['message' => 'Erro interno: ' . $e->getMessage()]);
}
