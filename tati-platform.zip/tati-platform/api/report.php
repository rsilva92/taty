<?php
// ============================================================
// api/report.php — Geração de Relatório HTML
// ============================================================

require_once __DIR__ . '/../includes/config.php';
requireAuth();

$projectId = (int)($_GET['project_id'] ?? $_POST['project_id'] ?? 0);
$format    = $_GET['format'] ?? 'html';

if (!$projectId) { die('ID inválido'); }

$db = getDB();
$stmt = $db->prepare("SELECT p.*, u.name as author FROM projects p JOIN users u ON u.id=p.user_id WHERE p.id=?");
$stmt->execute([$projectId]);
$project = $stmt->fetch();

if (!$project) { die('Projeto não encontrado'); }
if ($_SESSION['user_role'] !== 'admin' && $project['user_id'] != $_SESSION['user_id']) { die('Acesso negado'); }

$blkStmt = $db->prepare("SELECT * FROM project_blocks WHERE project_id = ? ORDER BY block_number");
$blkStmt->execute([$projectId]);
$blocks = $blkStmt->fetchAll();

if ($format === 'json') {
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="relatorio-' . $projectId . '.json"');
    echo json_encode(['project' => $project, 'blocks' => $blocks], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// HTML Report
$blockColors = [
    1=>'#6366f1',2=>'#8b5cf6',3=>'#a855f7',4=>'#ec4899',5=>'#f43f5e',
    6=>'#f97316',7=>'#eab308',8=>'#22c55e',9=>'#14b8a6',10=>'#06b6d4',
    11=>'#3b82f6',12=>'#6366f1',13=>'#8b5cf6',14=>'#10b981'
];

$blockIcons = [
    1=>'🗺️',2=>'💎',3=>'🎯',4=>'📝',5=>'🎬',6=>'🎥',7=>'🖼️',
    8=>'🎞️',9=>'✨',10=>'📌',11=>'🖼️',12=>'🔍',13=>'👥',14=>'✅'
];

$date    = date('d/m/Y H:i');
$title   = htmlspecialchars($project['title']);
$channel = htmlspecialchars($project['channel_name']);
$author  = htmlspecialchars($project['author']);
$tokens  = number_format($project['tokens_used'], 0, ',', '.');
$created = date('d/m/Y H:i', strtotime($project['created_at']));

header('Content-Type: text/html; charset=utf-8');
if (isset($_GET['download'])) {
    header('Content-Disposition: attachment; filename="relatorio-' . $projectId . '-' . date('Ymd') . '.html"');
}

echo '<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Relatório — ' . $title . '</title>
<style>
  @import url("https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap");
  *{margin:0;padding:0;box-sizing:border-box}
  body{background:#0a0a0f;color:#e2e8f0;font-family:"DM Sans",sans-serif;line-height:1.7}
  .cover{min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;
    background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(99,102,241,.25) 0%,transparent 70%);
    border-bottom:1px solid rgba(99,102,241,.2);padding:60px 40px}
  .cover-badge{background:rgba(99,102,241,.15);border:1px solid rgba(99,102,241,.4);color:#a5b4fc;
    padding:6px 18px;border-radius:999px;font-size:12px;letter-spacing:2px;text-transform:uppercase;margin-bottom:24px}
  .cover h1{font-family:"Syne",sans-serif;font-size:clamp(2rem,5vw,4rem);font-weight:800;
    background:linear-gradient(135deg,#fff 0%,#a5b4fc 50%,#818cf8 100%);-webkit-background-clip:text;
    -webkit-text-fill-color:transparent;background-clip:text;margin-bottom:16px;max-width:800px}
  .cover-meta{display:flex;gap:32px;flex-wrap:wrap;justify-content:center;margin-top:32px}
  .meta-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
    border-radius:12px;padding:16px 24px;text-align:left}
  .meta-label{font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:#64748b;margin-bottom:4px}
  .meta-value{font-size:14px;font-weight:600;color:#e2e8f0}
  .container{max-width:900px;margin:0 auto;padding:60px 24px}
  .toc{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
    border-radius:16px;padding:32px;margin-bottom:60px}
  .toc h2{font-family:"Syne",sans-serif;font-size:18px;font-weight:700;color:#a5b4fc;margin-bottom:20px}
  .toc-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .toc-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:8px;
    border:1px solid transparent;transition:all .2s;text-decoration:none;color:#94a3b8}
  .toc-item:hover{background:rgba(99,102,241,.1);border-color:rgba(99,102,241,.3);color:#e2e8f0}
  .toc-num{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;
    font-size:11px;font-weight:700;flex-shrink:0}
  .block-section{margin-bottom:56px;scroll-margin-top:80px}
  .block-header{display:flex;align-items:center;gap:14px;margin-bottom:20px;padding-bottom:16px;
    border-bottom:1px solid rgba(255,255,255,.06)}
  .block-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;
    justify-content:center;font-size:20px;flex-shrink:0}
  .block-title{font-family:"Syne",sans-serif;font-size:22px;font-weight:700;color:#f1f5f9}
  .block-content{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06);
    border-radius:12px;padding:28px;white-space:pre-wrap;font-size:14.5px;color:#cbd5e1;line-height:1.8}
  .footer{text-align:center;padding:48px 24px;color:#475569;font-size:13px;
    border-top:1px solid rgba(255,255,255,.06)}
  .print-btn{position:fixed;bottom:24px;right:24px;background:#6366f1;color:#fff;
    border:none;padding:12px 24px;border-radius:12px;font-family:"DM Sans",sans-serif;
    font-weight:600;cursor:pointer;box-shadow:0 4px 24px rgba(99,102,241,.4);font-size:14px}
  .print-btn:hover{background:#4f46e5}
  @media print{.print-btn{display:none}body{background:#fff;color:#000}.block-content{background:#f8f9fa;color:#000}}
</style>
</head>
<body>
<div class="cover">
  <div class="cover-badge">Relatório de Produção</div>
  <h1>' . $title . '</h1>
  <div class="cover-meta">
    <div class="meta-item"><div class="meta-label">Canal</div><div class="meta-value">' . $channel . '</div></div>
    <div class="meta-item"><div class="meta-label">Criado por</div><div class="meta-value">' . $author . '</div></div>
    <div class="meta-item"><div class="meta-label">Data</div><div class="meta-value">' . $created . '</div></div>
    <div class="meta-item"><div class="meta-label">Tokens usados</div><div class="meta-value">' . $tokens . '</div></div>
    <div class="meta-item"><div class="meta-label">Blocos gerados</div><div class="meta-value">' . count($blocks) . ' / 14</div></div>
  </div>
</div>
<div class="container">
  <div class="toc">
    <h2>📋 Índice de Conteúdo</h2>
    <div class="toc-grid">';

foreach ($blocks as $b) {
    $n   = $b['block_number'];
    $c   = $blockColors[$n] ?? '#6366f1';
    $ico = $blockIcons[$n] ?? '▪';
    echo '<a class="toc-item" href="#block-' . $n . '">
            <div class="toc-num" style="background:' . $c . '22;color:' . $c . '">' . $n . '</div>
            <span>' . $ico . ' ' . htmlspecialchars($b['block_name']) . '</span>
          </a>';
}

echo '</div></div>';

foreach ($blocks as $b) {
    $n    = $b['block_number'];
    $c    = $blockColors[$n] ?? '#6366f1';
    $ico  = $blockIcons[$n] ?? '▪';
    $name = htmlspecialchars($b['block_name']);
    $cont = htmlspecialchars($b['content']);
    echo '<div class="block-section" id="block-' . $n . '">
            <div class="block-header">
              <div class="block-icon" style="background:' . $c . '20;border:1px solid ' . $c . '40">' . $ico . '</div>
              <div>
                <div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:2px">Bloco ' . $n . '</div>
                <div class="block-title">' . $name . '</div>
              </div>
            </div>
            <div class="block-content">' . $cont . '</div>
          </div>';
}

echo '</div>
<div class="footer">
  <strong style="color:#a5b4fc">Tati Indicando — Studio</strong><br>
  Relatório gerado em ' . $date . ' · ' . count($blocks) . ' blocos · ' . $tokens . ' tokens
</div>
<button class="print-btn" onclick="window.print()">🖨️ Imprimir / Salvar PDF</button>
</body></html>';

// Registrar no banco
try {
    $db->prepare("INSERT INTO reports (project_id, user_id, file_name, file_path, format) VALUES (?,?,?,?,?)")
       ->execute([$projectId, $_SESSION['user_id'], 'relatorio-'.$projectId.'.html', 'inline', 'html']);
} catch(Exception $e) {}

auditLog('report_generated', "Projeto #{$projectId}");
