<?php
// ============================================================
// api/projects.php — CRUD de Projetos
// ============================================================

require_once __DIR__ . '/../includes/config.php';
requireAuth();

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$db     = getDB();

switch ($action) {

    case 'create':
        $title      = clean($_POST['title'] ?? '');
        $script     = trim($_POST['script'] ?? '');
        $videoType  = clean($_POST['video_type'] ?? 'Ranking / comparação / review afiliado');
        $channel    = clean($_POST['channel_name'] ?? 'Tati Indicando');
        $niche      = clean($_POST['niche'] ?? 'Eletrodomésticos');

        if (!$title || !$script) {
            echo json_encode(['success' => false, 'message' => 'Título e roteiro são obrigatórios.']);
            exit;
        }

        if (strlen($script) < 100) {
            echo json_encode(['success' => false, 'message' => 'O roteiro parece muito curto. Cole o roteiro completo.']);
            exit;
        }

        $stmt = $db->prepare("
            INSERT INTO projects (user_id, title, niche, channel_name, video_type, script, status)
            VALUES (?,?,?,?,?,?,'pending')
        ");
        $stmt->execute([$_SESSION['user_id'], $title, $niche, $channel, $videoType, $script]);
        $id = $db->lastInsertId();

        auditLog('project_created', "Projeto: {$title} (#{$id})");
        echo json_encode(['success' => true, 'project_id' => $id, 'message' => 'Projeto criado!']);
        break;

    case 'list':
        $userId = $_SESSION['user_id'];
        $role   = $_SESSION['user_role'];

        // Admin vê todos; outros veem apenas os seus
        if ($role === 'admin') {
            $stmt = $db->query("
                SELECT p.*, u.name as user_name,
                       (SELECT COUNT(*) FROM project_blocks pb WHERE pb.project_id = p.id) as blocks_count
                FROM projects p
                JOIN users u ON u.id = p.user_id
                ORDER BY p.created_at DESC
                LIMIT 50
            ");
        } else {
            $stmt = $db->prepare("
                SELECT p.*, u.name as user_name,
                       (SELECT COUNT(*) FROM project_blocks pb WHERE pb.project_id = p.id) as blocks_count
                FROM projects p
                JOIN users u ON u.id = p.user_id
                WHERE p.user_id = ?
                ORDER BY p.created_at DESC
                LIMIT 50
            ");
            $stmt->execute([$userId]);
        }

        echo json_encode(['success' => true, 'projects' => $stmt->fetchAll()]);
        break;

    case 'get':
        $id   = (int)($_GET['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM projects WHERE id = ?");
        $stmt->execute([$id]);
        $project = $stmt->fetch();

        if (!$project) {
            echo json_encode(['success' => false, 'message' => 'Projeto não encontrado.']);
            exit;
        }

        // Verificar permissão
        if ($_SESSION['user_role'] !== 'admin' && $project['user_id'] != $_SESSION['user_id']) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado.']);
            exit;
        }

        // Buscar blocos
        $blkStmt = $db->prepare("SELECT * FROM project_blocks WHERE project_id = ? ORDER BY block_number");
        $blkStmt->execute([$id]);
        $blocks = $blkStmt->fetchAll();

        echo json_encode(['success' => true, 'project' => $project, 'blocks' => $blocks]);
        break;

    case 'delete':
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT user_id FROM projects WHERE id=?");
        $stmt->execute([$id]);
        $p = $stmt->fetch();

        if (!$p || ($_SESSION['user_role'] !== 'admin' && $p['user_id'] != $_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado.']);
            exit;
        }

        $db->prepare("DELETE FROM projects WHERE id=?")->execute([$id]);
        auditLog('project_deleted', "Projeto #{$id}");
        echo json_encode(['success' => true, 'message' => 'Projeto excluído.']);
        break;

    case 'reset':
        // Resetar para re-processar
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT user_id FROM projects WHERE id=?");
        $stmt->execute([$id]);
        $p = $stmt->fetch();

        if (!$p || ($_SESSION['user_role'] !== 'admin' && $p['user_id'] != $_SESSION['user_id'])) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado.']);
            exit;
        }

        $db->prepare("DELETE FROM project_blocks WHERE project_id=?")->execute([$id]);
        $db->prepare("UPDATE projects SET status='pending', tokens_used=0 WHERE id=?")->execute([$id]);
        auditLog('project_reset', "Projeto #{$id} resetado");
        echo json_encode(['success' => true, 'message' => 'Projeto resetado. Pronto para reprocessar.']);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Ação inválida.']);
}
