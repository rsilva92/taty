<?php
// ============================================================
// config.php — Configurações Globais
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'seu_usuario_mysql');       // ← ALTERE
define('DB_PASS', 'sua_senha_mysql');          // ← ALTERE
define('DB_NAME', 'tati_platform');

define('CLAUDE_API_KEY', 'sk-ant-sua-chave-aqui'); // ← ALTERE
define('CLAUDE_MODEL', 'claude-sonnet-4-20250514');
define('CLAUDE_MAX_TOKENS', 8000);

define('BASE_URL', 'https://seudominio.com.br/tati-platform'); // ← ALTERE
define('REPORTS_DIR', __DIR__ . '/uploads/reports/');
define('APP_NAME', 'Tati Indicando — Studio');
define('APP_VERSION', '1.0.0');

// Sessão segura
session_start();
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);

// Timezone
date_default_timezone_set('America/Sao_Paulo');

// Error reporting (desative em produção)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/logs/error.log');

// Função de conexão PDO
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Falha na conexão com o banco de dados.']));
        }
    }
    return $pdo;
}

// Auth helper
function requireAuth(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function requireAdmin(): void {
    requireAuth();
    if ($_SESSION['user_role'] !== 'admin') {
        header('Location: ' . BASE_URL . '/pages/dashboard.php');
        exit;
    }
}

// Sanitize
function clean(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// Log de auditoria
function auditLog(string $action, string $description = '', ?int $userId = null): void {
    try {
        $db = getDB();
        $uid = $userId ?? ($_SESSION['user_id'] ?? null);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $stmt = $db->prepare("INSERT INTO audit_logs (user_id, action, description, ip_address) VALUES (?,?,?,?)");
        $stmt->execute([$uid, $action, $description, $ip]);
    } catch (Exception $e) {}
}
