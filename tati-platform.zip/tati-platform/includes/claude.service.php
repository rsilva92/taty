<?php
// ============================================================
// claude.service.php — Comunicação com a API do Claude
// ============================================================

require_once __DIR__ . '/config.php';

class ClaudeService {

    private string $apiKey;
    private string $model;
    private int $maxTokens;
    private string $baseUrl = 'https://api.anthropic.com/v1/messages';

    public function __construct() {
        $this->apiKey   = CLAUDE_API_KEY;
        $this->model    = CLAUDE_MODEL;
        $this->maxTokens = CLAUDE_MAX_TOKENS;
    }

    /**
     * Envia um único prompt e retorna a resposta em texto
     */
    public function complete(string $systemPrompt, string $userMessage): array {
        $payload = [
            'model'      => $this->model,
            'max_tokens' => $this->maxTokens,
            'system'     => $systemPrompt,
            'messages'   => [
                ['role' => 'user', 'content' => $userMessage]
            ]
        ];

        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'x-api-key: ' . $this->apiKey,
                'anthropic-version: 2023-06-01',
            ],
            CURLOPT_POSTFIELDS  => json_encode($payload),
            CURLOPT_TIMEOUT     => 120,
        ]);

        $raw  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($raw === false) {
            return ['success' => false, 'error' => 'Erro de conexão com a API.', 'content' => ''];
        }

        $data = json_decode($raw, true);

        if ($code !== 200) {
            $msg = $data['error']['message'] ?? 'Erro desconhecido na API.';
            return ['success' => false, 'error' => $msg, 'content' => ''];
        }

        $text   = $data['content'][0]['text'] ?? '';
        $tokens = ($data['usage']['input_tokens'] ?? 0) + ($data['usage']['output_tokens'] ?? 0);

        return ['success' => true, 'content' => $text, 'tokens' => $tokens, 'error' => ''];
    }

    /**
     * Gera os 14 blocos do sistema multiagente em sequência
     * Chama o Claude com prompts especializados por bloco
     */
    public function generateAllBlocks(string $script, array $projectData): \Generator {
        $blocks = $this->getBlockDefinitions();

        foreach ($blocks as $num => $block) {
            $systemPrompt = $this->buildSystemPrompt($block, $projectData);
            $userMessage  = $this->buildUserMessage($block, $script, $projectData);

            $result = $this->complete($systemPrompt, $userMessage);

            yield [
                'block_number' => $num,
                'block_name'   => $block['name'],
                'success'      => $result['success'],
                'content'      => $result['content'],
                'tokens'       => $result['tokens'] ?? 0,
                'error'        => $result['error'] ?? '',
            ];
        }
    }

    private function buildSystemPrompt(array $block, array $project): string {
        return <<<PROMPT
Você é um agente especialista em produção de conteúdo YouTube faceless no nicho de {$project['niche']}.
Canal: {$project['channel_name']}
Tipo de vídeo: {$project['video_type']}
Público-alvo: Comprador quente, pesquisando antes de comprar
Objetivo: Fazer o espectador clicar nos links da descrição
Tom: Natural, direto, confiável, comercial e humano
Formato visual: Canal faceless, realista, comercial, 16:9, estilo vídeo premium de produto
Mercados: Mercado Livre, Magalu, Shopee

REGRAS ABSOLUTAS:
- Tudo deve nascer do roteiro
- Não inventar características técnicas
- Não criar benefício que o roteiro não sustenta
- Não citar lojas na narração
- Não usar abertura clichê
- Não usar "fala pessoal"
- Não revelar o 1º lugar antes da hora
- Cada cena deve espelhar um trecho do roteiro
- Cada benefício precisa virar prova visual
- Imagens sem texto
- Prompts hiper-realistas, produto fiel à referência real
- Sem distorções, sem logotipos inventados, sem CGI artificial

Sua tarefa agora: gerar APENAS o {$block['label']} com máxima qualidade e precisão.
Responda SOMENTE com o conteúdo desse bloco, sem introduções ou explicações extras.
PROMPT;
    }

    private function buildUserMessage(array $block, string $script, array $project): string {
        return "ROTEIRO COMPLETO:\n{$script}\n\n---\n\nGere agora: {$block['label']}\n{$block['instructions']}";
    }

    private function getBlockDefinitions(): array {
        return [
            1  => ['name' => 'Mapa do Roteiro',          'label' => 'BLOCO 1 — MAPA DO ROTEIRO',
                   'instructions' => 'Mapeie: tema central, produtos mencionados, ordem de revelação, pontos de retenção, ganchos, CTAs implícitos, duração estimada por segmento.'],
            2  => ['name' => 'Verdade-Base',              'label' => 'BLOCO 2 — VERDADE-BASE EXTRAÍDA DO ROTEIRO',
                   'instructions' => 'Liste apenas fatos reais do roteiro: nomes dos produtos, características mencionadas, diferenciais citados, preços se houver, posição no ranking. Nada inventado.'],
            3  => ['name' => 'Ângulo Estratégico',        'label' => 'BLOCO 3 — ÂNGULO ESTRATÉGICO',
                   'instructions' => 'Defina: intenção de busca, palavra-chave principal, ângulo de clique (CTR), ângulo de retenção (watch time), ângulo de compra (conversão).'],
            4  => ['name' => 'Roteiro Otimizado',         'label' => 'BLOCO 4 — ROTEIRO OTIMIZADO',
                   'instructions' => 'Otimize o roteiro para até 6 minutos. Mantenha a essência, melhore o ritmo, remova clichês, fortaleça os ganchos, naturalize o tom. Preserve toda verdade-base.'],
            5  => ['name' => 'Storyboard 3x3',            'label' => 'BLOCO 5 — STORYBOARD 3x3',
                   'instructions' => 'Crie storyboard com 9 a 12 cenas. Para cada cena: número, trecho do roteiro vinculado, descrição visual, emoção, duração estimada.'],
            6  => ['name' => 'Shotlist Detalhada',        'label' => 'BLOCO 6 — SHOTLIST DETALHADA',
                   'instructions' => 'Para cada cena do storyboard: tipo de plano, ângulo, movimento, produto em destaque, foco, iluminação, duração.'],
            7  => ['name' => 'Prompts de Imagem IA',      'label' => 'BLOCO 7 — PROMPTS DE IMAGEM IA',
                   'instructions' => 'Para cada cena: trecho do roteiro vinculado | objetivo visual | prompt completo em inglês (hiper-realista) | iluminação | lente | enquadramento | composição | frame inicial | frame final | negative prompt.'],
            8  => ['name' => 'Prompts de Vídeo IA',       'label' => 'BLOCO 8 — PROMPTS DE VÍDEO IA',
                   'instructions' => 'Para cada cena: duração | intenção visual | movimento de câmera | ação do produto | keyframe inicial | keyframe intermediário | keyframe final | transição | prompt completo em inglês | negative prompt.'],
            9  => ['name' => 'Overlays de Benefícios',    'label' => 'BLOCO 9 — OVERLAYS DE BENEFÍCIOS',
                   'instructions' => 'Para cada benefício do roteiro: texto do overlay (máx 5 palavras), cena correspondente, posição na tela, cor, animação de entrada, duração na tela.'],
            10 => ['name' => 'Títulos',                   'label' => 'BLOCO 10 — TÍTULOS',
                   'instructions' => "Gere:\n- 5 títulos Search (foco em palavra-chave)\n- 5 títulos Browse (foco em curiosidade/emoção)\n- 5 títulos Comparação (foco em decisão)\n- 5 títulos Decisão de Compra (foco em urgência/valor)"],
            11 => ['name' => 'Thumbnail',                 'label' => 'BLOCO 11 — THUMBNAIL',
                   'instructions' => 'Entregue: conceito | layout detalhado | psicologia de clique | texto curto sugerido | prompt completo da thumbnail em inglês | 3 variações de texto alternativas.'],
            12 => ['name' => 'Descrição SEO',             'label' => 'BLOCO 12 — DESCRIÇÃO SEO',
                   'instructions' => "Estrutura:\n- CTA inicial (2 linhas)\n- Timestamps\n- 3º lugar + links [LINK_ML] [LINK_MAGALU] [LINK_SHOPEE]\n- 2º lugar + links\n- 1º lugar + links\n- Link do vídeo\n- Resumo (3 linhas)\n- 20 palavras-chave long-tail separadas por vírgula\n- 3 hashtags finais"],
            13 => ['name' => 'Aba Comunidade',            'label' => 'BLOCO 13 — ABA COMUNIDADE',
                   'instructions' => 'Entregue: ideia de carrossel 1:1 (5 slides) | prompts de imagem para cada slide | legenda completa | CTA | palavras-chave | 3 hashtags.'],
            14 => ['name' => 'Auditoria Final',           'label' => 'BLOCO 14 — AUDITORIA FINAL',
                   'instructions' => "Verifique cada item:\n✅/❌ Tudo nasceu do roteiro?\n✅/❌ Tem invenção técnica?\n✅/❌ Cenas conectadas ao roteiro?\n✅/❌ Títulos prometem o que o vídeo entrega?\n✅/❌ Thumbnail não repete o título?\n✅/❌ Descrição otimizada?\n✅/❌ CTA natural?\n✅/❌ Prompts visuais fiéis?\n✅/❌ Decisão final clara?\n\nNota geral: X/10\nPontos de melhoria:"],
        ];
    }
}
