<?php
require_once __DIR__ . '/../includes/config.php';
requireAuth();

$db = getDB();

// Stats
$userId = $_SESSION['user_id'];
$role   = $_SESSION['user_role'];
$isAdmin = $role === 'admin';

$where = $isAdmin ? '' : 'WHERE p.user_id = ' . $userId;

$stats = $db->query("
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed,
      SUM(CASE WHEN status='processing' THEN 1 ELSE 0 END) as processing,
      SUM(tokens_used) as total_tokens
    FROM projects p $where
")->fetch();
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Tati Indicando Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

:root {
  --bg: #07070e;
  --surface: #0f0f1a;
  --surface2: #131320;
  --border: rgba(255,255,255,.07);
  --accent: #6366f1;
  --accent2: #a855f7;
  --green: #22c55e;
  --yellow: #eab308;
  --red: #ef4444;
  --text: #e2e8f0;
  --muted: #64748b;
  --sidebar-w: 240px;
}

body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  display: flex;
  min-height: 100vh;
  overflow-x: hidden;
}

/* ── SIDEBAR ── */
.sidebar {
  width: var(--sidebar-w);
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0; left: 0; bottom: 0;
  z-index: 100;
}

.sidebar-brand {
  padding: 24px 20px;
  border-bottom: 1px solid var(--border);
  display: flex; align-items: center; gap: 12px;
}

.sidebar-logo {
  width: 36px; height: 36px;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 16px;
  flex-shrink: 0;
}

.sidebar-brand-text h2 {
  font-family: 'Syne', sans-serif;
  font-size: 13px; font-weight: 800;
  background: linear-gradient(135deg, #fff 0%, #a5b4fc 100%);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
  line-height: 1.2;
}

.sidebar-brand-text p { font-size: 10px; color: var(--muted); margin-top: 1px; }

.sidebar-nav { flex: 1; padding: 16px 12px; overflow-y: auto; }

.nav-section {
  font-size: 10px; font-weight: 700; text-transform: uppercase;
  letter-spacing: 1.5px; color: var(--muted);
  padding: 0 8px; margin: 20px 0 8px;
}

.nav-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 12px;
  border-radius: 10px;
  font-size: 13.5px; font-weight: 500;
  color: #94a3b8;
  cursor: pointer;
  transition: all .15s;
  margin-bottom: 2px;
  text-decoration: none;
}

.nav-item:hover { background: rgba(255,255,255,.05); color: var(--text); }
.nav-item.active { background: rgba(99,102,241,.15); color: #a5b4fc; font-weight: 600; }
.nav-item .icon { width: 18px; text-align: center; font-size: 15px; }

.sidebar-footer {
  padding: 16px 12px;
  border-top: 1px solid var(--border);
}

.user-card {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 12px;
  background: rgba(255,255,255,.04);
  border-radius: 10px;
  border: 1px solid var(--border);
}

.user-avatar {
  width: 32px; height: 32px;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 700; color: #fff;
  flex-shrink: 0;
}

.user-info { flex: 1; min-width: 0; }
.user-name { font-size: 12px; font-weight: 600; color: var(--text); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-role { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; }

.btn-logout {
  background: none; border: none; color: var(--muted);
  cursor: pointer; font-size: 14px; padding: 4px;
  transition: color .15s;
}
.btn-logout:hover { color: var(--red); }

/* ── MAIN ── */
.main {
  margin-left: var(--sidebar-w);
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.topbar {
  background: rgba(7,7,14,.8);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--border);
  padding: 16px 32px;
  display: flex; align-items: center; justify-content: space-between;
  position: sticky; top: 0; z-index: 50;
}

.page-title { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 700; }
.page-sub { font-size: 12px; color: var(--muted); margin-top: 1px; }

.btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 20px;
  border-radius: 10px;
  font-family: 'DM Sans', sans-serif;
  font-size: 13.5px; font-weight: 600;
  cursor: pointer; border: none;
  transition: all .15s;
}

.btn-primary {
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  color: #fff;
  box-shadow: 0 4px 16px rgba(99,102,241,.3);
}
.btn-primary:hover { opacity: .9; transform: translateY(-1px); }

.btn-ghost {
  background: rgba(255,255,255,.05);
  border: 1px solid var(--border);
  color: var(--text);
}
.btn-ghost:hover { background: rgba(255,255,255,.08); }

.btn-danger { background: rgba(239,68,68,.15); border: 1px solid rgba(239,68,68,.3); color: #fca5a5; }
.btn-danger:hover { background: rgba(239,68,68,.25); }

.content { padding: 32px; flex: 1; }

/* ── STATS ── */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 16px;
  margin-bottom: 32px;
}

.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 22px;
  position: relative;
  overflow: hidden;
}

.stat-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
}

.stat-card.blue::before { background: linear-gradient(90deg, var(--accent), var(--accent2)); }
.stat-card.green::before { background: var(--green); }
.stat-card.yellow::before { background: var(--yellow); }
.stat-card.purple::before { background: var(--accent2); }

.stat-icon { font-size: 22px; margin-bottom: 12px; }
.stat-value { font-family: 'Syne', sans-serif; font-size: 28px; font-weight: 800; color: var(--text); }
.stat-label { font-size: 12px; color: var(--muted); margin-top: 4px; }

/* ── TABS ── */
.tabs {
  display: flex; gap: 4px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 4px;
  margin-bottom: 24px;
  width: fit-content;
}

.tab {
  padding: 8px 20px;
  border-radius: 8px;
  font-size: 13px; font-weight: 500;
  color: var(--muted);
  cursor: pointer;
  transition: all .15s;
  border: none;
  background: none;
}

.tab.active {
  background: rgba(99,102,241,.2);
  color: #a5b4fc;
  font-weight: 600;
}

/* ── PROJECT LIST ── */
.projects-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 20px;
}

.section-title { font-family: 'Syne', sans-serif; font-size: 16px; font-weight: 700; }

.projects-list { display: flex; flex-direction: column; gap: 12px; }

.project-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 20px 24px;
  display: flex; align-items: center; gap: 18px;
  transition: border-color .2s, transform .15s;
  cursor: pointer;
}

.project-card:hover {
  border-color: rgba(99,102,241,.35);
  transform: translateY(-1px);
}

.project-status {
  width: 10px; height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
}

.status-completed { background: var(--green); box-shadow: 0 0 8px var(--green); }
.status-processing { background: var(--yellow); animation: pulse 1.5s infinite; }
.status-pending { background: var(--muted); }
.status-error { background: var(--red); }

@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }

.project-info { flex: 1; min-width: 0; }
.project-title { font-weight: 600; font-size: 14.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.project-meta { font-size: 12px; color: var(--muted); margin-top: 3px; }

.project-blocks {
  font-size: 12px; color: var(--muted);
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 4px 10px;
  white-space: nowrap;
}

.project-actions { display: flex; gap: 6px; }

/* ── MODAL ── */
.overlay {
  position: fixed; inset: 0; z-index: 200;
  background: rgba(0,0,0,.7);
  backdrop-filter: blur(6px);
  display: flex; align-items: center; justify-content: center;
  padding: 24px;
  opacity: 0; pointer-events: none;
  transition: opacity .2s;
}

.overlay.open { opacity: 1; pointer-events: all; }

.modal {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 20px;
  width: 100%; max-width: 680px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 32px 80px rgba(0,0,0,.6);
  transform: translateY(16px);
  transition: transform .25s;
}

.overlay.open .modal { transform: translateY(0); }

.modal-header {
  padding: 24px 28px;
  border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
}

.modal-title { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 700; }

.modal-close {
  background: rgba(255,255,255,.08);
  border: none; color: var(--muted);
  width: 32px; height: 32px;
  border-radius: 8px;
  cursor: pointer; font-size: 18px;
  display: flex; align-items: center; justify-content: center;
  transition: all .15s;
}
.modal-close:hover { background: rgba(239,68,68,.2); color: var(--red); }

.modal-body { padding: 24px 28px; }

.field { margin-bottom: 20px; }
.field label { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--muted); margin-bottom: 8px; }

.field input, .field select, .field textarea {
  width: 100%;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 12px 14px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  outline: none;
  transition: border-color .2s;
  resize: vertical;
}

.field input:focus, .field select:focus, .field textarea:focus {
  border-color: rgba(99,102,241,.5);
  box-shadow: 0 0 0 3px rgba(99,102,241,.1);
}

.field textarea { min-height: 200px; line-height: 1.6; font-size: 13px; }
.field input::placeholder, .field textarea::placeholder { color: #475569; }
.field select option { background: #1e1e2e; }

.char-count { font-size: 11px; color: var(--muted); margin-top: 4px; text-align: right; }

.modal-footer {
  padding: 20px 28px;
  border-top: 1px solid var(--border);
  display: flex; gap: 10px; justify-content: flex-end;
}

/* ── PROJECT VIEWER ── */
.viewer-overlay {
  position: fixed; inset: 0; z-index: 300;
  background: var(--bg);
  overflow-y: auto;
  opacity: 0; pointer-events: none;
  transition: opacity .2s;
}

.viewer-overlay.open { opacity: 1; pointer-events: all; }

.viewer-topbar {
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  padding: 16px 32px;
  display: flex; align-items: center; gap: 16px;
  position: sticky; top: 0; z-index: 10;
}

.viewer-content { max-width: 900px; margin: 0 auto; padding: 40px 32px; }

.blocks-nav {
  display: flex; flex-wrap: wrap; gap: 6px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 14px;
  margin-bottom: 32px;
}

.block-nav-btn {
  padding: 6px 14px;
  border-radius: 7px;
  font-size: 12px; font-weight: 600;
  border: none; cursor: pointer;
  background: rgba(255,255,255,.05);
  color: var(--muted);
  transition: all .15s;
}

.block-nav-btn:hover { background: rgba(99,102,241,.15); color: #a5b4fc; }
.block-nav-btn.done { color: var(--green); }

.block-item {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 14px;
  margin-bottom: 20px;
  overflow: hidden;
}

.block-item-header {
  display: flex; align-items: center; gap: 12px;
  padding: 18px 22px;
  cursor: pointer;
  transition: background .15s;
}

.block-item-header:hover { background: rgba(255,255,255,.02); }

.block-num {
  width: 32px; height: 32px;
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 700;
  flex-shrink: 0;
}

.block-item-title { font-weight: 600; font-size: 14px; flex: 1; }
.block-chevron { color: var(--muted); transition: transform .2s; }
.block-item.open .block-chevron { transform: rotate(180deg); }

.block-item-body {
  display: none;
  padding: 0 22px 22px;
}

.block-item.open .block-item-body { display: block; }

.block-text {
  background: rgba(0,0,0,.3);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 20px;
  font-size: 13.5px;
  line-height: 1.8;
  color: #cbd5e1;
  white-space: pre-wrap;
  overflow-x: auto;
}

/* ── PROGRESS ── */
.progress-overlay {
  position: fixed; inset: 0; z-index: 400;
  background: rgba(0,0,0,.85);
  backdrop-filter: blur(8px);
  display: flex; align-items: center; justify-content: center;
  opacity: 0; pointer-events: none;
  transition: opacity .2s;
}

.progress-overlay.open { opacity: 1; pointer-events: all; }

.progress-card {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 24px;
  padding: 40px;
  width: 100%; max-width: 560px;
  box-shadow: 0 32px 80px rgba(0,0,0,.6);
}

.progress-header { text-align: center; margin-bottom: 32px; }
.progress-header h2 { font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; margin-bottom: 8px; }
.progress-header p { font-size: 13px; color: var(--muted); }

.progress-bar-wrap {
  background: rgba(255,255,255,.06);
  border-radius: 99px;
  height: 6px;
  margin-bottom: 28px;
  overflow: hidden;
}

.progress-bar-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--accent), var(--accent2));
  border-radius: 99px;
  transition: width .4s ease;
  width: 0%;
}

.progress-blocks { display: flex; flex-direction: column; gap: 8px; max-height: 300px; overflow-y: auto; }

.progress-block {
  display: flex; align-items: center; gap: 12px;
  padding: 10px 14px;
  background: rgba(255,255,255,.03);
  border-radius: 10px;
  font-size: 13px;
  transition: all .2s;
}

.progress-block.active { background: rgba(99,102,241,.1); border: 1px solid rgba(99,102,241,.2); }
.progress-block.done { background: rgba(34,197,94,.06); border: 1px solid rgba(34,197,94,.15); }
.progress-block.error-block { background: rgba(239,68,68,.06); border: 1px solid rgba(239,68,68,.15); }

.pb-icon { width: 24px; height: 24px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 12px; flex-shrink: 0; }
.pb-name { flex: 1; font-weight: 500; }
.pb-status { font-size: 11px; color: var(--muted); }

.toast {
  position: fixed; bottom: 24px; right: 24px; z-index: 999;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 14px 20px;
  font-size: 13.5px;
  box-shadow: 0 8px 32px rgba(0,0,0,.4);
  transform: translateY(100px);
  opacity: 0;
  transition: all .3s;
  max-width: 320px;
}

.toast.show { transform: translateY(0); opacity: 1; }
.toast.success { border-color: rgba(34,197,94,.4); }
.toast.error { border-color: rgba(239,68,68,.4); }

.empty-state {
  text-align: center;
  padding: 64px 24px;
  color: var(--muted);
}

.empty-state .icon { font-size: 48px; margin-bottom: 16px; }
.empty-state h3 { font-family: 'Syne', sans-serif; font-size: 18px; color: var(--text); margin-bottom: 8px; }
.empty-state p { font-size: 13px; }

.badge {
  display: inline-flex; align-items: center;
  padding: 3px 10px;
  border-radius: 99px;
  font-size: 11px; font-weight: 600;
  text-transform: uppercase; letter-spacing: .5px;
}

.badge-green { background: rgba(34,197,94,.12); color: #86efac; border: 1px solid rgba(34,197,94,.25); }
.badge-yellow { background: rgba(234,179,8,.12); color: #fde047; border: 1px solid rgba(234,179,8,.25); }
.badge-gray { background: rgba(100,116,139,.12); color: #94a3b8; border: 1px solid rgba(100,116,139,.25); }
.badge-red { background: rgba(239,68,68,.12); color: #fca5a5; border: 1px solid rgba(239,68,68,.25); }
.badge-blue { background: rgba(99,102,241,.12); color: #a5b4fc; border: 1px solid rgba(99,102,241,.25); }

@media (max-width: 768px) {
  .sidebar { display: none; }
  .main { margin-left: 0; }
  .content { padding: 20px; }
  .topbar { padding: 14px 20px; }
  .stats-grid { grid-template-columns: 1fr 1fr; }
}
</style>
</head>
<body>

<!-- ── SIDEBAR ── -->
<aside class="sidebar">
  <div class="sidebar-brand">
    <div class="sidebar-logo">✦</div>
    <div class="sidebar-brand-text">
      <h2>Tati Indicando</h2>
      <p>Production Studio</p>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">Principal</div>
    <a class="nav-item active" href="#">
      <span class="icon">⬡</span> Dashboard
    </a>
    <a class="nav-item" href="#" onclick="showTab('projects')">
      <span class="icon">🎬</span> Projetos
    </a>
    <a class="nav-item" href="#" onclick="openNewProject()">
      <span class="icon">✦</span> Novo Projeto
    </a>

    <div class="nav-section">Histórico</div>
    <a class="nav-item" href="#" onclick="showTab('reports')">
      <span class="icon">📊</span> Relatórios
    </a>
    <a class="nav-item" href="api/report.php?project_id=0" target="_blank" style="display:none" id="reportLink">
      <span class="icon">⬇</span> Último Relatório
    </a>

    <?php if ($isAdmin): ?>
    <div class="nav-section">Administração</div>
    <a class="nav-item" href="#" onclick="showTab('users')">
      <span class="icon">👥</span> Usuários
    </a>
    <a class="nav-item" href="#" onclick="showTab('settings')">
      <span class="icon">⚙</span> Configurações
    </a>
    <?php endif; ?>
  </nav>

  <div class="sidebar-footer">
    <div class="user-card">
      <div class="user-avatar"><?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?></div>
      <div class="user-info">
        <div class="user-name"><?= clean($_SESSION['user_name']) ?></div>
        <div class="user-role"><?= $_SESSION['user_role'] ?></div>
      </div>
      <button class="btn-logout" onclick="logout()" title="Sair">⎋</button>
    </div>
  </div>
</aside>

<!-- ── MAIN ── -->
<main class="main">
  <div class="topbar">
    <div>
      <div class="page-title" id="pageTitle">Dashboard</div>
      <div class="page-sub" id="pageSub">Visão geral da plataforma</div>
    </div>
    <button class="btn btn-primary" onclick="openNewProject()">
      <span>✦</span> Novo Projeto
    </button>
  </div>

  <div class="content">

    <!-- STATS -->
    <div class="stats-grid" id="statsGrid">
      <div class="stat-card blue">
        <div class="stat-icon">🎬</div>
        <div class="stat-value"><?= $stats['total'] ?? 0 ?></div>
        <div class="stat-label">Total de projetos</div>
      </div>
      <div class="stat-card green">
        <div class="stat-icon">✅</div>
        <div class="stat-value"><?= $stats['completed'] ?? 0 ?></div>
        <div class="stat-label">Concluídos</div>
      </div>
      <div class="stat-card yellow">
        <div class="stat-icon">⚡</div>
        <div class="stat-value"><?= $stats['processing'] ?? 0 ?></div>
        <div class="stat-label">Em processamento</div>
      </div>
      <div class="stat-card purple">
        <div class="stat-icon">🪙</div>
        <div class="stat-value"><?= number_format($stats['total_tokens'] ?? 0, 0, ',', '.') ?></div>
        <div class="stat-label">Tokens usados</div>
      </div>
    </div>

    <!-- PROJECTS LIST -->
    <div id="projectsSection">
      <div class="projects-header">
        <div class="section-title">Projetos Recentes</div>
        <button class="btn btn-ghost" onclick="loadProjects()">🔄 Atualizar</button>
      </div>
      <div class="projects-list" id="projectsList">
        <div class="empty-state">
          <div class="icon">🎬</div>
          <h3>Carregando projetos...</h3>
          <p>Aguarde um momento</p>
        </div>
      </div>
    </div>

  </div>
</main>

<!-- ── MODAL NOVO PROJETO ── -->
<div class="overlay" id="newProjectOverlay" onclick="closeIfOverlay(event,'newProjectOverlay')">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">✦ Novo Projeto</div>
      <button class="modal-close" onclick="closeOverlay('newProjectOverlay')">×</button>
    </div>
    <div class="modal-body">
      <div class="field">
        <label>Título do Projeto</label>
        <input type="text" id="pTitle" placeholder="Ex: Top 3 Air Fryers 2025 — Melhores do Mercado">
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div class="field">
          <label>Nome do Canal</label>
          <input type="text" id="pChannel" value="Tati Indicando">
        </div>
        <div class="field">
          <label>Nicho</label>
          <input type="text" id="pNiche" value="Eletrodomésticos">
        </div>
      </div>
      <div class="field">
        <label>Tipo de Vídeo</label>
        <select id="pVideoType">
          <option>Ranking / comparação / review afiliado</option>
          <option>Review único de produto</option>
          <option>Comparativo 1x1</option>
          <option>Top 5 produtos</option>
          <option>Guia de compra</option>
        </select>
      </div>
      <div class="field">
        <label>Roteiro Completo</label>
        <textarea id="pScript" placeholder="Cole aqui o roteiro completo do vídeo...&#10;&#10;O sistema vai transformar este roteiro nos 14 blocos de produção automaticamente."></textarea>
        <div class="char-count"><span id="charCount">0</span> caracteres</div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeOverlay('newProjectOverlay')">Cancelar</button>
      <button class="btn btn-primary" onclick="createProject()">✦ Criar e Processar</button>
    </div>
  </div>
</div>

<!-- ── VIEWER ── -->
<div class="viewer-overlay" id="viewerOverlay">
  <div class="viewer-topbar">
    <button class="btn btn-ghost" onclick="closeViewer()">← Voltar</button>
    <div style="flex:1">
      <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:15px" id="viewerTitle">—</div>
      <div style="font-size:11px;color:#64748b;margin-top:1px" id="viewerMeta">—</div>
    </div>
    <button class="btn btn-ghost" id="viewerReportBtn" onclick="">📊 Relatório HTML</button>
    <button class="btn btn-ghost" id="viewerJsonBtn" onclick="">⬇ JSON</button>
    <button class="btn btn-danger" id="viewerDeleteBtn" onclick="">🗑 Excluir</button>
  </div>
  <div class="viewer-content">
    <div class="blocks-nav" id="blocksNav"></div>
    <div id="blocksList"></div>
  </div>
</div>

<!-- ── PROGRESS ── -->
<div class="progress-overlay" id="progressOverlay">
  <div class="progress-card">
    <div class="progress-header">
      <div style="font-size:36px;margin-bottom:12px">⚡</div>
      <h2>Sistema Multiagente Ativo</h2>
      <p id="progressMsg">Inicializando agentes especializados...</p>
    </div>
    <div class="progress-bar-wrap">
      <div class="progress-bar-fill" id="progressBar"></div>
    </div>
    <div class="progress-blocks" id="progressBlocks"></div>
    <div style="text-align:center;margin-top:20px;font-size:12px;color:#64748b" id="progressTokens"></div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
const BLOCK_NAMES = [
  '', 'Mapa do Roteiro','Verdade-Base','Ângulo Estratégico','Roteiro Otimizado',
  'Storyboard 3x3','Shotlist Detalhada','Prompts de Imagem IA','Prompts de Vídeo IA',
  'Overlays de Benefícios','Títulos','Thumbnail','Descrição SEO','Aba Comunidade','Auditoria Final'
];

const BLOCK_ICONS = ['','🗺️','💎','🎯','📝','🎬','🎥','🖼️','🎞️','✨','📌','🖼️','🔍','👥','✅'];
const BLOCK_COLORS = ['','#6366f1','#8b5cf6','#a855f7','#ec4899','#f43f5e','#f97316','#eab308','#22c55e','#14b8a6','#06b6d4','#3b82f6','#6366f1','#8b5cf6','#10b981'];

let currentProjectId = null;

// ── CHAR COUNT
document.getElementById('pScript').addEventListener('input', function() {
  document.getElementById('charCount').textContent = this.value.length.toLocaleString('pt-BR');
});

// ── PROJECTS
async function loadProjects() {
  const res = await fetch('api/projects.php?action=list');
  const data = await res.json();
  const list = document.getElementById('projectsList');

  if (!data.success || !data.projects.length) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="icon">🎬</div>
        <h3>Nenhum projeto ainda</h3>
        <p>Crie seu primeiro projeto para começar</p>
        <br>
        <button class="btn btn-primary" onclick="openNewProject()">✦ Criar Projeto</button>
      </div>`;
    return;
  }

  list.innerHTML = data.projects.map(p => {
    const badges = {
      completed: '<span class="badge badge-green">✓ Concluído</span>',
      processing: '<span class="badge badge-yellow">⚡ Processando</span>',
      pending: '<span class="badge badge-gray">⏳ Pendente</span>',
      error: '<span class="badge badge-red">✗ Erro</span>',
    };
    const date = new Date(p.created_at).toLocaleDateString('pt-BR',{day:'2-digit',month:'short',year:'numeric'});
    return `
    <div class="project-card" onclick="openProject(${p.id})">
      <div class="project-status status-${p.status}"></div>
      <div class="project-info">
        <div class="project-title">${escHtml(p.title)}</div>
        <div class="project-meta">${escHtml(p.channel_name)} · ${date} · por ${escHtml(p.user_name)}</div>
      </div>
      <div class="project-blocks">📦 ${p.blocks_count}/14 blocos</div>
      ${badges[p.status] || ''}
      <div class="project-actions" onclick="event.stopPropagation()">
        ${p.status === 'completed' ? `<button class="btn btn-ghost" style="padding:7px 12px;font-size:12px" onclick="openReport(${p.id})">📊</button>` : ''}
      </div>
    </div>`;
  }).join('');
}

// ── OPEN PROJECT VIEWER
async function openProject(id) {
  const res  = await fetch(`api/projects.php?action=get&id=${id}`);
  const data = await res.json();
  if (!data.success) { toast('Erro ao carregar projeto', 'error'); return; }

  currentProjectId = id;
  const p = data.project;
  const blocks = data.blocks;

  document.getElementById('viewerTitle').textContent = p.title;
  document.getElementById('viewerMeta').textContent = `${p.channel_name} · ${p.niche} · ${p.tokens_used?.toLocaleString('pt-BR') || 0} tokens`;

  document.getElementById('viewerReportBtn').onclick = () => window.open(`api/report.php?project_id=${id}`, '_blank');
  document.getElementById('viewerJsonBtn').onclick   = () => window.open(`api/report.php?project_id=${id}&format=json`, '_blank');
  document.getElementById('viewerDeleteBtn').onclick = () => deleteProject(id);

  // Nav
  const nav = document.getElementById('blocksNav');
  nav.innerHTML = blocks.map(b =>
    `<button class="block-nav-btn done" onclick="scrollToBlock(${b.block_number})">
      ${BLOCK_ICONS[b.block_number]} ${b.block_number}
    </button>`
  ).join('');

  // Blocks list
  const bl = document.getElementById('blocksList');
  if (!blocks.length) {
    const isPending = p.status === 'pending';
    bl.innerHTML = `
      <div class="empty-state">
        <div class="icon">${isPending ? '⏳' : '⚠️'}</div>
        <h3>${isPending ? 'Projeto não processado' : 'Nenhum bloco gerado'}</h3>
        <p>${isPending ? 'Clique abaixo para iniciar o sistema multiagente' : 'Ocorreu um erro no processamento'}</p>
        <br>
        <button class="btn btn-primary" onclick="startGeneration(${id})">⚡ Processar Agora</button>
      </div>`;
  } else {
    bl.innerHTML = blocks.map(b => {
      const c = BLOCK_COLORS[b.block_number] || '#6366f1';
      return `
      <div class="block-item" id="block-${b.block_number}">
        <div class="block-item-header" onclick="toggleBlock(this)">
          <div class="block-num" style="background:${c}20;color:${c}">${BLOCK_ICONS[b.block_number]}</div>
          <div class="block-item-title">${escHtml(b.block_name)}</div>
          <div class="block-chevron">⌄</div>
        </div>
        <div class="block-item-body">
          <div class="block-text">${escHtml(b.content)}</div>
        </div>
      </div>`;
    }).join('');
    // Auto-open first
    const first = bl.querySelector('.block-item');
    if (first) first.classList.add('open');
  }

  document.getElementById('viewerOverlay').classList.add('open');
}

function closeViewer() {
  document.getElementById('viewerOverlay').classList.remove('open');
  currentProjectId = null;
}

function scrollToBlock(n) {
  const el = document.getElementById(`block-${n}`);
  if (el) { el.scrollIntoView({behavior:'smooth',block:'start'}); el.classList.add('open'); }
}

function toggleBlock(header) {
  header.parentElement.classList.toggle('open');
}

// ── CREATE PROJECT
function openNewProject() {
  document.getElementById('newProjectOverlay').classList.add('open');
}

async function createProject() {
  const title   = document.getElementById('pTitle').value.trim();
  const script  = document.getElementById('pScript').value.trim();
  const channel = document.getElementById('pChannel').value.trim();
  const niche   = document.getElementById('pNiche').value.trim();
  const vtype   = document.getElementById('pVideoType').value;

  if (!title) { toast('Digite o título do projeto', 'error'); return; }
  if (script.length < 100) { toast('O roteiro parece muito curto. Cole o roteiro completo.', 'error'); return; }

  const fd = new FormData();
  fd.append('action','create');
  fd.append('title',title);
  fd.append('script',script);
  fd.append('channel_name',channel);
  fd.append('niche',niche);
  fd.append('video_type',vtype);

  const res  = await fetch('api/projects.php', {method:'POST',body:fd});
  const data = await res.json();

  if (!data.success) { toast(data.message,'error'); return; }

  closeOverlay('newProjectOverlay');
  toast('Projeto criado! Iniciando processamento...','success');
  loadProjects();
  startGeneration(data.project_id);
}

// ── GENERATION WITH SSE
function startGeneration(projectId) {
  const overlay = document.getElementById('progressOverlay');
  const blocksEl = document.getElementById('progressBlocks');
  const bar = document.getElementById('progressBar');
  const msg = document.getElementById('progressMsg');
  const tokEl = document.getElementById('progressTokens');

  blocksEl.innerHTML = '';
  bar.style.width = '0%';
  msg.textContent = 'Conectando com a API do Claude...';
  tokEl.textContent = '';

  // Pre-render block slots
  for (let i = 1; i <= 14; i++) {
    const div = document.createElement('div');
    div.className = 'progress-block';
    div.id = `pb-${i}`;
    div.innerHTML = `
      <div class="pb-icon" style="background:${BLOCK_COLORS[i]}20;color:${BLOCK_COLORS[i]}">${BLOCK_ICONS[i]}</div>
      <div class="pb-name">${BLOCK_NAMES[i]}</div>
      <div class="pb-status">aguardando</div>`;
    blocksEl.appendChild(div);
  }

  overlay.classList.add('open');

  const es = new EventSource(`api/generate.php?project_id=${projectId}`);
  let completedBlocks = 0;
  let totalTokens = 0;

  es.addEventListener('start', e => {
    const d = JSON.parse(e.data);
    msg.textContent = d.message;
  });

  es.addEventListener('block_done', e => {
    const d = JSON.parse(e.data);
    const n = d.block_number;
    completedBlocks++;
    totalTokens += d.tokens || 0;

    const pb = document.getElementById(`pb-${n}`);
    if (pb) {
      pb.classList.add('done');
      pb.querySelector('.pb-status').textContent = `✓ ${(d.tokens||0).toLocaleString('pt-BR')} tokens`;
    }

    bar.style.width = `${(completedBlocks / 14) * 100}%`;
    msg.textContent = `Gerando bloco ${n}/14: ${d.block_name}`;
    tokEl.textContent = `Total de tokens usados: ${totalTokens.toLocaleString('pt-BR')}`;
    blocksEl.scrollTop = blocksEl.scrollHeight;
  });

  es.addEventListener('block_error', e => {
    const d = JSON.parse(e.data);
    const pb = document.getElementById(`pb-${d.block_number}`);
    if (pb) { pb.classList.add('error-block'); pb.querySelector('.pb-status').textContent = '✗ Erro'; }
  });

  es.addEventListener('complete', e => {
    es.close();
    const d = JSON.parse(e.data);
    bar.style.width = '100%';
    msg.textContent = '✓ Produção completa!';
    tokEl.textContent = `Total: ${(d.total_tokens||0).toLocaleString('pt-BR')} tokens`;

    setTimeout(() => {
      overlay.classList.remove('open');
      loadProjects();
      if (d.status === 'completed') {
        toast('✓ Todos os 14 blocos gerados com sucesso!','success');
        openProject(projectId);
      } else {
        toast('Processamento concluído com alguns erros.','error');
      }
    }, 1800);
  });

  es.addEventListener('error', e => {
    es.close();
    overlay.classList.remove('open');
    toast('Erro na geração. Verifique a API Key.','error');
  });
}

// ── REPORT
function openReport(id) {
  window.open(`api/report.php?project_id=${id}`, '_blank');
}

// ── DELETE
async function deleteProject(id) {
  if (!confirm('Excluir este projeto e todos os blocos gerados?')) return;
  const fd = new FormData(); fd.append('action','delete'); fd.append('id',id);
  const res = await fetch('api/projects.php',{method:'POST',body:fd});
  const data = await res.json();
  if (data.success) {
    closeViewer();
    toast('Projeto excluído.','success');
    loadProjects();
  } else { toast(data.message,'error'); }
}

// ── HELPERS
function openOverlay(id) { document.getElementById(id).classList.add('open'); }
function closeOverlay(id) { document.getElementById(id).classList.remove('open'); }
function closeIfOverlay(e,id) { if (e.target.id === id) closeOverlay(id); }

function escHtml(str) {
  return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

async function logout() {
  const fd = new FormData(); fd.append('action','logout');
  await fetch('api/auth.php',{method:'POST',body:fd});
  window.location.href = '../index.php';
}

let toastTimer;
function toast(msg, type='success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.classList.remove('show'); }, 3500);
}

function showTab(tab) { /* extend as needed */ }

// Init
loadProjects();
</script>
</body>
</html>
