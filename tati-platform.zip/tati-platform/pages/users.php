<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$db = getDB();
$users = $db->query("SELECT id, name, email, role, created_at, last_login, active FROM users ORDER BY created_at DESC")->fetchAll();
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Usuários — Tati Indicando Studio</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#07070e;--surface:#0f0f1a;--border:rgba(255,255,255,.07);--accent:#6366f1;--text:#e2e8f0;--muted:#64748b}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;padding:40px}
.header{display:flex;align-items:center;gap:16px;margin-bottom:32px}
.back{background:rgba(255,255,255,.06);border:1px solid var(--border);color:var(--text);padding:10px 18px;border-radius:10px;cursor:pointer;font-family:'DM Sans',sans-serif;font-size:13px;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.page-title{font-family:'Syne',sans-serif;font-size:24px;font-weight:800;flex:1}
.btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:10px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;cursor:pointer;border:none;transition:all .15s}
.btn-primary{background:linear-gradient(135deg,var(--accent),#a855f7);color:#fff}
.table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden}
table{width:100%;border-collapse:collapse}
th{padding:14px 20px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:1px;color:var(--muted);border-bottom:1px solid var(--border);font-weight:600}
td{padding:16px 20px;font-size:14px;border-bottom:1px solid var(--border)}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.badge{display:inline-flex;align-items:center;padding:3px 10px;border-radius:99px;font-size:11px;font-weight:600;text-transform:uppercase}
.badge-admin{background:rgba(99,102,241,.15);color:#a5b4fc;border:1px solid rgba(99,102,241,.3)}
.badge-editor{background:rgba(34,197,94,.1);color:#86efac;border:1px solid rgba(34,197,94,.2)}
.badge-viewer{background:rgba(100,116,139,.1);color:#94a3b8;border:1px solid rgba(100,116,139,.2)}
.modal{display:none;position:fixed;inset:0;z-index:99;background:rgba(0,0,0,.7);backdrop-filter:blur(6px);align-items:center;justify-content:center}
.modal.open{display:flex}
.modal-box{background:#131320;border:1px solid var(--border);border-radius:20px;padding:36px;width:100%;max-width:440px}
.modal-box h2{font-family:'Syne',sans-serif;font-size:20px;font-weight:700;margin-bottom:24px}
.field{margin-bottom:18px}
.field label{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:var(--muted);margin-bottom:8px}
.field input,.field select{width:100%;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;padding:12px 14px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:14px;outline:none}
.field input:focus,.field select:focus{border-color:rgba(99,102,241,.5)}
.field select option{background:#1e1e2e}
.actions{display:flex;gap:10px;margin-top:8px}
.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;border-radius:8px;padding:10px 14px;font-size:13px;margin-top:12px;display:none}
</style>
</head>
<body>
<div class="header">
  <a href="dashboard.php" class="back">← Dashboard</a>
  <h1 class="page-title">👥 Gerenciar Usuários</h1>
  <button class="btn btn-primary" onclick="document.getElementById('modal').classList.add('open')">+ Novo Usuário</button>
</div>

<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>#</th><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Último acesso</th><th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($users as $u): ?>
      <tr>
        <td style="color:#64748b;font-size:12px"><?= $u['id'] ?></td>
        <td style="font-weight:600"><?= clean($u['name']) ?></td>
        <td style="color:#94a3b8"><?= clean($u['email']) ?></td>
        <td><span class="badge badge-<?= $u['role'] ?>"><?= $u['role'] ?></span></td>
        <td style="font-size:12px;color:#64748b"><?= $u['last_login'] ? date('d/m/Y H:i', strtotime($u['last_login'])) : 'Nunca' ?></td>
        <td><span class="badge" style="background:<?= $u['active'] ? 'rgba(34,197,94,.1)' : 'rgba(239,68,68,.1)' ?>;color:<?= $u['active'] ? '#86efac' : '#fca5a5' ?>;border:1px solid <?= $u['active'] ? 'rgba(34,197,94,.2)' : 'rgba(239,68,68,.2)' ?>"><?= $u['active'] ? 'Ativo' : 'Inativo' ?></span></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="modal" id="modal" onclick="if(event.target===this)this.classList.remove('open')">
  <div class="modal-box">
    <h2>Novo Usuário</h2>
    <div class="field"><label>Nome</label><input type="text" id="uName" placeholder="Nome completo"></div>
    <div class="field"><label>E-mail</label><input type="email" id="uEmail" placeholder="email@exemplo.com"></div>
    <div class="field"><label>Senha</label><input type="password" id="uPass" placeholder="Mínimo 8 caracteres"></div>
    <div class="field">
      <label>Perfil de Acesso</label>
      <select id="uRole">
        <option value="editor">Editor — Pode criar e editar projetos</option>
        <option value="viewer">Viewer — Somente visualização</option>
        <option value="admin">Admin — Acesso total</option>
      </select>
    </div>
    <div class="err" id="uErr"></div>
    <div class="actions">
      <button class="btn" style="background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.07);color:#e2e8f0" onclick="document.getElementById('modal').classList.remove('open')">Cancelar</button>
      <button class="btn btn-primary" onclick="createUser()">Criar Usuário</button>
    </div>
  </div>
</div>

<script>
async function createUser() {
  const err = document.getElementById('uErr');
  err.style.display = 'none';
  const fd = new FormData();
  fd.append('action','register');
  fd.append('name', document.getElementById('uName').value);
  fd.append('email', document.getElementById('uEmail').value);
  fd.append('password', document.getElementById('uPass').value);
  fd.append('role', document.getElementById('uRole').value);
  const res = await fetch('../api/auth.php',{method:'POST',body:fd});
  const data = await res.json();
  if (data.success) { location.reload(); }
  else { err.textContent = data.message; err.style.display='block'; }
}
</script>
</body>
</html>
