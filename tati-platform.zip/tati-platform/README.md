# ✦ Tati Indicando — Studio de Produção Multiagente
## Guia de Instalação Completo

---

## 📁 Estrutura de Arquivos

```
tati-platform/
├── index.php                    ← Página de login
├── .htaccess                    ← Segurança e headers
├── database.sql                 ← Script do banco de dados
├── api/
│   ├── auth.php                 ← Login / Logout / Registro
│   ├── generate.php             ← Geração SSE multiagente
│   ├── projects.php             ← CRUD de projetos
│   └── report.php               ← Gerador de relatórios
├── includes/
│   ├── config.php               ← ⚙️ CONFIGURE AQUI
│   └── claude.service.php       ← Comunicação com API Claude
├── pages/
│   ├── dashboard.php            ← Dashboard principal
│   └── users.php                ← Gerenciar usuários (admin)
└── uploads/
    └── reports/                 ← Relatórios salvos
```

---

## 🚀 Instalação Passo a Passo

### 1. Upload para o servidor
Faça upload de toda a pasta `tati-platform/` para o diretório público do seu servidor
(geralmente `public_html/` ou `www/`).

### 2. Criar o banco de dados
1. Acesse o **phpMyAdmin** no seu cPanel
2. Clique em "Novo Banco de Dados"
3. Nome: `tati_platform`
4. Charset: `utf8mb4`
5. Clique em "Importar" e suba o arquivo `database.sql`

### 3. Configurar o arquivo principal
Abra `includes/config.php` e configure:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'usuario_do_banco');      // Seu usuário MySQL
define('DB_PASS', 'senha_do_banco');         // Sua senha MySQL
define('DB_NAME', 'tati_platform');

define('CLAUDE_API_KEY', 'sk-ant-api03-...');  // Sua chave da API Anthropic
define('BASE_URL', 'https://seudominio.com.br/tati-platform');
```

### 4. Permissões de pasta
No servidor, defina a permissão da pasta `uploads/` como **755**:
```bash
chmod -R 755 uploads/
chmod -R 755 logs/
```
Crie a pasta `logs/` se não existir.

### 5. Criar pasta de logs
```bash
mkdir tati-platform/logs
chmod 755 tati-platform/logs
```

### 6. Primeiro acesso
- URL: `https://seudominio.com.br/tati-platform/`
- E-mail: `admin@tatiindicando.com`
- Senha: `password`
- **⚠️ TROQUE A SENHA IMEDIATAMENTE após o primeiro login!**

---

## 🔑 Como obter a API Key do Claude

1. Acesse: https://console.anthropic.com/
2. Clique em "API Keys" no menu lateral
3. Clique em "Create Key"
4. Copie a chave (começa com `sk-ant-...`)
5. Cole em `includes/config.php`

---

## 🎬 Como usar a plataforma

### Criar um projeto:
1. Clique em **"✦ Novo Projeto"**
2. Preencha o título e o nome do canal
3. Cole o roteiro completo no campo "Roteiro"
4. Clique em **"Criar e Processar"**
5. O sistema multiagente vai processar automaticamente os **14 blocos**

### Acompanhar o progresso:
- O painel de progresso aparece em tempo real
- Cada bloco é mostrado conforme é gerado
- O total de tokens é exibido ao final

### Visualizar resultados:
- Clique em qualquer projeto para ver os blocos
- Use o menu de navegação dos blocos para pular entre seções
- Todos os blocos podem ser expandidos/recolhidos

### Gerar relatório:
- Dentro de um projeto concluído, clique em **"📊 Relatório HTML"**
- O relatório abre em nova aba com design profissional
- Clique em **"🖨️ Imprimir / Salvar PDF"** para exportar em PDF
- Clique em **"⬇ JSON"** para baixar os dados brutos

---

## 👥 Perfis de Usuário

| Perfil  | Pode criar projetos | Vê todos projetos | Admin |
|---------|--------------------|--------------------|-------|
| Admin   | ✅                  | ✅                  | ✅    |
| Editor  | ✅                  | ❌ (só os seus)     | ❌    |
| Viewer  | ❌                  | ❌ (só os seus)     | ❌    |

---

## ⚙️ Configurações Avançadas

### Modelo do Claude
Em `includes/config.php`, você pode alterar:
```php
define('CLAUDE_MODEL', 'claude-sonnet-4-20250514');  // Padrão recomendado
define('CLAUDE_MAX_TOKENS', 8000);                    // Tokens por bloco
```

### Timeout de geração
Cada bloco pode levar até 2 minutos. Para vídeos longos, o processo
total pode levar 15–25 minutos. Certifique-se que o PHP `max_execution_time`
esteja configurado adequadamente:
```php
set_time_limit(0); // já definido no generate.php
```

No cPanel, vá em "PHP Settings" e defina `max_execution_time = 300`.

---

## 🛡️ Segurança

- Troque a senha padrão do admin imediatamente
- Mantenha a pasta `includes/` inacessível via web (o .htaccess faz isso)
- Nunca exponha a `CLAUDE_API_KEY` em código público
- Use HTTPS obrigatoriamente em produção

---

## 📊 Estimativa de Custos API

| Tipo de projeto | Tokens estimados | Custo aprox. (Sonnet) |
|-----------------|-----------------|----------------------|
| Roteiro simples | 40.000–60.000   | ~$0.18–0.27          |
| Roteiro médio   | 60.000–100.000  | ~$0.27–0.45          |
| Roteiro longo   | 100.000–140.000 | ~$0.45–0.63          |

*Preços baseados em claude-sonnet-4 em 2025. Verifique a tabela atual em console.anthropic.com*

---

## 🆘 Suporte

Se encontrar algum erro:
1. Verifique os logs em `logs/error.log`
2. Confirme que a API Key está correta
3. Confirme que o banco de dados está configurado
4. Verifique se o PHP está na versão 8.1+

---

**Versão:** 1.0.0  
**Compatibilidade:** PHP 8.1+, MySQL 5.7+, Apache/Nginx
