-- ============================================================
-- TATI INDICANDO — PLATAFORMA MULTIAGENTE
-- Banco de Dados MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS tati_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tati_platform;

-- Usuários
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','editor','viewer') DEFAULT 'editor',
    avatar VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    active TINYINT(1) DEFAULT 1
);

-- Projetos de produção
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    niche VARCHAR(100) DEFAULT 'Eletrodomésticos',
    channel_name VARCHAR(100) DEFAULT 'Tati Indicando',
    video_type VARCHAR(100) DEFAULT NULL,
    script TEXT NOT NULL,
    status ENUM('pending','processing','completed','error') DEFAULT 'pending',
    tokens_used INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Blocos de saída (cada bloco 1–14 do sistema multiagente)
CREATE TABLE IF NOT EXISTS project_blocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    block_number TINYINT NOT NULL,
    block_name VARCHAR(100) NOT NULL,
    content LONGTEXT NOT NULL,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Relatórios exportados
CREATE TABLE IF NOT EXISTS reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    format ENUM('pdf','json','txt','html') DEFAULT 'html',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Configurações do sistema
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(100) NOT NULL UNIQUE,
    value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Logs de auditoria
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dados iniciais
INSERT INTO users (name, email, password, role) VALUES
('Administrador', 'admin@tatiindicando.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- Senha padrão: password (troque após primeiro login!)

INSERT INTO settings (key_name, value) VALUES
('claude_model', 'claude-sonnet-4-20250514'),
('max_tokens', '8000'),
('platform_name', 'Tati Indicando — Studio'),
('version', '1.0.0');
