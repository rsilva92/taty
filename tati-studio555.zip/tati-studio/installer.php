<?php
/**
 * TATI INDICANDO STUDIO — INSTALADOR WEB v2.0.0
 * Interface visual completa para instalação via navegador.
 * Delete este arquivo após a instalação!
 */
declare(strict_types=1);
session_start();

define('INSTALLER_VERSION', '2.0.0');
define('CONFIG_FILE', __DIR__ . '/includes/config.php');
define('ALREADY_INSTALLED', file_exists(CONFIG_FILE));

// ── Funções utilitárias ───────────────────────────────────────────────────────

function checkPHP(): bool {
    return version_compare(PHP_VERSION, '7.4.0', '>=');
}

function checkWritable(): bool {
    return is_writable(__DIR__) && is_writable(__DIR__ . '/includes')
        || (is_writable(__DIR__) && !is_dir(__DIR__ . '/includes'));
}

function checkExtensions(): array {
    $missing = [];
    foreach (['curl', 'json', 'mbstring'] as $ext) {
        if (!extension_loaded($ext)) $missing[] = $ext;
    }
    return $missing;
}

function hasPdoMysql(): bool {
    return extension_loaded('pdo') && extension_loaded('pdo_mysql');
}

function allEnvOk(): bool {
    return checkPHP() && checkWritable() && empty(checkExtensions());
}

function testDbConnection(string $host, string $port, string $name, string $user, string $pass): array {
    if (!hasPdoMysql()) {
        return ['ok' => false, 'error' => 'Extensão pdo_mysql não instalada no servidor.'];
    }
    try {
        $pdo = new PDO(
            "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4;connect_timeout=5",
            $user, $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return ['ok' => true, 'pdo' => $pdo];
    } catch (Exception $e) {
        $m = $e->getMessage();
        if (str_contains($m, 'Access denied'))
            $err = 'Usuário ou senha incorretos (Access denied).';
        elseif (str_contains($m, 'Unknown database'))
            $err = "Banco \"{$name}\" não existe. Crie-o no painel antes de instalar.";
        elseif (str_contains($m, "Can't connect") || str_contains($m, 'refused'))
            $err = 'MySQL não está rodando ou porta bloqueada.';
        elseif (str_contains($m, 'No such file'))
            $err = 'Socket MySQL não encontrado. Use 127.0.0.1 como host.';
        else
            $err = $m;
        return ['ok' => false, 'error' => $err];
    }
}

function createTables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS projetos (
        id            INT AUTO_INCREMENT PRIMARY KEY,
        titulo        VARCHAR(255) NOT NULL DEFAULT 'Sem titulo',
        roteiro       LONGTEXT,
        resultados    JSON,
        criado_em     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_criado (criado_em)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS sessoes_log (
        id        INT AUTO_INCREMENT PRIMARY KEY,
        ip        VARCHAR(45),
        acao      VARCHAR(100),
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function saveConfig(array $data): bool {
    $dir = __DIR__ . '/includes';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);

    $php  = "<?php\n";
    $php .= "// Gerado pelo instalador em " . date('d/m/Y H:i:s') . "\n";
    $php .= "// NÃO edite manualmente — use Configurações no Studio.\n\n";
    foreach ($data as $k => $v) {
        $php .= "define('" . $k . "', '" . addslashes((string)$v) . "');\n";
    }
    $php .= "\ndefine('INSTALLED', true);\n";

    if (file_put_contents(CONFIG_FILE, $php) === false) return false;
    chmod(CONFIG_FILE, 0640);
    @chown(CONFIG_FILE, 'www-data');
    return true;
}

function createHtaccess(string $subpath): void {
    $base = $subpath ? '/' . trim($subpath, '/') : '/';
    $ht   = "Options -Indexes\n\n";
    $ht  .= "<IfModule mod_rewrite.c>\n";
    $ht  .= "  RewriteEngine On\n";
    $ht  .= "  RewriteBase {$base}\n\n";
    $ht  .= "  RewriteCond %{REQUEST_FILENAME} !-f\n";
    $ht  .= "  RewriteCond %{REQUEST_FILENAME} !-d\n";
    $ht  .= "  RewriteRule ^api/ - [L]\n\n";
    $ht  .= "  RewriteRule ^(.*)$ index.php?route=\$1 [QSA,L]\n";
    $ht  .= "</IfModule>\n\n";
    $ht  .= "<FilesMatch \"(config\\.php|installer\\.php|\\.env|\\.git)$\">\n";
    $ht  .= "  Order Allow,Deny\n";
    $ht  .= "  Deny from all\n";
    $ht  .= "</FilesMatch>\n\n";
    $ht  .= "AddDefaultCharset UTF-8\n";
    file_put_contents(__DIR__ . '/.htaccess', $ht);
}

function createDirs(): void {
    foreach (['includes','api','cache','logs','assets/css','assets/js'] as $d) {
        $path = __DIR__ . '/' . $d;
        if (!is_dir($path)) @mkdir($path, 0755, true);
    }
}

// ── Processar formulários ─────────────────────────────────────────────────────

$step   = (int)($_SESSION['step'] ?? 1);
$errors = [];
$form   = $_SESSION['form'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // STEP 1 → 2
    if ($action === 'next_step1') {
        if (!allEnvOk()) {
            $errors[] = 'Corrija os problemas de ambiente antes de continuar.';
        } else {
            $_SESSION['step'] = 2;
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }

    // STEP 2 → 3 (instalar)
    if ($action === 'install') {
        $apiKey  = trim($_POST['api_key']  ?? '');
        $pass    = trim($_POST['password'] ?? '');
        $pass2   = trim($_POST['password2'] ?? '');
        $subpath = preg_replace('/[^A-Za-z0-9_-]/', '', $_POST['subpath'] ?? '');
        $dbHost  = trim($_POST['db_host']  ?? '127.0.0.1') ?: '127.0.0.1';
        $dbPort  = trim($_POST['db_port']  ?? '3306')      ?: '3306';
        $dbName  = trim($_POST['db_name']  ?? '');
        $dbUser  = trim($_POST['db_user']  ?? '');
        $dbPass  = $_POST['db_pass'] ?? '';

        // Salva form para repopular em caso de erro
        $_SESSION['form'] = compact('subpath','dbHost','dbPort','dbName','dbUser');

        // Validações
        if (strlen($apiKey) < 20 || substr($apiKey, 0, 7) !== 'sk-ant-')
            $errors[] = 'Chave de API inválida. Deve começar com <strong>sk-ant-</strong> e ter ao menos 20 caracteres.';
        if (strlen($pass) < 8)
            $errors[] = 'Senha deve ter ao menos <strong>8 caracteres</strong>.';
        if ($pass !== $pass2)
            $errors[] = 'As senhas não <strong>coincidem</strong>.';
        if (empty($dbName))
            $errors[] = 'Nome do banco é <strong>obrigatório</strong>.';
        if (empty($dbUser))
            $errors[] = 'Usuário do banco é <strong>obrigatório</strong>.';

        // Testa banco e cria tabelas
        if (empty($errors)) {
            $db = testDbConnection($dbHost, $dbPort, $dbName, $dbUser, $dbPass);
            if (!$db['ok']) {
                $errors[] = 'Erro no banco: <strong>' . htmlspecialchars($db['error']) . '</strong>';
            } else {
                try {
                    createTables($db['pdo']);
                } catch (Exception $e) {
                    $errors[] = 'Erro ao criar tabelas: ' . htmlspecialchars($e->getMessage());
                }
            }
        }

        // Salva tudo
        if (empty($errors)) {
            createDirs();

            $saved = saveConfig([
                'ANTHROPIC_API_KEY' => $apiKey,
                'APP_PASSWORD'      => password_hash($pass, PASSWORD_DEFAULT),
                'APP_SUBPATH'       => $subpath,
                'APP_VERSION'       => INSTALLER_VERSION,
                'DB_HOST'           => $dbHost,
                'DB_PORT'           => $dbPort,
                'DB_NAME'           => $dbName,
                'DB_USER'           => $dbUser,
                'DB_PASS'           => $dbPass,
            ]);

            if (!$saved) {
                $errors[] = 'Não foi possível salvar o <strong>config.php</strong>. Verifique as permissões da pasta <code>includes/</code>.';
            } else {
                createHtaccess($subpath);
                $_SESSION['step']       = 3;
                $_SESSION['studio_url'] = ($subpath ? '/' . $subpath : '') . '/index.php';
                $_SESSION['form']       = [];
                header('Location: ' . $_SERVER['PHP_SELF']);
                exit;
            }
        }

        // Mantém na step 2 com erros
        $_SESSION['step'] = 2;
        $step = 2;
    }

    // Reiniciar
    if ($action === 'restart') {
        session_destroy();
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

$step = (int)($_SESSION['step'] ?? 1);
$studioUrl = $_SESSION['studio_url'] ?? '/index.php';

// Pré-preenche form
$fSubpath = htmlspecialchars($form['subpath'] ?? '');
$fHost    = htmlspecialchars($form['dbHost']  ?? '127.0.0.1');
$fPort    = htmlspecialchars($form['dbPort']  ?? '3306');
$fName    = htmlspecialchars($form['dbName']  ?? 'tati_studio');
$fUser    = htmlspecialchars($form['dbUser']  ?? '');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Instalador — Tati Studio <?= INSTALLER_VERSION ?></title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&family=DM+Mono:wght@400&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:      #07070d;
  --surface: #111118;
  --surface2:#181824;
  --border:  #222235;
  --border2: #2e2e4a;
  --accent:  #ff6b35;
  --accent2: #ffb703;
  --text:    #eeeef5;
  --muted:   #6b6b8a;
  --ok:      #2dd4bf;
  --err:     #f87171;
  --warn:    #fbbf24;
  --r:       14px;
}

html { scroll-behavior: smooth; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  padding: 3rem 1.5rem;
  background-image:
    radial-gradient(ellipse at 10% 10%, rgba(255,107,53,.09) 0%, transparent 55%),
    radial-gradient(ellipse at 90% 90%, rgba(255,183,3,.07) 0%, transparent 55%);
}

/* ── Logo e topo ─────────────────────────────────────────────────────────── */
.top {
  width: 100%;
  max-width: 640px;
  margin-bottom: 2.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
}
.logo {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.5rem;
  letter-spacing: -.04em;
  display: flex;
  align-items: center;
  gap: .6rem;
}
.logo span { color: var(--accent); }
.logo .ver {
  font-family: 'DM Sans', sans-serif;
  font-size: .65rem;
  font-weight: 400;
  background: var(--surface);
  border: 1px solid var(--border);
  color: var(--muted);
  padding: .2rem .55rem;
  border-radius: 4px;
  letter-spacing: .05em;
  text-transform: uppercase;
}

/* ── Stepper ─────────────────────────────────────────────────────────────── */
.stepper {
  width: 100%;
  max-width: 640px;
  display: flex;
  align-items: center;
  margin-bottom: 2rem;
  gap: 0;
}
.step-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex: 1;
  position: relative;
}
.step-item:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 18px;
  left: 50%;
  width: 100%;
  height: 2px;
  background: var(--border);
  transition: background .4s;
  z-index: 0;
}
.step-item.done:not(:last-child)::after { background: var(--ok); }
.step-item.active:not(:last-child)::after { background: var(--border); }

.step-circle {
  width: 36px; height: 36px;
  border-radius: 50%;
  border: 2px solid var(--border);
  background: var(--surface);
  display: flex; align-items: center; justify-content: center;
  font-size: .82rem; font-weight: 700;
  color: var(--muted);
  transition: all .3s;
  position: relative; z-index: 1;
  font-family: 'Syne', sans-serif;
}
.step-item.active .step-circle {
  border-color: var(--accent);
  background: rgba(255,107,53,.12);
  color: var(--accent);
  box-shadow: 0 0 0 4px rgba(255,107,53,.12);
}
.step-item.done .step-circle {
  border-color: var(--ok);
  background: rgba(45,212,191,.12);
  color: var(--ok);
}
.step-label {
  font-size: .72rem;
  color: var(--muted);
  margin-top: .45rem;
  text-align: center;
  font-weight: 500;
  letter-spacing: .02em;
}
.step-item.active .step-label { color: var(--accent); }
.step-item.done   .step-label { color: var(--ok); }

/* ── Card principal ──────────────────────────────────────────────────────── */
.card {
  width: 100%;
  max-width: 640px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--r);
  overflow: hidden;
}
.card-header {
  padding: 2rem 2.5rem 1.5rem;
  border-bottom: 1px solid var(--border);
  background: linear-gradient(135deg, rgba(255,107,53,.04) 0%, transparent 60%);
}
.card-header h1 {
  font-family: 'Syne', sans-serif;
  font-weight: 800;
  font-size: 1.4rem;
  letter-spacing: -.03em;
  margin-bottom: .3rem;
}
.card-header p { color: var(--muted); font-size: .88rem; line-height: 1.6; }
.card-body { padding: 2rem 2.5rem; }

/* ── Checklist de ambiente ───────────────────────────────────────────────── */
.env-grid { display: flex; flex-direction: column; gap: .6rem; }
.env-item {
  display: flex; align-items: center; gap: .85rem;
  padding: .9rem 1.1rem;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 10px;
  transition: border-color .2s;
}
.env-item.ok   { border-color: rgba(45,212,191,.25);  }
.env-item.err  { border-color: rgba(248,113,113,.25); }
.env-item.warn { border-color: rgba(251,191,36,.2);   }
.env-icon { font-size: 1.15rem; flex-shrink: 0; }
.env-label { flex: 1; font-size: .88rem; }
.env-label strong { display: block; margin-bottom: .08rem; }
.env-label small  { color: var(--muted); font-size: .77rem; }
.env-badge {
  font-size: .7rem; font-weight: 700; padding: .22rem .6rem;
  border-radius: 20px; white-space: nowrap;
}
.badge-ok   { background: rgba(45,212,191,.12);  color: var(--ok); }
.badge-err  { background: rgba(248,113,113,.12); color: var(--err); }
.badge-warn { background: rgba(251,191,36,.12);  color: var(--warn); }

/* ── Formulário ──────────────────────────────────────────────────────────── */
.section-title {
  font-family: 'Syne', sans-serif;
  font-weight: 700;
  font-size: .88rem;
  color: var(--text);
  margin: 1.8rem 0 1rem;
  display: flex;
  align-items: center;
  gap: .5rem;
}
.section-title:first-child { margin-top: 0; }
.section-divider {
  border: none;
  border-top: 1px solid var(--border);
  margin: 1.8rem 0;
}

.field { margin-bottom: 1.2rem; }
.field:last-child { margin-bottom: 0; }
label {
  display: block;
  font-size: .74rem; font-weight: 600;
  color: var(--muted);
  text-transform: uppercase; letter-spacing: .07em;
  margin-bottom: .42rem;
}
.input-wrap { position: relative; }
input[type=text], input[type=password], input[type=url] {
  width: 100%;
  background: var(--surface2);
  border: 1.5px solid var(--border);
  border-radius: 9px;
  color: var(--text);
  font-family: 'DM Sans', sans-serif;
  font-size: .92rem;
  padding: .8rem 1rem;
  outline: none;
  transition: border-color .2s, box-shadow .2s;
}
input:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px rgba(255,107,53,.1);
}
input.has-toggle { padding-right: 3rem; }
.toggle-btn {
  position: absolute; right: .6rem; top: 50%;
  transform: translateY(-50%);
  background: none; border: none; cursor: pointer;
  color: var(--muted); font-size: .95rem; padding: .3rem;
  transition: color .15s;
}
.toggle-btn:hover { color: var(--text); }
.hint {
  font-size: .76rem; color: var(--muted);
  margin-top: .38rem; line-height: 1.5;
}
.grid2 { display: grid; grid-template-columns: 2fr 1fr; gap: 1rem; }
.grid2-equal { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }

/* Radio cards de instalação */
.radio-group { display: flex; gap: .75rem; }
.radio-card {
  flex: 1; border: 1.5px solid var(--border);
  border-radius: 10px; padding: 1.1rem;
  cursor: pointer; text-align: center;
  transition: border-color .2s, background .2s;
  user-select: none;
}
.radio-card:has(input:checked) {
  border-color: var(--accent);
  background: rgba(255,107,53,.06);
}
.radio-card input { display: none; }
.rc-icon  { font-size: 1.5rem; margin-bottom: .4rem; }
.rc-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: .85rem; }
.rc-desc  { font-size: .73rem; color: var(--muted); margin-top: .15rem; }

#subpath-wrap { margin-top: 1rem; display: none; }

/* ── Erros ───────────────────────────────────────────────────────────────── */
.err-box {
  background: rgba(248,113,113,.07);
  border: 1px solid rgba(248,113,113,.3);
  border-radius: 10px;
  padding: 1rem 1.2rem;
  margin-bottom: 1.5rem;
}
.err-box ul { list-style: none; }
.err-box li {
  color: var(--err); font-size: .86rem;
  line-height: 1.75; display: flex; gap: .5rem;
}
.err-box li::before { content: '⚠'; flex-shrink: 0; }

/* ── Botões ──────────────────────────────────────────────────────────────── */
.btn {
  display: inline-flex; align-items: center; justify-content: center; gap: .5rem;
  background: linear-gradient(135deg, var(--accent), #ff8c5a);
  color: #fff; border: none; border-radius: 9px;
  padding: .9rem 2rem;
  font-family: 'Syne', sans-serif; font-weight: 700; font-size: .95rem;
  cursor: pointer; transition: opacity .2s, transform .15s, box-shadow .2s;
  letter-spacing: -.01em; white-space: nowrap;
  box-shadow: 0 4px 16px rgba(255,107,53,.25);
}
.btn:hover { opacity: .88; transform: translateY(-1px); box-shadow: 0 6px 20px rgba(255,107,53,.35); }
.btn:active { transform: translateY(0); }
.btn:disabled { opacity: .4; cursor: not-allowed; transform: none; box-shadow: none; }
.btn-full { width: 100%; }
.btn-ghost {
  background: transparent;
  border: 1.5px solid var(--border2);
  color: var(--muted);
  font-family: 'DM Sans', sans-serif; font-weight: 500;
  box-shadow: none;
}
.btn-ghost:hover { border-color: var(--border2); color: var(--text); opacity: 1; box-shadow: none; }

.btn-row { display: flex; gap: .75rem; flex-wrap: wrap; margin-top: 2rem; }

/* ── Alerta de extensão ──────────────────────────────────────────────────── */
.ext-tip {
  background: rgba(251,191,36,.06);
  border: 1px solid rgba(251,191,36,.25);
  border-radius: 10px;
  padding: 1rem 1.2rem;
  margin-top: 1.5rem;
  font-size: .84rem;
  line-height: 1.7;
  color: var(--warn);
}
.ext-tip code {
  display: block;
  background: rgba(0,0,0,.3);
  border-radius: 6px;
  padding: .5rem .8rem;
  margin-top: .5rem;
  font-family: 'DM Mono', monospace;
  font-size: .78rem;
  color: var(--text);
}

/* ── Sucesso ─────────────────────────────────────────────────────────────── */
.success-wrap { text-align: center; padding: 1rem 0 .5rem; }
.success-icon {
  width: 80px; height: 80px;
  background: rgba(45,212,191,.1);
  border: 2px solid rgba(45,212,191,.3);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 2.2rem; margin: 0 auto 1.5rem;
}
.success-wrap h2 {
  font-family: 'Syne', sans-serif;
  font-weight: 800; font-size: 1.6rem;
  letter-spacing: -.03em; margin-bottom: .4rem;
}
.success-wrap p { color: var(--muted); font-size: .9rem; }

.checklist-done {
  display: flex; flex-direction: column;
  gap: .45rem; margin: 1.8rem 0;
  text-align: left;
}
.done-item {
  display: flex; align-items: center; gap: .7rem;
  font-size: .85rem; color: var(--ok);
  background: rgba(45,212,191,.05);
  border-radius: 8px; padding: .55rem .9rem;
  font-family: 'DM Mono', monospace;
}

.access-btn {
  display: flex; align-items: center; justify-content: center; gap: .65rem;
  width: 100%;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  color: #fff; text-decoration: none;
  border-radius: 10px; padding: 1.1rem;
  font-family: 'Syne', sans-serif; font-weight: 800; font-size: 1.05rem;
  letter-spacing: -.02em;
  transition: opacity .2s, transform .15s;
  box-shadow: 0 6px 24px rgba(255,107,53,.3);
  margin-bottom: .75rem;
}
.access-btn:hover { opacity: .9; transform: translateY(-1px); }

.warn-notice {
  background: rgba(251,191,36,.06);
  border: 1px solid rgba(251,191,36,.2);
  border-radius: 8px; padding: .8rem 1rem;
  font-size: .8rem; color: var(--warn);
  line-height: 1.6; text-align: left;
}

/* ── Loading spinner no botão ────────────────────────────────────────────── */
@keyframes spin { to { transform: rotate(360deg); } }
.spinner {
  width: 16px; height: 16px;
  border: 2px solid rgba(255,255,255,.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin .8s linear infinite;
  display: none;
}
.btn.loading .spinner { display: block; }
.btn.loading .btn-label { opacity: .6; }

/* ── Força de senha ──────────────────────────────────────────────────────── */
.strength-bar {
  height: 3px; border-radius: 2px;
  background: var(--border); margin-top: .4rem;
  overflow: hidden;
}
.strength-fill {
  height: 100%; border-radius: 2px;
  transition: width .3s, background .3s;
  width: 0%;
}

@media (max-width: 480px) {
  body { padding: 1.5rem 1rem; }
  .card-header, .card-body { padding: 1.5rem; }
  .grid2, .grid2-equal { grid-template-columns: 1fr; }
  .radio-group { flex-direction: column; }
}
</style>
</head>
<body>

<div class="top">
  <div class="logo">
    Tati <span>Studio</span>
    <span class="ver">Instalador <?= INSTALLER_VERSION ?></span>
  </div>
  <?php if ($step < 3): ?>
  <form method="POST" style="margin:0">
    <input type="hidden" name="action" value="restart">
    <button type="submit" style="background:none;border:1px solid var(--border);color:var(--muted);border-radius:6px;padding:.3rem .8rem;cursor:pointer;font-size:.78rem;font-family:'DM Sans',sans-serif">
      ↺ Reiniciar
    </button>
  </form>
  <?php endif; ?>
</div>

<!-- STEPPER -->
<div class="stepper">
  <?php
  $steps_labels = ['Verificação', 'Configuração', 'Concluído'];
  foreach ($steps_labels as $i => $lbl):
    $n = $i + 1;
    $cls = $n < $step ? 'done' : ($n === $step ? 'active' : '');
    $icon = $n < $step ? '✓' : $n;
  ?>
  <div class="step-item <?= $cls ?>">
    <div class="step-circle"><?= $icon ?></div>
    <div class="step-label"><?= $lbl ?></div>
  </div>
  <?php endforeach; ?>
</div>

<!-- CARD PRINCIPAL -->
<div class="card">

<?php if ($step === 3): ?>
<!-- ════════════ STEP 3: SUCESSO ════════════ -->
<div class="card-header">
  <h1>Instalação concluída 🎉</h1>
  <p>O Tati Studio está pronto para uso. Acesse agora e comece a produzir.</p>
</div>
<div class="card-body">
  <div class="success-wrap">
    <div class="success-icon">🎬</div>
    <h2>Tudo configurado!</h2>
    <p>Sistema instalado com sucesso em <?= date('d/m/Y \à\s H:i') ?></p>
  </div>

  <div class="checklist-done">
    <div class="done-item">✓  includes/config.php — gerado</div>
    <div class="done-item">✓  .htaccess — configurado</div>
    <div class="done-item">✓  Banco de dados — conectado</div>
    <div class="done-item">✓  Tabelas projetos + sessoes_log — criadas</div>
    <div class="done-item">✓  Pastas cache/, logs/, assets/ — criadas</div>
  </div>

  <a href="<?= htmlspecialchars($studioUrl) ?>" class="access-btn">
    🚀 Acessar o Studio agora
  </a>

  <div class="warn-notice">
    ⚠️ <strong>Importante:</strong> Delete ou renomeie o arquivo <code style="background:rgba(0,0,0,.2);padding:.1rem .3rem;border-radius:3px">installer.php</code> do servidor agora para evitar acesso indevido.
  </div>
</div>

<?php elseif ($step === 2): ?>
<!-- ════════════ STEP 2: CONFIGURAÇÃO ════════════ -->
<div class="card-header">
  <h1>Configuração do sistema</h1>
  <p>Preencha os dados abaixo. Todos os campos marcados com * são obrigatórios.</p>
</div>
<div class="card-body">

  <?php if (!empty($errors)): ?>
  <div class="err-box">
    <ul>
      <?php foreach ($errors as $e): ?>
      <li><?= $e ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
  <?php endif; ?>

  <form method="POST" id="install-form" novalidate>
    <input type="hidden" name="action" value="install">

    <!-- Anthropic API -->
    <div class="section-title">🤖 API da Anthropic</div>

    <div class="field">
      <label>Chave de API *</label>
      <div class="input-wrap">
        <input type="password" name="api_key" id="api-key"
               class="has-toggle"
               placeholder="sk-ant-api03-..."
               autocomplete="off" required>
        <button type="button" class="toggle-btn" onclick="toggleVis('api-key',this)">👁</button>
      </div>
      <p class="hint">Obtenha em <strong>console.anthropic.com</strong> → API Keys. Começa com <code style="font-size:.75rem">sk-ant-</code></p>
    </div>

    <hr class="section-divider">

    <!-- Credenciais de acesso -->
    <div class="section-title">🔐 Senha de acesso ao Studio</div>

    <div class="grid2-equal">
      <div class="field">
        <label>Senha * <span style="font-size:.68rem;text-transform:none;letter-spacing:0">(mín. 8 caracteres)</span></label>
        <div class="input-wrap">
          <input type="password" name="password" id="pass-input"
                 class="has-toggle"
                 placeholder="••••••••"
                 autocomplete="new-password"
                 oninput="calcStrength(this)"
                 required>
          <button type="button" class="toggle-btn" onclick="toggleVis('pass-input',this)">👁</button>
        </div>
        <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
      </div>
      <div class="field">
        <label>Confirmar senha *</label>
        <div class="input-wrap">
          <input type="password" name="password2" id="pass2-input"
                 class="has-toggle"
                 placeholder="••••••••"
                 autocomplete="new-password"
                 required>
          <button type="button" class="toggle-btn" onclick="toggleVis('pass2-input',this)">👁</button>
        </div>
      </div>
    </div>

    <hr class="section-divider">

    <!-- Localização -->
    <div class="section-title">📁 Local de instalação</div>

    <div class="field">
      <div class="radio-group">
        <label class="radio-card">
          <input type="radio" name="install_type" value="root" checked onchange="toggleSubpath(false)">
          <div class="rc-icon">🏠</div>
          <div class="rc-title">Raiz do domínio</div>
          <div class="rc-desc">seusite.com/</div>
        </label>
        <label class="radio-card">
          <input type="radio" name="install_type" value="sub" onchange="toggleSubpath(true)">
          <div class="rc-icon">📂</div>
          <div class="rc-title">Subpasta</div>
          <div class="rc-desc">seusite.com/studio</div>
        </label>
      </div>
      <div id="subpath-wrap">
        <label>Nome da subpasta</label>
        <input type="text" name="subpath" id="subpath-input"
               placeholder="ex: studio"
               value="<?= $fSubpath ?>">
        <p class="hint">Apenas letras, números e hífen. Sem barras ou espaços.</p>
      </div>
    </div>

    <hr class="section-divider">

    <!-- Banco de dados -->
    <div class="section-title">🗄️ Banco de dados (MySQL)</div>

    <div class="grid2">
      <div class="field">
        <label>Host *</label>
        <input type="text" name="db_host" value="<?= $fHost ?>" required>
      </div>
      <div class="field">
        <label>Porta *</label>
        <input type="text" name="db_port" value="<?= $fPort ?>" required>
      </div>
    </div>

    <div class="field">
      <label>Nome do banco *</label>
      <input type="text" name="db_name" value="<?= $fName ?>" required>
      <p class="hint">O banco já deve existir. Crie-o no painel da hospedagem (cPanel/Plesk) antes de instalar.</p>
    </div>

    <div class="grid2-equal">
      <div class="field">
        <label>Usuário MySQL *</label>
        <input type="text" name="db_user" value="<?= $fUser ?>"
               placeholder="tati_user" autocomplete="off" required>
      </div>
      <div class="field">
        <label>Senha MySQL</label>
        <div class="input-wrap">
          <input type="password" name="db_pass" id="db-pass"
                 class="has-toggle"
                 placeholder="Senha do usuário"
                 autocomplete="new-password">
          <button type="button" class="toggle-btn" onclick="toggleVis('db-pass',this)">👁</button>
        </div>
      </div>
    </div>
    <p class="hint" style="margin-top:-.5rem">💡 As tabelas serão criadas automaticamente após conectar com sucesso.</p>

    <div class="btn-row">
      <button type="submit" class="btn btn-full" id="install-btn">
        <div class="spinner"></div>
        <span class="btn-label">⚡ Instalar sistema</span>
      </button>
    </div>

    <div style="text-align:center;margin-top:1rem">
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="restart">
        <button type="submit" class="btn btn-ghost" style="padding:.5rem 1.2rem;font-size:.82rem">← Voltar</button>
      </form>
    </div>

  </form>
</div>

<?php else: ?>
<!-- ════════════ STEP 1: VERIFICAÇÃO ════════════ -->
<?php
$phpOk      = checkPHP();
$writableOk = checkWritable();
$missingExt = checkExtensions();
$pdoOk      = hasPdoMysql();
$allOk      = $phpOk && $writableOk && empty($missingExt);
?>
<div class="card-header">
  <h1>Verificação do ambiente</h1>
  <p>Checando se o servidor atende os requisitos antes de instalar o Tati Studio.</p>
</div>
<div class="card-body">

  <?php if (!empty($errors)): ?>
  <div class="err-box">
    <ul><?php foreach($errors as $e): ?><li><?= $e ?></li><?php endforeach; ?></ul>
  </div>
  <?php endif; ?>

  <div class="env-grid">

    <!-- PHP -->
    <div class="env-item <?= $phpOk ? 'ok' : 'err' ?>">
      <span class="env-icon">🐘</span>
      <div class="env-label">
        <strong>PHP <?= PHP_VERSION ?></strong>
        <small>Versão mínima requerida: 7.4</small>
      </div>
      <span class="env-badge <?= $phpOk ? 'badge-ok' : 'badge-err' ?>">
        <?= $phpOk ? 'OK' : 'Atualizar' ?>
      </span>
    </div>

    <!-- Escrita -->
    <div class="env-item <?= $writableOk ? 'ok' : 'err' ?>">
      <span class="env-icon">📝</span>
      <div class="env-label">
        <strong>Permissão de escrita</strong>
        <small><?= htmlspecialchars(__DIR__) ?></small>
      </div>
      <span class="env-badge <?= $writableOk ? 'badge-ok' : 'badge-err' ?>">
        <?= $writableOk ? 'OK' : 'Sem permissão' ?>
      </span>
    </div>

    <!-- Extensões base -->
    <div class="env-item <?= empty($missingExt) ? 'ok' : 'err' ?>">
      <span class="env-icon">🔌</span>
      <div class="env-label">
        <strong>Extensões base</strong>
        <small>curl, json, mbstring</small>
      </div>
      <span class="env-badge <?= empty($missingExt) ? 'badge-ok' : 'badge-err' ?>">
        <?= empty($missingExt) ? 'OK' : 'Faltam: ' . implode(', ', $missingExt) ?>
      </span>
    </div>

    <!-- pdo_mysql -->
    <div class="env-item <?= $pdoOk ? 'ok' : 'warn' ?>">
      <span class="env-icon">🗄️</span>
      <div class="env-label">
        <strong>pdo_mysql</strong>
        <small>Necessário para salvar projetos no banco</small>
      </div>
      <span class="env-badge <?= $pdoOk ? 'badge-ok' : 'badge-warn' ?>">
        <?= $pdoOk ? 'OK' : 'Não instalada' ?>
      </span>
    </div>

    <!-- mod_rewrite -->
    <div class="env-item warn">
      <span class="env-icon">🌐</span>
      <div class="env-label">
        <strong>mod_rewrite</strong>
        <small>Verificado após instalação</small>
      </div>
      <span class="env-badge badge-warn">Pendente</span>
    </div>

  </div>

  <!-- Dicas de correção -->
  <?php if (!$writableOk): ?>
  <div class="ext-tip" style="border-color:rgba(248,113,113,.25);color:var(--err)">
    ⚠ Sem permissão de escrita. Execute no servidor:
    <code>chmod 755 <?= htmlspecialchars(__DIR__) ?> && chown www-data:www-data <?= htmlspecialchars(__DIR__) ?></code>
  </div>
  <?php endif; ?>

  <?php if (!empty($missingExt)): ?>
  <div class="ext-tip" style="border-color:rgba(248,113,113,.25);color:var(--err)">
    ⚠ Extensões faltando: <strong><?= implode(', ', $missingExt) ?></strong>
    <code>sudo apt-get install <?= implode(' ', array_map(fn($e) => "php8.2-{$e}", $missingExt)) ?> && sudo systemctl restart apache2</code>
  </div>
  <?php endif; ?>

  <?php if (!$pdoOk): ?>
  <div class="ext-tip">
    ℹ️ <strong>pdo_mysql não encontrada</strong> — você pode continuar, mas o salvamento de projetos não vai funcionar até instalar a extensão.
    <code>sudo apt-get install php8.2-mysql -y && sudo systemctl restart apache2</code>
    Em hospedagem compartilhada: ative <strong>pdo_mysql</strong> no painel PHP do provedor.
  </div>
  <?php endif; ?>

  <form method="POST" style="margin-top:1.8rem">
    <input type="hidden" name="action" value="next_step1">
    <button type="submit" class="btn btn-full" <?= !$allOk ? 'disabled' : '' ?>>
      <?= $allOk
        ? '✓ Tudo OK — Continuar para configuração →'
        : 'Corrija os erros acima para continuar' ?>
    </button>
  </form>

</div>
<?php endif; ?>

</div><!-- .card -->

<p style="margin-top:1.5rem;font-size:.75rem;color:var(--muted);text-align:center">
  Tati Indicando Studio <?= INSTALLER_VERSION ?> — Delete este arquivo após instalar
</p>

<script>
// Mostrar/ocultar senha
function toggleVis(id, btn) {
  const inp = document.getElementById(id);
  const isPass = inp.type === 'password';
  inp.type = isPass ? 'text' : 'password';
  btn.textContent = isPass ? '🙈' : '👁';
}

// Subpasta
function toggleSubpath(show) {
  const wrap  = document.getElementById('subpath-wrap');
  const input = document.getElementById('subpath-input');
  wrap.style.display = show ? 'block' : 'none';
  show ? input.setAttribute('required','') : input.removeAttribute('required');
  if (!show) input.value = '';
}

// Força de senha
function calcStrength(inp) {
  const val  = inp.value;
  const fill = document.getElementById('strength-fill');
  if (!fill) return;
  let score = 0;
  if (val.length >= 8)  score++;
  if (val.length >= 12) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const colors = ['#f87171','#fbbf24','#fbbf24','#34d399','#2dd4bf'];
  const widths  = ['20%','40%','60%','80%','100%'];
  fill.style.width      = widths[Math.min(score, 4)];
  fill.style.background = colors[Math.min(score, 4)];
}

// Loading no botão de instalar
document.getElementById('install-form')?.addEventListener('submit', function(e) {
  const btn = document.getElementById('install-btn');
  // Validação básica antes de mostrar loading
  const apiKey = document.querySelector('[name=api_key]').value.trim();
  const pass   = document.querySelector('[name=password]').value;
  const pass2  = document.querySelector('[name=password2]').value;
  if (pass !== pass2) {
    e.preventDefault();
    alert('As senhas não coincidem.');
    return;
  }
  if (!apiKey.startsWith('sk-ant-') || apiKey.length < 20) {
    e.preventDefault();
    alert('Chave de API inválida. Deve começar com sk-ant-');
    return;
  }
  btn.classList.add('loading');
  btn.disabled = true;
  document.querySelector('.btn-label').textContent = 'Instalando...';
});
</script>
</body>
</html>
